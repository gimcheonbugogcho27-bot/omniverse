"""크리에이터: 프로젝트/파일 관리, 템플릿, 미리보기(샌드박스), 공개 갤러리, 평가, 내보내기/가져오기, AI 생성."""
import re

from flask import Blueprint, Response, g

import db
from routes_ai import generate
from security import (APIError, body, choice, feature_required, integer, login_required, ok, rate_limit, text)

bp = Blueprint("creator", __name__)

PATH_RE = re.compile(r"^[A-Za-z0-9_\-]{1,40}\.(html|css|js|json|md|txt)$")
MAX_FILES = 20

TEMPLATES = {
    "blank": {"index.html": "<!doctype html>\n<html lang=\"ko\">\n<head><meta charset=\"utf-8\"><link rel=\"stylesheet\" href=\"style.css\"></head>\n<body>\n  <h1>새 프로젝트</h1>\n  <script src=\"script.js\"></script>\n</body>\n</html>\n",
              "style.css": "body { font-family: sans-serif; background: #0b1020; color: #e6f0ff; padding: 2rem; }\n",
              "script.js": "console.log('OMNIVERSE X 프로젝트');\n"},
    "game": {"index.html": "<!doctype html>\n<html lang=\"ko\">\n<head><meta charset=\"utf-8\"><link rel=\"stylesheet\" href=\"style.css\"></head>\n<body>\n  <canvas id=\"c\" width=\"480\" height=\"320\"></canvas>\n  <p>방향키로 움직여 별을 모으세요</p>\n  <script src=\"script.js\"></script>\n</body>\n</html>\n",
             "style.css": "body { margin: 0; display: grid; place-items: center; min-height: 100vh; background: #050816; color: #9fe8ff; font-family: sans-serif; }\ncanvas { background: #0d1433; border-radius: 12px; }\n",
             "script.js": "const c = document.getElementById('c'), x = c.getContext('2d');\nlet p = {x: 240, y: 160}, star = {x: 100, y: 100}, score = 0, keys = {};\naddEventListener('keydown', e => keys[e.key] = true);\naddEventListener('keyup', e => keys[e.key] = false);\nfunction loop() {\n  if (keys.ArrowLeft) p.x -= 4; if (keys.ArrowRight) p.x += 4;\n  if (keys.ArrowUp) p.y -= 4; if (keys.ArrowDown) p.y += 4;\n  if (Math.hypot(p.x - star.x, p.y - star.y) < 18) { score++; star = {x: Math.random() * 460 + 10, y: Math.random() * 300 + 10}; }\n  x.clearRect(0, 0, 480, 320);\n  x.fillStyle = '#ffd84d'; x.beginPath(); x.arc(star.x, star.y, 8, 0, 7); x.fill();\n  x.fillStyle = '#22d3ee'; x.beginPath(); x.arc(p.x, p.y, 12, 0, 7); x.fill();\n  x.fillStyle = '#fff'; x.fillText('점수 ' + score, 10, 20);\n  requestAnimationFrame(loop);\n}\nloop();\n"},
    "website": {"index.html": "<!doctype html>\n<html lang=\"ko\">\n<head><meta charset=\"utf-8\"><link rel=\"stylesheet\" href=\"style.css\"></head>\n<body>\n  <header><h1>나의 웹사이트</h1><p>OMNIVERSE X 크리에이터로 만들었어요</p></header>\n  <section class=\"cards\"><div>소개</div><div>작품</div><div>연락</div></section>\n  <script src=\"script.js\"></script>\n</body>\n</html>\n",
                "style.css": "body { margin: 0; font-family: sans-serif; background: linear-gradient(135deg, #1e1b4b, #0e7490); color: #fff; min-height: 100vh; }\nheader { padding: 4rem 2rem; text-align: center; }\n.cards { display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap; }\n.cards div { background: rgba(255,255,255,.12); padding: 2rem 3rem; border-radius: 16px; }\n",
                "script.js": "document.querySelectorAll('.cards div').forEach(d => d.onclick = () => alert(d.textContent));\n"},
    "app": {"index.html": "<!doctype html>\n<html lang=\"ko\">\n<head><meta charset=\"utf-8\"><link rel=\"stylesheet\" href=\"style.css\"></head>\n<body>\n  <h1>할 일 앱</h1>\n  <form id=\"f\"><input id=\"t\" placeholder=\"할 일\"><button>추가</button></form>\n  <ul id=\"l\"></ul>\n  <script src=\"script.js\"></script>\n</body>\n</html>\n",
            "style.css": "body { font-family: sans-serif; background: #0b1020; color: #e6f0ff; padding: 2rem; }\ninput, button { padding: .5rem; border-radius: 8px; border: 0; }\nli { cursor: pointer; }\n",
            "script.js": "const f = document.getElementById('f'), t = document.getElementById('t'), l = document.getElementById('l');\nf.onsubmit = e => { e.preventDefault(); if (!t.value) return; const li = document.createElement('li'); li.textContent = t.value; li.onclick = () => li.remove(); l.append(li); t.value = ''; };\n"},
}


def _project(pid, write=False):
    p = db.one("select cp.*, u.username as owner from public.creator_projects cp join public.users u on u.id = cp.owner_id "
               "where cp.id = %(p)s", {"p": pid})
    if not p:
        raise APIError(404, "프로젝트를 찾을 수 없습니다")
    me = g.user
    is_owner = p["owner_id"] == me["id"]
    if write and not is_owner:
        raise APIError(403, "프로젝트 주인만 수정할 수 있습니다")
    if not is_owner and p["visibility"] != "public" and me["role"] != "admin":
        raise APIError(404, "프로젝트를 찾을 수 없습니다")
    p["is_owner"] = is_owner
    return p


def _bump(pid):
    db.execute("update public.creator_projects set version = version + 1 where id = %(p)s", {"p": pid})


def _write_file(pid, path, content):
    if not PATH_RE.match(path):
        raise APIError(400, "파일 이름은 영문/숫자/-/_ 와 .html .css .js .json .md .txt 확장자만 쓸 수 있습니다")
    if len(content) > 500000:
        raise APIError(400, "파일은 50만 자까지 저장할 수 있습니다")
    exists = db.scalar("select exists (select 1 from public.project_files where project_id = %(p)s and path = %(f)s) as x",
                       {"p": pid, "f": path})
    if not exists and db.scalar("select count(*) as n from public.project_files where project_id = %(p)s", {"p": pid}) >= MAX_FILES:
        raise APIError(400, f"파일은 프로젝트당 {MAX_FILES}개까지 만들 수 있습니다")
    db.execute("insert into public.project_files (project_id, path, content) values (%(p)s, %(f)s, %(c)s) "
               "on conflict (project_id, path) do update set content = excluded.content, version = public.project_files.version + 1",
               {"p": pid, "f": path, "c": content})


@bp.get("/api/creator/projects")
@login_required
@feature_required("creator")
def my_projects():
    return ok(db.query("select id, title, kind, description, visibility, version, rating_sum, rating_count, updated_at "
                       "from public.creator_projects where owner_id = %(u)s order by updated_at desc", {"u": g.user["id"]}))


@bp.get("/api/creator/gallery")
@login_required
@feature_required("creator")
def gallery():
    return ok(db.query("select cp.id, cp.title, cp.kind, cp.description, cp.version, cp.rating_sum, cp.rating_count, cp.updated_at, "
                       "u.username as owner from public.creator_projects cp join public.users u on u.id = cp.owner_id "
                       "where cp.visibility = 'public' and u.status = 'active' order by cp.updated_at desc limit 60"))


@bp.post("/api/creator/projects")
@login_required
@feature_required("creator")
@rate_limit("project_new", 10, 3600, per="user")
def create_project():
    d = body()
    uid = g.user["id"]
    if db.scalar("select count(*) as n from public.creator_projects where owner_id = %(u)s", {"u": uid}) >= 30:
        raise APIError(400, "프로젝트는 30개까지 만들 수 있습니다")
    kind = choice(d, "kind", ("app", "game", "website", "world"))
    template = choice(d, "template", tuple(TEMPLATES.keys()), default="blank")
    row = db.one("insert into public.creator_projects (owner_id, title, kind, description) values (%(u)s, %(t)s, %(k)s, %(d)s) "
                 "returning id", {"u": uid, "t": text(d, "title", max_len=60), "k": kind,
                                  "d": text(d, "description", required=False, min_len=0, max_len=500)})
    for path, content in TEMPLATES[template].items():
        _write_file(row["id"], path, content)
    return ok({"id": row["id"]}, 201)


@bp.get("/api/creator/projects/<int:pid>")
@login_required
def get_project(pid):
    p = _project(pid)
    files = db.query("select path, content, version, updated_at from public.project_files where project_id = %(p)s order by path",
                     {"p": pid})
    my_rating = db.scalar("select stars from public.project_ratings where project_id = %(p)s and user_id = %(u)s",
                          {"p": pid, "u": g.user["id"]})
    return ok({"project": p, "files": files, "my_rating": my_rating})


@bp.patch("/api/creator/projects/<int:pid>")
@login_required
def update_project(pid):
    _project(pid, write=True)
    d = body()
    sets, params = [], {"p": pid}
    if "title" in d:
        params["t"] = text(d, "title", max_len=60)
        sets.append("title = %(t)s")
    if "description" in d:
        params["d"] = text(d, "description", required=False, min_len=0, max_len=500) or ""
        sets.append("description = %(d)s")
    if "visibility" in d:
        params["v"] = choice(d, "visibility", ("private", "public"))
        sets.append("visibility = %(v)s")
    if not sets:
        raise APIError(400, "바꿀 내용이 없습니다")
    db.execute(f"update public.creator_projects set {', '.join(sets)} where id = %(p)s", params)
    return ok()


@bp.delete("/api/creator/projects/<int:pid>")
@login_required
def delete_project(pid):
    _project(pid, write=True)
    db.execute("delete from public.creator_projects where id = %(p)s", {"p": pid})
    return ok()


@bp.put("/api/creator/projects/<int:pid>/files")
@login_required
@rate_limit("file_save", 60, 60, per="user")
def save_file(pid):
    _project(pid, write=True)
    d = body()
    path = text(d, "path", max_len=50)
    content = d.get("content", "")
    if not isinstance(content, str):
        raise APIError(400, "content 값은 문자열이어야 합니다")
    _write_file(pid, path, content)
    _bump(pid)
    return ok()


@bp.delete("/api/creator/projects/<int:pid>/files/<path>")
@login_required
def delete_file(pid, path):
    _project(pid, write=True)
    if path == "index.html":
        raise APIError(400, "index.html은 지울 수 없습니다")
    n = db.execute("delete from public.project_files where project_id = %(p)s and path = %(f)s", {"p": pid, "f": path})
    if not n:
        raise APIError(404, "파일을 찾을 수 없습니다")
    _bump(pid)
    return ok()


@bp.post("/api/creator/projects/<int:pid>/rate")
@login_required
def rate(pid):
    p = _project(pid)
    if p["is_owner"]:
        raise APIError(400, "내 작품은 평가할 수 없습니다")
    if p["visibility"] != "public":
        raise APIError(400, "공개 작품만 평가할 수 있습니다")
    stars = integer(body(), "stars", lo=1, hi=5)
    db.execute("insert into public.project_ratings (project_id, user_id, stars) values (%(p)s, %(u)s, %(s)s) "
               "on conflict (project_id, user_id) do update set stars = excluded.stars", {"p": pid, "u": g.user["id"], "s": stars})
    db.execute("update public.creator_projects set rating_sum = t.s, rating_count = t.c from "
               "(select coalesce(sum(stars), 0) as s, count(*) as c from public.project_ratings where project_id = %(p)s) t "
               "where id = %(p)s", {"p": pid})
    return ok()


@bp.get("/api/creator/projects/<int:pid>/export")
@login_required
def export_project(pid):
    p = _project(pid)
    files = db.query("select path, content from public.project_files where project_id = %(p)s order by path", {"p": pid})
    return ok({"format": "omniverse-project/1", "title": p["title"], "kind": p["kind"],
               "description": p["description"], "files": files})


@bp.post("/api/creator/import")
@login_required
@feature_required("creator")
@rate_limit("project_new", 10, 3600, per="user")
def import_project():
    d = body()
    if d.get("format") != "omniverse-project/1":
        raise APIError(400, "OMNIVERSE 프로젝트 파일 형식이 아닙니다")
    files = d.get("files")
    if not isinstance(files, list) or not files or len(files) > MAX_FILES:
        raise APIError(400, "파일 목록이 올바르지 않습니다")
    kind = choice(d, "kind", ("app", "game", "website", "world"))
    row = db.one("insert into public.creator_projects (owner_id, title, kind, description) values (%(u)s, %(t)s, %(k)s, %(d)s) "
                 "returning id", {"u": g.user["id"], "t": text(d, "title", max_len=60), "k": kind,
                                  "d": text(d, "description", required=False, min_len=0, max_len=500)})
    for f in files:
        if not isinstance(f, dict) or not isinstance(f.get("path"), str) or not isinstance(f.get("content"), str):
            db.execute("delete from public.creator_projects where id = %(p)s", {"p": row["id"]})
            raise APIError(400, "파일 항목이 올바르지 않습니다")
        try:
            _write_file(row["id"], f["path"], f["content"])
        except APIError:
            db.execute("delete from public.creator_projects where id = %(p)s", {"p": row["id"]})
            raise
    return ok({"id": row["id"]}, 201)


@bp.post("/api/creator/projects/<int:pid>/ai-generate")
@login_required
@feature_required("ai")
@rate_limit("ai_build", 5, 300, per="user")
def ai_generate(pid):
    p = _project(pid, write=True)
    prompt = text(body(), "prompt", max_len=2000)
    system = ("너는 HTML5 웹 개발자다. 사용자의 요청을 외부 라이브러리 없이 하나의 완전한 HTML 파일(<style>, <script> 포함)로 만든다. "
              "설명 없이 코드만 출력하고, 코드 블록 표시(```)도 쓰지 않는다. 한국어 UI를 쓴다.")
    answer = generate(system, [{"role": "user", "content": f"[{p['kind']}] {prompt}"}], max_tokens=8192)
    code = re.sub(r"^```[a-zA-Z]*\s*|\s*```$", "", answer.strip())
    _write_file(pid, "index.html", code)
    _bump(pid)
    return ok({"path": "index.html", "length": len(code)})


@bp.get("/api/creator/projects/<int:pid>/preview")
@login_required
def preview(pid):
    """샌드박스 미리보기: CSP sandbox로 별도 출처에서 실행되어 OMNIVERSE 쿠키/API에 접근할 수 없다."""
    _project(pid)
    files = {f["path"]: f["content"] for f in db.query(
        "select path, content from public.project_files where project_id = %(p)s", {"p": pid})}
    html = files.get("index.html", "<p>index.html이 없습니다</p>")

    def inline_css(m):
        name = m.group(1)
        return f"<style>\n{files[name]}\n</style>" if name in files else m.group(0)

    def inline_js(m):
        name = m.group(1)
        if name not in files:
            return m.group(0)
        code = files[name].replace("</script", "<\\/script")
        return "<script>\n" + code + "\n</script>"

    html = re.sub(r"<link[^>]+href=[\"']([A-Za-z0-9_\-]+\.css)[\"'][^>]*>", inline_css, html)
    html = re.sub(r"<script[^>]+src=[\"']([A-Za-z0-9_\-]+\.js)[\"'][^>]*>\s*</script>", inline_js, html)
    resp = Response(html, mimetype="text/html")
    resp.headers["Content-Security-Policy"] = (
        "sandbox allow-scripts allow-pointer-lock; default-src 'none'; script-src 'unsafe-inline'; "
        "style-src 'unsafe-inline'; img-src data: https:; font-src data: https:; media-src data: https:; "
        "frame-ancestors 'self'")
    resp.headers["X-Frame-Options"] = "SAMEORIGIN"
    resp.headers["Cache-Control"] = "no-store"
    return resp
