"""월드, 아바타, 퀘스트, 업적."""
import re

from flask import Blueprint, g

import db
import services as sv
from security import APIError, body, choice, feature_required, integer, login_required, ok, rate_limit, text

bp = Blueprint("world", __name__)

AVATAR_BODIES = ("default", "astronaut", "android", "spirit")
THEMES = ("city", "ocean", "forest", "volcano", "ice", "desert", "nebula")


@bp.get("/api/worlds")
@login_required
@feature_required("world")
def worlds():
    me = g.user["id"]
    rows = db.query(
        "select w.id, w.slug, w.name, w.theme, w.description, w.color, w.min_level, w.is_official, "
        "cu.username as creator, "
        "(select count(*) from public.world_members m where m.world_id = w.id) as members, "
        "m.score as my_score, m.last_visit_at as my_last_visit "
        "from public.worlds w left join public.world_members m on m.world_id = w.id and m.user_id = %(me)s "
        "left join public.users cu on cu.id = w.creator_id "
        "where w.is_active order by w.is_official desc, w.min_level, w.id", {"me": me})
    level = g.user["level"] or 1
    for r in rows:
        r["locked"] = r["min_level"] > level
    return ok({"items": rows, "my_level": level})


def _world(slug):
    w = db.one("select id, slug, name, theme, description, color, min_level, is_official, creator_id, created_at "
               "from public.worlds where slug = %(s)s and is_active", {"s": slug})
    if not w:
        raise APIError(404, "월드를 찾을 수 없습니다")
    return w


@bp.get("/api/worlds/<slug>")
@login_required
@feature_required("world")
def world(slug):
    w = _world(slug)
    me = g.user["id"]
    board = db.query(
        "select u.username, p.display_name, p.level, m.score from public.world_members m "
        "join public.users u on u.id = m.user_id join public.user_profiles p on p.user_id = u.id "
        "where m.world_id = %(w)s and u.status = 'active' order by m.score desc, m.joined_at limit 10", {"w": w["id"]})
    mine = db.one("select score, joined_at, last_visit_at from public.world_members where world_id = %(w)s and user_id = %(u)s",
                  {"w": w["id"], "u": me})
    quests = db.query(
        f"select q.code, q.title, q.description, q.reward_coins, q.reward_exp, coalesce(uq.status, 'in_progress') as status "
        f"from public.quests q left join public.user_quests uq on uq.quest_id = q.id and uq.user_id = %(u)s "
        f"and uq.period = {sv.QUEST_PERIOD_SQL} where q.world_id = %(w)s and q.is_active", {"w": w["id"], "u": me})
    w["locked"] = w["min_level"] > (g.user["level"] or 1)
    return ok({"world": w, "leaderboard": board, "membership": mine, "quests": quests})


@bp.post("/api/worlds/<slug>/enter")
@login_required
@feature_required("world")
def enter(slug):
    w = _world(slug)
    me = g.user["id"]
    if w["min_level"] > (g.user["level"] or 1):
        raise APIError(403, f"레벨 {w['min_level']} 이상부터 입장할 수 있습니다")
    row = db.one(
        "insert into public.world_members (world_id, user_id) values (%(w)s, %(u)s) "
        "on conflict (world_id, user_id) do update set last_visit_at = now() returning (xmax = 0) as first_visit",
        {"w": w["id"], "u": me})
    if slug == "nova-prime":
        sv.complete_quest(me, "first_landing")
    if row["first_visit"]:
        sv.add_exp(me, 20)
        sv.check_explorer(me)
    return ok({"entered": True, "first_visit": row["first_visit"]})


@bp.post("/api/worlds/<slug>/score")
@login_required
@feature_required("world")
@rate_limit("world_score", 6, 60, per="user")
def world_score(slug):
    """월드 탐험(에너지 수집) 결과 저장. 한 번에 최대 500점."""
    w = _world(slug)
    score = integer(body(), "score", lo=0, hi=500)
    row = db.one("update public.world_members set score = score + %(s)s, last_visit_at = now() "
                 "where world_id = %(w)s and user_id = %(u)s returning score", {"s": score, "w": w["id"], "u": g.user["id"]})
    if not row:
        raise APIError(400, "먼저 월드에 입장하세요")
    lvl = sv.add_exp(g.user["id"], min(score // 10, 50))
    return ok({"total": row["score"], "level": lvl})


@bp.post("/api/worlds")
@login_required
@feature_required("world")
@rate_limit("world_new", 3, 3600, per="user")
def create_world():
    d = body()
    me = g.user["id"]
    if db.scalar("select count(*) as n from public.worlds where creator_id = %(u)s", {"u": me}) >= 3:
        raise APIError(400, "사용자 월드는 1인당 3개까지 만들 수 있습니다")
    name = text(d, "name", min_len=2, max_len=30)
    theme = choice(d, "theme", THEMES)
    color = text(d, "color", required=False, max_len=7) or "#7c5cff"
    if not re.match(r"^#[0-9a-fA-F]{6}$", color):
        raise APIError(400, "색상은 #RRGGBB 형식이어야 합니다")
    desc = text(d, "description", required=False, min_len=0, max_len=300)
    slug = f"u{me}-" + re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")[:20]
    if slug.endswith("-") or slug == f"u{me}-":
        slug = f"u{me}-world{db.scalar('select count(*) + 1 as n from public.worlds where creator_id = %(u)s', {'u': me})}"
    try:
        row = db.one("insert into public.worlds (slug, name, theme, description, color, creator_id) "
                     "values (%(s)s, %(n)s, %(t)s, %(d)s, %(c)s, %(u)s) returning id, slug",
                     {"s": slug, "n": name, "t": theme, "d": desc, "c": color, "u": me})
    except db.IntegrityError:
        raise APIError(409, "같은 이름의 월드가 이미 있습니다")
    return ok(row, 201)


# ---------------- 아바타 ----------------

@bp.get("/api/avatar")
@login_required
def avatar():
    me = g.user["id"]
    av = db.one("select body, color, equipped from public.avatars where user_id = %(u)s", {"u": me})
    owned = db.query("select i.code, i.name, i.rarity from public.inventory inv join public.items i on i.id = inv.item_id "
                     "where inv.user_id = %(u)s and inv.quantity > 0 and i.category = 'avatar' order by i.price", {"u": me})
    return ok({"avatar": av, "owned": owned, "bodies": AVATAR_BODIES})


@bp.patch("/api/avatar")
@login_required
def update_avatar():
    import json
    d = body()
    me = g.user["id"]
    sets, params = [], {"u": me}
    if "body" in d:
        params["b"] = choice(d, "body", AVATAR_BODIES)
        sets.append("body = %(b)s")
    if "color" in d:
        color = text(d, "color", max_len=7)
        if not re.match(r"^#[0-9a-fA-F]{6}$", color):
            raise APIError(400, "색상은 #RRGGBB 형식이어야 합니다")
        params["c"] = color
        sets.append("color = %(c)s")
    if "equipped" in d:
        eq = d["equipped"]
        if not isinstance(eq, list) or len(eq) > 5 or not all(isinstance(x, str) for x in eq):
            raise APIError(400, "장착 목록이 올바르지 않습니다")
        if eq:
            owned = {r["code"] for r in db.query(
                "select i.code from public.inventory inv join public.items i on i.id = inv.item_id "
                "where inv.user_id = %(u)s and inv.quantity > 0 and i.category = 'avatar'", {"u": me})}
            if not set(eq) <= owned:
                raise APIError(400, "가지고 있는 아바타 아이템만 장착할 수 있습니다")
        params["e"] = json.dumps({"items": sorted(set(eq))})
        sets.append("equipped = %(e)s::jsonb")
    if not sets:
        raise APIError(400, "바꿀 내용이 없습니다")
    db.execute(f"update public.avatars set {', '.join(sets)} where user_id = %(u)s", params)
    return ok()


# ---------------- 퀘스트 / 업적 ----------------

@bp.get("/api/quests")
@login_required
def quests():
    return ok(db.query(
        f"select q.code, q.title, q.description, q.reward_coins, q.reward_exp, q.is_daily, w.name as world_name, "
        f"coalesce(uq.status, 'in_progress') as status from public.quests q "
        f"left join public.worlds w on w.id = q.world_id "
        f"left join public.user_quests uq on uq.quest_id = q.id and uq.user_id = %(u)s and uq.period = {sv.QUEST_PERIOD_SQL} "
        f"where q.is_active order by q.is_daily desc, q.id", {"u": g.user["id"]}))


@bp.post("/api/quests/<code>/claim")
@login_required
@rate_limit("quest_claim", 20, 60, per="user")
def claim(code):
    me = g.user["id"]
    q = db.one(
        f"select q.id, q.title, q.reward_coins, q.reward_exp, uq.status, to_char(uq.period, 'YYYY-MM-DD') as period "
        f"from public.quests q join public.user_quests uq on uq.quest_id = q.id and uq.user_id = %(u)s "
        f"and uq.period = {sv.QUEST_PERIOD_SQL} where q.code = %(c)s", {"u": me, "c": code})
    if not q:
        raise APIError(400, "아직 완료하지 않은 퀘스트입니다")
    if q["status"] == "claimed":
        raise APIError(409, "이미 보상을 받았습니다")
    balance = None
    if q["reward_coins"] > 0:
        try:
            balance = db.scalar("select public.omni_credit(%(u)s, %(a)s, 'quest_reward', %(m)s, %(k)s) as b",
                                {"u": me, "a": q["reward_coins"], "m": f"퀘스트: {q['title']}",
                                 "k": f"quest:{me}:{q['id']}:{q['period']}"})
        except db.OmniError as e:
            if e.code != "already_claimed":
                from security import omni_to_api
                raise omni_to_api(e)
    db.execute("update public.user_quests set status = 'claimed' where user_id = %(u)s and quest_id = %(q)s "
               f"and period = %(p)s::date", {"u": me, "q": q["id"], "p": q["period"]})
    lvl = sv.add_exp(me, q["reward_exp"])
    return ok({"coins": q["reward_coins"], "exp": q["reward_exp"], "balance": balance, "level": lvl})


@bp.get("/api/achievements")
@login_required
def achievements():
    return ok(db.query(
        "select a.code, a.title, a.description, a.icon, a.reward_coins, ua.earned_at "
        "from public.achievements a left join public.user_achievements ua on ua.achievement_id = a.id and ua.user_id = %(u)s "
        "order by a.id", {"u": g.user["id"]}))
