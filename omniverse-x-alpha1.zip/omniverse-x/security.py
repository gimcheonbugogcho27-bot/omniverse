"""인증, 세션, CSRF, 요청 제한, 입력값 검증, 권한 데코레이터."""
import hashlib
import json
import os
import re
import secrets
import threading
import time
from collections import defaultdict, deque
from functools import wraps

from flask import g, jsonify, request, session

import db

SESSION_DAYS = 30
USERNAME_RE = re.compile(r"^[A-Za-z0-9_가-힣]{2,20}$")
EMAIL_RE = re.compile(r"^[^@\s]{1,64}@[^@\s]{1,190}\.[^@\s]{2,}$")


class APIError(Exception):
    def __init__(self, status, message, code=None):
        super().__init__(message)
        self.status = status
        self.message = message
        self.code = code


OMNI_MESSAGES = {
    "insufficient_funds": (400, "코인이 부족합니다"),
    "already_claimed": (409, "이미 받은 보상입니다"),
    "wallet_frozen": (403, "지갑이 동결되어 있습니다. 관리자에게 문의하세요"),
    "invalid_amount": (400, "금액 또는 수량이 올바르지 않습니다"),
    "self_transfer": (400, "자기 자신에게는 보낼 수 없습니다"),
    "receiver_unavailable": (400, "받는 사람에게 보낼 수 없습니다"),
    "daily_limit": (400, "오늘 송금 한도를 넘었습니다"),
    "item_not_found": (404, "아이템을 찾을 수 없습니다"),
    "not_for_sale": (400, "판매하지 않는 아이템입니다"),
    "already_owned": (409, "이미 가지고 있는 아이템입니다"),
}


def omni_to_api(err):
    status, msg = OMNI_MESSAGES.get(err.code, (400, "요청을 처리할 수 없습니다"))
    return APIError(status, msg, err.code)


# ---------- 입력값 ----------

def body():
    data = request.get_json(silent=True)
    if data is None:
        data = {}
    if not isinstance(data, dict):
        raise APIError(400, "JSON 객체 형식이어야 합니다")
    return data


def text(data, key, *, required=True, min_len=1, max_len=500, default=None):
    val = data.get(key, default)
    if val is None:
        if required:
            raise APIError(400, f"{key} 값이 필요합니다")
        return None
    if not isinstance(val, str):
        raise APIError(400, f"{key} 값은 문자열이어야 합니다")
    val = val.strip()
    if required and len(val) < min_len:
        raise APIError(400, f"{key} 값은 {min_len}자 이상이어야 합니다")
    if len(val) > max_len:
        raise APIError(400, f"{key} 값은 {max_len}자 이하여야 합니다")
    return val


def integer(data, key, *, required=True, lo=None, hi=None, default=None):
    val = data.get(key, default)
    if val is None:
        if required:
            raise APIError(400, f"{key} 값이 필요합니다")
        return None
    if isinstance(val, bool):
        raise APIError(400, f"{key} 값은 정수여야 합니다")
    try:
        val = int(val)
    except (TypeError, ValueError):
        raise APIError(400, f"{key} 값은 정수여야 합니다")
    if lo is not None and val < lo:
        raise APIError(400, f"{key} 값은 {lo} 이상이어야 합니다")
    if hi is not None and val > hi:
        raise APIError(400, f"{key} 값은 {hi} 이하여야 합니다")
    return val


def choice(data, key, options, *, default=None):
    val = data.get(key, default)
    if val not in options:
        raise APIError(400, f"{key} 값이 올바르지 않습니다")
    return val


def page_args(default_limit=20, max_limit=50):
    try:
        limit = min(max(int(request.args.get("limit", default_limit)), 1), max_limit)
        offset = max(int(request.args.get("offset", 0)), 0)
    except ValueError:
        raise APIError(400, "limit/offset 값이 올바르지 않습니다")
    return limit, offset


# ---------- 요청 제한 / 비정상 활동 ----------

class RateLimiter:
    def __init__(self):
        self._hits = defaultdict(deque)
        self._lock = threading.Lock()

    def hit(self, key, limit, window):
        now = time.monotonic()
        with self._lock:
            q = self._hits[key]
            while q and q[0] <= now - window:
                q.popleft()
            if len(q) >= limit:
                return False
            q.append(now)
            if len(self._hits) > 50000:  # 메모리 보호
                self._hits.clear()
            return True

    def count(self, key, window):
        now = time.monotonic()
        with self._lock:
            q = self._hits.get(key)
            if not q:
                return 0
            while q and q[0] <= now - window:
                q.popleft()
            return len(q)

    def reset(self):
        with self._lock:
            self._hits.clear()


limiter = RateLimiter()


def client_ip():
    # ProxyFix(x_for=1)가 Render 프록시가 붙인 실제 IP를 remote_addr에 넣는다 (사용자가 위조한 헤더는 무시)
    return request.remote_addr or "unknown"


def rate_limit(bucket, limit, window, per="ip"):
    def deco(fn):
        @wraps(fn)
        def wrapper(*a, **kw):
            ident = str(g.user["id"]) if per == "user" and getattr(g, "user", None) else client_ip()
            if not limiter.hit(f"{bucket}:{ident}", limit, window):
                raise APIError(429, "요청이 너무 많습니다. 잠시 후 다시 시도하세요")
            return fn(*a, **kw)
        return wrapper
    return deco


# ---------- 세션 ----------

def _hash(token):
    return hashlib.sha256(token.encode()).hexdigest()


def start_session(user_id):
    token = secrets.token_urlsafe(32)
    db.execute(
        "insert into public.user_sessions (user_id, token_hash, ip, user_agent, expires_at) "
        "values (%(u)s, %(h)s, %(ip)s, %(ua)s, now() + make_interval(days => %(d)s))",
        {"u": user_id, "h": _hash(token), "ip": client_ip()[:64],
         "ua": (request.user_agent.string or "")[:300], "d": SESSION_DAYS},
    )
    session.clear()
    session.permanent = True
    session["sid"] = token
    session["csrf"] = secrets.token_urlsafe(24)


def end_session():
    token = session.get("sid")
    if token:
        db.execute("update public.user_sessions set revoked_at = now() where token_hash = %(h)s", {"h": _hash(token)})
    session.clear()


def load_user():
    g.user = None
    token = session.get("sid")
    if not token:
        return
    row = db.one(
        "select u.id, u.email, u.username, u.role, u.status, p.display_name, p.level, p.exp "
        "from public.user_sessions s join public.users u on u.id = s.user_id "
        "left join public.user_profiles p on p.user_id = u.id "
        "where s.token_hash = %(h)s and s.revoked_at is null and s.expires_at > now()",
        {"h": _hash(token)},
    )
    if not row or row["status"] != "active":
        session.pop("sid", None)
        return
    g.user = row


def csrf_token():
    if "csrf" not in session:
        session["csrf"] = secrets.token_urlsafe(24)
    return session["csrf"]


def check_csrf():
    if request.method in ("GET", "HEAD", "OPTIONS"):
        return
    sent = request.headers.get("X-CSRF-Token", "")
    expected = session.get("csrf", "")
    if not expected or not secrets.compare_digest(sent, expected):
        raise APIError(403, "보안 토큰이 올바르지 않습니다. 페이지를 새로고침하세요", "csrf")


def login_required(fn):
    @wraps(fn)
    def wrapper(*a, **kw):
        if not g.get("user"):
            raise APIError(401, "로그인이 필요합니다", "auth")
        return fn(*a, **kw)
    return wrapper


def admin_required(fn):
    @wraps(fn)
    def wrapper(*a, **kw):
        if not g.get("user"):
            raise APIError(401, "로그인이 필요합니다", "auth")
        if g.user["role"] != "admin":
            raise APIError(403, "관리자만 접근할 수 있습니다", "forbidden")
        return fn(*a, **kw)
    return wrapper


def staff_required(fn):
    @wraps(fn)
    def wrapper(*a, **kw):
        if not g.get("user"):
            raise APIError(401, "로그인이 필요합니다", "auth")
        if g.user["role"] not in ("admin", "moderator"):
            raise APIError(403, "운영자만 접근할 수 있습니다", "forbidden")
        return fn(*a, **kw)
    return wrapper


# ---------- 시스템 설정 (30초 캐시) ----------

_settings_cache = {"at": 0.0, "data": {}}


def settings(refresh=False):
    if refresh or time.monotonic() - _settings_cache["at"] > 30:
        rows = db.query("select key, value from public.system_settings")
        data = {}
        for r in rows:
            v = r["value"]
            data[r["key"]] = json.loads(v) if isinstance(v, str) else v
        _settings_cache.update(at=time.monotonic(), data=data)
    return _settings_cache["data"]


def setting(key, default=None):
    return settings().get(key, default)


def feature_required(name):
    def deco(fn):
        @wraps(fn)
        def wrapper(*a, **kw):
            feats = setting("features", {}) or {}
            if not feats.get(name, False):
                raise APIError(503, "이 기능은 현재 비활성화되어 있습니다", "feature_off")
            return fn(*a, **kw)
        return wrapper
    return deco


def ok(data=None, status=200):
    return jsonify(data if data is not None else {"ok": True}), status


def is_admin_email(email):
    raw = os.environ.get("ADMIN_EMAILS", "")
    allowed = {e.strip().lower() for e in raw.split(",") if e.strip()}
    return email.lower() in allowed
