"""PostgreSQL 접근 계층.

모든 SQL은 %s / %(name)s 자리표시자로 값을 넘긴다(문자열 이어붙이기 금지 → SQL Injection 방지).
결과는 dict 목록으로 돌려준다.
"""
import os
import re
import threading


class DBError(Exception):
    """일반 DB 오류"""


class IntegrityError(DBError):
    """고유값/외래키/체크 제약 위반"""


class OmniError(DBError):
    """DB 함수가 올린 비즈니스 오류 (OMNI:<code>)"""

    def __init__(self, code):
        super().__init__(code)
        self.code = code


_OMNI_RE = re.compile(r"OMNI:([a-z_]+)")
_pool = None
_pool_lock = threading.Lock()


def _normalize_url(url):
    # Render/Heroku 형식 postgres:// → postgresql://
    if url.startswith("postgres://"):
        url = "postgresql://" + url[len("postgres://"):]
    if "sslmode=" not in url and "localhost" not in url and "127.0.0.1" not in url:
        url += ("&" if "?" in url else "?") + "sslmode=require"
    return url


def _get_pool():
    global _pool
    if _pool is None:
        with _pool_lock:
            if _pool is None:
                import psycopg2.pool  # 배포 환경에서만 필요
                url = os.environ.get("DATABASE_URL")
                if not url:
                    raise DBError("DATABASE_URL 환경변수가 설정되지 않았습니다")
                maxconn = int(os.environ.get("DB_POOL_MAX", "5"))
                _pool = psycopg2.pool.ThreadedConnectionPool(1, maxconn, _normalize_url(url), connect_timeout=10)
    return _pool


def _translate(exc):
    msg = str(exc)
    m = _OMNI_RE.search(msg)
    if m:
        return OmniError(m.group(1))
    pgcode = getattr(exc, "pgcode", None) or ""
    if pgcode.startswith("23"):
        return IntegrityError(msg)
    return DBError(msg)


def _run_psycopg(sql, params, fetch):
    """실제 PostgreSQL 실행. fetch=True면 행 목록, False면 영향받은 행 수."""
    import psycopg2
    import psycopg2.extras
    pool = _get_pool()
    conn = pool.getconn()
    broken = False
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute(sql, params)
            result = [dict(r) for r in cur.fetchall()] if fetch else cur.rowcount
        conn.commit()
        return result
    except psycopg2.Error as exc:
        try:
            conn.rollback()
        except Exception:
            broken = True
        if isinstance(exc, (psycopg2.OperationalError, psycopg2.InterfaceError)):
            broken = True
        raise _translate(exc) from exc
    finally:
        pool.putconn(conn, close=broken)


# 테스트에서 교체할 수 있도록 함수 참조로 둔다.
_run = _run_psycopg


def query(sql, params=None):
    return _run(sql, params or None, True)


def one(sql, params=None):
    rows = query(sql, params)
    return rows[0] if rows else None


def scalar(sql, params=None):
    row = one(sql, params)
    return next(iter(row.values())) if row else None


def execute(sql, params=None):
    return _run(sql, params or None, False)


def ping():
    return scalar("select 1 as ok") == 1

