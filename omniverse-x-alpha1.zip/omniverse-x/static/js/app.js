/* =========================================================
   OMNIVERSE X ALPHA 1.0 — 프론트엔드 (해시 라우팅 SPA)
   모든 사용자 입력은 esc()로 이스케이프한 뒤 화면에 넣는다.
   ========================================================= */
(function () {
  "use strict";

  const S = { user: null, csrf: "", features: {}, unread: 0, balance: null, stop: null, timers: [], theme: "nebula" };
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const ESC = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };
  const esc = (v) => String(v == null ? "" : v).replace(/[&<>"']/g, (c) => ESC[c]);
  const num = (n) => Number(n || 0).toLocaleString("ko-KR");
  const enc = encodeURIComponent;

  // ---------------- API ----------------
  async function api(path, opts = {}) {
    const method = opts.method || "GET";
    const headers = { Accept: "application/json" };
    if (method !== "GET") { headers["Content-Type"] = "application/json"; headers["X-CSRF-Token"] = S.csrf; }
    let res;
    try {
      res = await fetch(path, { method, headers, credentials: "same-origin", body: method === "GET" ? undefined : JSON.stringify(opts.body || {}) });
    } catch (e) {
      const err = new Error("네트워크에 연결할 수 없습니다. 인터넷 연결을 확인하세요"); err.status = 0; throw err;
    }
    let data = null;
    try { data = await res.json(); } catch (e) { /* 빈 응답 */ }
    if (data && data.csrf) S.csrf = data.csrf;
    if (!res.ok) {
      const err = new Error((data && data.error) || `요청 실패 (${res.status})`);
      err.status = res.status; err.code = data && data.code;
      if (res.status === 401 && data && data.code === "auth" && S.user) { S.user = null; render(); }
      if (data && data.code === "csrf") await refreshMe();
      throw err;
    }
    return data;
  }
  const post = (p, b) => api(p, { method: "POST", body: b });
  const patch = (p, b) => api(p, { method: "PATCH", body: b });
  const put = (p, b) => api(p, { method: "PUT", body: b });
  const del = (p) => api(p, { method: "DELETE" });

  // ---------------- UI 도구 ----------------
  function toast(msg, kind = "ok") {
    const t = document.createElement("div");
    t.className = `toast glass ${kind}`;
    t.textContent = msg;
    $("#toasts").appendChild(t);
    setTimeout(() => { t.classList.add("out"); setTimeout(() => t.remove(), 350); }, 3200);
  }
  const fail = (e) => toast(e.message || String(e), "err");

  function modal(html, onMount) {
    const m = $("#modal");
    m.innerHTML = `<div class="modal-box glass">${html}</div>`;
    m.classList.remove("hidden");
    m.onclick = (e) => { if (e.target === m || e.target.closest("[data-close]")) closeModal(); };
    if (onMount) onMount($(".modal-box", m));
  }
  function closeModal() { const m = $("#modal"); m.classList.add("hidden"); m.innerHTML = ""; }
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeModal(); });

  function confirmBox(text, okLabel = "확인", danger = false) {
    return new Promise((resolve) => {
      modal(`<h3>${esc(text)}</h3><div class="row end" style="margin-top:1.2rem">
        <button class="btn ghost" data-close>취소</button><button class="btn ${danger ? "danger" : ""}" id="cf-ok">${esc(okLabel)}</button></div>`,
      (box) => { $("#cf-ok", box).onclick = () => { closeModal(); resolve(true); }; });
      $("#modal").addEventListener("click", function h(e) { if (e.target.closest("[data-close]") || e.target === $("#modal")) { resolve(false); $("#modal").removeEventListener("click", h); } });
    });
  }

  async function busy(btn, fn) {
    if (!btn) return fn();
    btn.classList.add("loading"); btn.disabled = true;
    try { return await fn(); } finally { btn.classList.remove("loading"); btn.disabled = false; }
  }

  function timeAgo(iso) {
    if (!iso) return "";
    const d = new Date(iso), s = (Date.now() - d.getTime()) / 1000;
    if (s < 60) return "방금 전";
    if (s < 3600) return `${Math.floor(s / 60)}분 전`;
    if (s < 86400) return `${Math.floor(s / 3600)}시간 전`;
    if (s < 86400 * 7) return `${Math.floor(s / 86400)}일 전`;
    return d.toLocaleDateString("ko-KR");
  }
  const fmt = (iso) => (iso ? new Date(iso).toLocaleString("ko-KR", { dateStyle: "medium", timeStyle: "short" }) : "-");

  const BODY_ICON = { default: "", astronaut: "🧑‍🚀", android: "🤖", spirit: "👻" };
  const ITEM_ICON = { avatar_neon_visor: "🥽", avatar_star_cape: "🦸", avatar_nebula_wings: "🪽", game_boost_x2: "⚡", badge_pioneer: "🏅" };
  const CAT_ICON = { avatar: "👕", game: "🎮", world: "🪐", badge: "🏅", consumable: "🧪" };
  function avatarHTML(name, color, body, cls = "", equipped) {
    const icon = BODY_ICON[body] || "";
    const items = (equipped && equipped.items) || [];
    const gear = items.length ? `<span class="gear">${ITEM_ICON[items[0]] || "✦"}</span>` : "";
    const c = /^#[0-9a-fA-F]{6}$/.test(color || "") ? color : "";
    return `<span class="avatar ${cls}" data-color="${esc(c)}">${icon || esc((name || "?").slice(0, 1))}${gear}</span>`;
  }
  function planetHTML(color, size, ring = true) {
    const c = /^#[0-9a-fA-F]{6}$/.test(color || "") ? color : "#7c5cff";
    return `<span class="planet-wrap"><span class="planet" data-pc="${c}" data-size="${size}"></span>${ring ? `<span class="planet-ring" data-pc="${c}" data-size="${size}"></span>` : ""}</span>`;
  }
  // CSP(인라인 스타일 속성 금지 대비): data-* 값을 CSSOM으로 적용
  function paint(root) {
    $$("[data-pc]", root).forEach((el) => { el.style.setProperty("--pc", el.dataset.pc); if (el.dataset.size) el.style.setProperty("--size", el.dataset.size + "px"); });
    $$(".avatar[data-color]", root).forEach((el) => { if (el.dataset.color) el.style.setProperty("--ac", el.dataset.color); });
    $$("[data-w]", root).forEach((el) => { el.style.width = el.dataset.w + "%"; });
    $$("[data-h]", root).forEach((el) => { el.style.height = el.dataset.h + "%"; });
    $$("[data-gc]", root).forEach((el) => el.style.setProperty("--gc", el.dataset.gc));
  }
  function userLink(username, display) {
    return `<a href="#/u/${enc(username)}"><b>${esc(display || username)}</b></a> <span class="dim">@${esc(username)}</span>`;
  }
  function richText(s) {
    let h = esc(s);
    h = h.replace(/```(\w*)\n?([\s\S]*?)```/g, (_, lang, code) => `<pre>${code}</pre>`);
    h = h.replace(/`([^`\n]+)`/g, "<code>$1</code>");
    h = h.replace(/\*\*([^*\n]+)\*\*/g, "<b>$1</b>");
    return h;
  }
  const emptyBox = (icon, text) => `<div class="empty"><span class="big">${icon}</span>${esc(text)}</div>`;

  // 3D 기울기 효과 (마우스 반응)
  document.addEventListener("pointermove", (e) => {
    const el = e.target.closest && e.target.closest(".tilt");
    if (!el || e.pointerType !== "mouse") return;
    const r = el.getBoundingClientRect();
    const x = (e.clientX - r.left) / r.width - 0.5, y = (e.clientY - r.top) / r.height - 0.5;
    el.style.transform = `perspective(900px) rotateX(${(-y * 8).toFixed(2)}deg) rotateY(${(x * 10).toFixed(2)}deg) translateY(-3px)`;
  }, { passive: true });
  document.addEventListener("pointerout", (e) => {
    const el = e.target.closest && e.target.closest(".tilt");
    if (el && !el.contains(e.relatedTarget)) el.style.transform = "";
  });

  // ---------------- 셸 ----------------
  const NAV = [
    ["메인", [["dashboard", "🏠", "대시보드"], ["ai", "🤖", "OMNI AI"], ["worlds", "🪐", "월드"], ["games", "🎮", "게임 센터"]]],
    ["소셜", [["feed", "📰", "피드"], ["friends", "🤝", "친구"], ["messages", "💬", "메시지"], ["communities", "👥", "커뮤니티"]]],
    ["경제·성장", [["wallet", "💰", "지갑"], ["shop", "🛍️", "상점"], ["avatar", "🧑‍🚀", "아바타"], ["quests", "🎯", "퀘스트·업적"], ["rankings", "🏆", "랭킹"]]],
    ["창작", [["creator", "🛠️", "크리에이터"], ["gallery", "🖼️", "작품 갤러리"]]],
    ["기타", [["notifications", "🔔", "알림"], ["settings", "⚙️", "설정"], ["roadmap", "🧭", "로드맵"]]],
  ];
  function shellHTML() {
    const admin = S.user.role === "admin" || S.user.role === "moderator";
    const groups = NAV.map(([g, items]) => `<div class="nav-group">${g}</div>` + items.map(([k, i, l]) =>
      `<a href="#/${k}" data-nav="${k}"><span class="ico">${i}</span>${l}${k === "notifications" ? `<span class="badge hidden" id="nav-unread"></span>` : ""}</a>`).join("")).join("");
    return `
    <div class="shell">
      <aside class="sidebar glass">
        <div class="brand">${planetHTML("#7c5cff", 30, false)}<div>OMNIVERSE <b>X</b><small>ALPHA 1.0</small></div></div>
        <nav class="nav">${groups}${admin ? `<div class="nav-group">운영</div><a href="#/admin" data-nav="admin"><span class="ico">🛡️</span>관리자</a>` : ""}</nav>
        <div class="grow"></div>
        <a class="item" href="#/u/${enc(S.user.username)}">${avatarHTML(S.user.display_name, "", "")}<div class="grow"><div>${esc(S.user.display_name)}</div><div class="dim">Lv.${S.user.level} · @${esc(S.user.username)}</div></div></a>
      </aside>
      <div class="main">
        <header class="topbar glass">
          <a class="brand-mini" href="#/dashboard">${planetHTML("#7c5cff", 26, false)}<span>OMNI<b>X</b></span></a>
          <form class="search" id="search-form"><input class="input" id="search-q" placeholder="사용자, 월드, 게임, 게시물 검색" aria-label="통합 검색"></form>
          <div class="grow"></div>
          <a class="coin-chip" href="#/wallet" title="내 코인"><span class="coin"></span><span id="top-balance">-</span><span class="txt">코인</span></a>
          <a class="icon-btn" href="#/notifications" title="알림">🔔<span class="dot hidden" id="top-unread"></span></a>
          <button class="icon-btn" id="logout-btn" title="로그아웃">⏻</button>
        </header>
        <div id="view"></div>
      </div>
      <nav class="mobile-nav glass">
        <a href="#/dashboard" data-nav="dashboard"><span class="ico">🏠</span>홈</a>
        <a href="#/worlds" data-nav="worlds"><span class="ico">🪐</span>월드</a>
        <a href="#/ai" data-nav="ai"><span class="ico">🤖</span>AI</a>
        <a href="#/feed" data-nav="feed"><span class="ico">📰</span>피드</a>
        <button id="more-btn"><span class="ico">☰</span>더보기</button>
      </nav>
      <div class="more-sheet glass" id="more-sheet">
        ${NAV.flatMap(([, items]) => items).filter(([k]) => !["dashboard", "worlds", "ai", "feed"].includes(k))
          .map(([k, i, l]) => `<a href="#/${k}"><span class="ico">${i}</span>${l}</a>`).join("")}
        ${admin ? `<a href="#/admin"><span class="ico">🛡️</span>관리자</a>` : ""}
      </div>
    </div>`;
  }
  function mountShell() {
    $("#root").innerHTML = shellHTML();
    paint($("#root"));
    $("#search-form").onsubmit = (e) => { e.preventDefault(); const q = $("#search-q").value.trim(); if (q) location.hash = `#/search/${enc(q)}`; };
    $("#logout-btn").onclick = async () => { try { await post("/api/auth/logout"); } catch (e) { /* 무시 */ } S.user = null; location.hash = "#/"; render(); };
    $("#more-btn").onclick = () => $("#more-sheet").classList.toggle("open");
    $("#more-sheet").onclick = (e) => { if (e.target.closest("a")) $("#more-sheet").classList.remove("open"); };
    refreshTop();
  }
  async function refreshTop() {
    if (!S.user) return;
    try {
      const [n, w] = await Promise.all([api("/api/notifications?limit=1"), S.features.economy ? api("/api/wallet?limit=1") : Promise.resolve(null)]);
      S.unread = n.unread;
      const dot = $("#top-unread"), nb = $("#nav-unread");
      [dot, nb].forEach((el) => { if (!el) return; el.textContent = n.unread > 99 ? "99+" : n.unread; el.classList.toggle("hidden", !n.unread); });
      if (w) { S.balance = w.balance; const b = $("#top-balance"); if (b) b.textContent = num(w.balance); }
    } catch (e) { /* 상단바 갱신 실패는 조용히 */ }
  }

  // ---------------- 라우터 ----------------
  const ROUTES = [];
  const route = (re, fn, nav) => ROUTES.push({ re, fn, nav });
  function cleanup() {
    if (S.stop) { try { S.stop(); } catch (e) { /* 무시 */ } S.stop = null; }
    S.timers.forEach(clearInterval); S.timers = [];
    closeModal();
  }
  async function refreshMe() {
    const me = await api("/api/auth/me");
    S.user = me.user; S.csrf = me.csrf; S.features = me.features || {};
    return me;
  }
  let shellFor = null;
  async function render() {
    cleanup();
    const sheet = $("#more-sheet"); if (sheet) sheet.classList.remove("open");
    const path = (location.hash.replace(/^#/, "") || "/").split("?")[0];
    if (!S.user) { shellFor = null; return viewAuth(); }
    if (path === "/" || path === "") { location.replace("#/dashboard"); return; }
    if (shellFor !== S.user.id) { mountShell(); shellFor = S.user.id; }
    const view = $("#view");
    let hit = null, m = null;
    for (const r of ROUTES) { m = path.match(r.re); if (m) { hit = r; break; } }
    const navKey = hit ? hit.nav : "";
    $$("[data-nav]").forEach((a) => a.classList.toggle("on", a.dataset.nav === navKey));
    view.innerHTML = `<div class="view"><div class="empty"><span class="big">✦</span>불러오는 중…</div></div>`;
    window.scrollTo({ top: 0 });
    if (!hit) { view.innerHTML = `<div class="view glass card">${emptyBox("🛰️", "존재하지 않는 페이지입니다.")}<div class="center"><a class="btn" href="#/dashboard">대시보드로</a></div></div>`; return; }
    try {
      await hit.fn(view, ...m.slice(1).map((x) => (x == null ? undefined : decodeURIComponent(x))));
      paint(view);
    } catch (e) {
      if (e.status === 401) return;
      view.innerHTML = `<div class="view glass card">${emptyBox(e.code === "feature_off" ? "🔒" : "⚠️", e.message)}<div class="center"><button class="btn ghost" id="retry">다시 시도</button></div></div>`;
      $("#retry").onclick = render;
    }
  }
  window.addEventListener("hashchange", render);
  const page = (title, sub, actions = "") => `<div class="page-head"><div><h1 class="grad">${title}</h1>${sub ? `<p>${sub}</p>` : ""}</div><div class="row">${actions}</div></div>`;

  // ================= 인증 =================
  function viewAuth() {
    const refMatch = location.hash.match(/ref=([A-Za-z0-9_가-힣]+)/);
    const ref = refMatch ? decodeURIComponent(refMatch[1]) : "";
    $("#root").innerHTML = `
    <div class="auth view">
      <section class="auth-hero">
        <div class="chip c2">ALPHA 1.0 · 차세대 통합 플랫폼</div>
        <h1>OMNIVERSE <span class="grad">X</span></h1>
        <p class="tag">AI 어시스턴트, 3D 행성 월드, 게임 센터, 소셜 네트워크, 가상 경제, 창작 도구를 하나의 계정으로.</p>
        <div class="hero-planet-wrap"><span class="planet" data-pc="#7c5cff"></span><span class="planet-ring" data-pc="#22d3ee"></span><span class="moon"></span></div>
        <div class="feature-pills">${["🤖 OMNI AI", "🪐 5개 행성 월드", "🎮 게임 3종", "💰 가상 코인", "🛠️ 크리에이터", "🛡️ 관리자 도구"].map((t) => `<span class="chip">${t}</span>`).join("")}</div>
      </section>
      <section class="auth-card glass">
        <div class="tabs"><button class="on" data-tab="login">로그인</button><button data-tab="signup">회원가입</button></div>
        <form id="login-form">
          <label class="field"><span>아이디 또는 이메일</span><input class="input" name="login" autocomplete="username" required></label>
          <label class="field"><span>비밀번호</span><input class="input" name="password" type="password" autocomplete="current-password" required></label>
          <button class="btn block">우주로 출발 🚀</button>
        </form>
        <form id="signup-form" class="hidden">
          <label class="field"><span>이메일</span><input class="input" name="email" type="email" autocomplete="email" required></label>
          <label class="field"><span>아이디 (2~20자, 한글·영문·숫자·_)</span><input class="input" name="username" autocomplete="username" required maxlength="20"></label>
          <label class="field"><span>표시 이름</span><input class="input" name="display_name" maxlength="30" placeholder="비우면 아이디 사용"></label>
          <label class="field"><span>비밀번호 (8자 이상, 영문+숫자)</span><input class="input" name="password" type="password" autocomplete="new-password" required minlength="8"></label>
          ${ref ? `<div class="notice info small">${esc(ref)}님의 초대로 가입하면 자동으로 친구 요청이 갑니다.</div><br>` : ""}
          <button class="btn cyan block">계정 만들기 ✦</button>
          <p class="dim center">가입하면 500 코인과 개척자 배지를 드려요. 실제 돈과는 무관한 가상 화폐입니다.</p>
        </form>
      </section>
    </div>`;
    paint($("#root"));
    $$(".tabs button").forEach((b) => (b.onclick = () => {
      $$(".tabs button").forEach((x) => x.classList.toggle("on", x === b));
      $("#login-form").classList.toggle("hidden", b.dataset.tab !== "login");
      $("#signup-form").classList.toggle("hidden", b.dataset.tab !== "signup");
    }));
    if (ref) $('[data-tab="signup"]').click();
    $("#login-form").onsubmit = (e) => {
      e.preventDefault();
      const f = new FormData(e.target);
      busy(e.submitter, async () => {
        try { await post("/api/auth/login", { login: f.get("login"), password: f.get("password") }); await afterAuth(); } catch (err) { fail(err); }
      });
    };
    $("#signup-form").onsubmit = (e) => {
      e.preventDefault();
      const f = new FormData(e.target);
      busy(e.submitter, async () => {
        try {
          await post("/api/auth/signup", { email: f.get("email"), username: f.get("username"), display_name: f.get("display_name"), password: f.get("password"), ref: ref || undefined });
          toast("환영합니다! 500 코인이 지급되었어요");
          await afterAuth();
        } catch (err) { fail(err); }
      });
    };
  }
  async function afterAuth() {
    await refreshMe();
    await applyTheme();
    location.hash = "#/dashboard";
    render();
  }
  async function applyTheme() {
    try {
      const s = await api("/api/me/settings");
      S.theme = s.theme; document.body.dataset.theme = s.theme;
    } catch (e) { /* 기본 테마 */ }
  }

  // ================= 대시보드 =================
  route(/^\/dashboard$/, async (v) => {
    const d = await api("/api/me/dashboard");
    const me = d.me, st = d.stats;
    const prevExp = (me.level - 1) ** 2 * 100, pct = Math.min(100, Math.round(((me.exp - prevExp) / Math.max(1, d.next_level_exp - prevExp)) * 100));
    v.innerHTML = `<div class="view stack">
      ${page(`안녕하세요, ${esc(me.display_name)}님`, "오늘도 우주를 탐험해 볼까요?")}
      <div class="grid g3">
        <div class="glass card tilt span2"><div class="row">
          ${avatarHTML(me.display_name, me.avatar_color, me.avatar_body, "lg", me.equipped)}
          <div class="grow"><h2>${esc(me.display_name)} ${me.title ? `<span class="chip c1">${esc(me.title)}</span>` : ""}</h2>
            <div class="muted small">@${esc(me.username)} · 레벨 ${me.level} · 경험치 ${num(me.exp)} / ${num(d.next_level_exp)}</div>
            <div class="bar" style="margin-top:.6rem"><i data-w="${pct}"></i></div></div>
        </div></div>
        <div class="glass card tilt"><div class="stat"><span class="ico">💰</span><span class="v">${num(me.balance)}</span><span class="l">보유 코인</span></div>
          <button class="btn sm ${d.daily_claimed ? "ghost" : "cyan"}" id="daily-btn" ${d.daily_claimed ? "disabled" : ""} style="margin-top:.6rem">${d.daily_claimed ? "오늘 출석 완료 ✓" : `출석 체크 +${d.daily_reward}`}</button></div>
      </div>
      <div class="grid g4">
        ${[["🪐", st.worlds_visited, "방문한 월드", "worlds"], ["🤝", st.friends, "친구", "friends"], ["📰", st.posts, "내 게시물", "feed"], ["🏅", st.achievements, "업적", "quests"]]
          .map(([i, n, l, h]) => `<a class="glass card tilt stat" href="#/${h}"><span class="ico">${i}</span><span class="v">${num(n)}</span><span class="l">${l}</span></a>`).join("")}
      </div>
      <div class="grid g2">
        <div class="glass card"><div class="row between"><h3>🎯 오늘의 퀘스트</h3><a href="#/quests" class="small">전체 보기</a></div>
          <div class="list">${d.quests.map((q) => questItem(q)).join("") || emptyBox("🎯", "퀘스트가 없습니다")}</div></div>
        <div class="glass card"><h3>📢 공지사항</h3>
          <div class="list">${d.announcements.map((a) => `<div class="item"><div class="grow"><div>${esc(a.title)}</div><div class="muted small">${esc(a.body)}</div><div class="dim">${timeAgo(a.created_at)}</div></div></div>`).join("") || emptyBox("📭", "아직 공지가 없습니다")}</div>
          <div class="divider"></div>
          <h3>🚀 바로 가기</h3>
          <div class="row"><a class="btn sm" href="#/ai">AI에게 묻기</a><a class="btn sm cyan" href="#/worlds/nova-prime">노바 프라임 입장</a><a class="btn sm ghost" href="#/games">게임 하기</a><a class="btn sm ghost" href="#/creator">작품 만들기</a></div></div>
      </div></div>`;
    const btn = $("#daily-btn");
    if (btn && !d.daily_claimed) btn.onclick = () => busy(btn, async () => {
      try { const r = await post("/api/wallet/daily"); toast(`출석 보상 ${r.amount} 코인!`); render(); refreshTop(); } catch (e) { fail(e); }
    });
    bindQuestClaims(v);
  }, "dashboard");

  function questItem(q) {
    const st = q.status;
    const action = st === "completed" ? `<button class="btn sm good" data-claim="${esc(q.code)}">보상 받기</button>`
      : st === "claimed" ? `<span class="chip good">완료 ✓</span>` : `<span class="chip">진행 중</span>`;
    return `<div class="item"><span>${q.is_daily ? "🔁" : "⭐"}</span><div class="grow"><div>${esc(q.title)}</div><div class="muted small">${esc(q.description || "")}${q.world_name ? ` · ${esc(q.world_name)}` : ""}</div>
      <div class="dim">보상 <span class="coin"></span> ${num(q.reward_coins)} · EXP ${num(q.reward_exp)}</div></div>${action}</div>`;
  }
  function bindQuestClaims(root) {
    $$("[data-claim]", root).forEach((b) => (b.onclick = () => busy(b, async () => {
      try { const r = await post(`/api/quests/${enc(b.dataset.claim)}/claim`); toast(`보상 ${r.coins} 코인 · EXP ${r.exp} 획득!`); await refreshMe(); render(); refreshTop(); } catch (e) { fail(e); }
    })));
  }

  // ================= AI =================
  route(/^\/ai(?:\/(\d+))?$/, async (v, cid) => {
    const [st, convs] = await Promise.all([api("/api/ai/status"), api("/api/ai/conversations")]);
    let mode = "chat";
    const current = cid ? Number(cid) : null;
    v.innerHTML = `<div class="view">
      ${page("OMNI AI", `Gemini 기반 통합 AI · 모델 <span class="chip c2">${esc(st.model)}</span> ${st.configured ? `<span class="chip good">연결됨</span>` : `<span class="chip warn">미설정</span>`}`,
        `<button class="btn sm ghost" id="mem-btn">🧠 AI 기억</button><button class="btn sm" id="new-conv">＋ 새 대화</button>`)}
      ${st.configured ? "" : `<div class="notice" style="margin-bottom:1rem">AI 키가 아직 설정되지 않았습니다. 관리자가 Render 환경변수 <span class="kbd">GEMINI_API_KEY</span>를 등록하면 바로 쓸 수 있습니다. 지금 메시지를 보내면 미설정 안내가 표시됩니다.</div>`}
      <div class="chat">
        <aside class="chat-side glass"><b>대화 기록</b><div class="list" id="conv-list">${convs.map((c) => `<a class="item ${c.id === current ? "on" : ""}" href="#/ai/${c.id}"><div class="grow"><div class="small">${esc(c.title)}</div><div class="dim">${timeAgo(c.updated_at)}</div></div></a>`).join("") || `<div class="dim">아직 대화가 없습니다</div>`}</div>
          <div class="divider"></div><b>프롬프트 라이브러리</b>
          <div class="list">${st.library.map((p, i) => `<button class="item small" data-lib="${i}" style="text-align:left;cursor:pointer;color:inherit">${esc(p.title)} <span class="chip">${esc(p.mode)}</span></button>`).join("")}</div>
        </aside>
        <section class="chat-main glass">
          <div class="modes">${[["chat", "💬 대화"], ["code", "💻 코드"], ["doc", "📄 문서"], ["game", "🎮 게임 제작"], ["study", "📚 학습"]].map(([k, l]) => `<button data-mode="${k}" class="${k === mode ? "on" : ""}">${l}</button>`).join("")}
            <span class="chip soon" title="확장 예정">🎙️ 음성 대화 · 준비 중</span><span class="chip soon">🖼️ 이미지 생성 · 준비 중</span></div>
          <div class="chat-log" id="chat-log">${current ? "" : `<div class="empty"><span class="big">🤖</span>무엇이든 물어보세요. 왼쪽 라이브러리에서 예시를 고를 수도 있어요.</div>`}</div>
          <form class="chat-input" id="chat-form"><textarea class="input" id="chat-text" placeholder="메시지 입력 (Enter 전송, Shift+Enter 줄바꿈)" rows="1" maxlength="8000"></textarea><button class="btn">전송</button></form>
        </section>
      </div></div>`;
    const log = $("#chat-log");
    const addMsg = (role, content) => {
      const d = document.createElement("div");
      d.className = `msg ${role}`; d.innerHTML = richText(content);
      log.appendChild(d); log.scrollTop = log.scrollHeight; return d;
    };
    if (current) {
      const msgs = await api(`/api/ai/conversations/${current}/messages`);
      log.innerHTML = msgs.length ? "" : `<div class="empty"><span class="big">✨</span>새 대화를 시작하세요.</div>`;
      msgs.forEach((m) => addMsg(m.role, m.content));
    }
    $$("[data-mode]", v).forEach((b) => (b.onclick = () => { mode = b.dataset.mode; $$("[data-mode]", v).forEach((x) => x.classList.toggle("on", x === b)); }));
    $$("[data-lib]", v).forEach((b) => (b.onclick = () => {
      const p = st.library[Number(b.dataset.lib)];
      mode = p.mode; $$("[data-mode]", v).forEach((x) => x.classList.toggle("on", x.dataset.mode === mode));
      $("#chat-text").value = p.prompt; $("#chat-text").focus();
    }));
    $("#new-conv").onclick = async () => { try { const c = await post("/api/ai/conversations", {}); location.hash = `#/ai/${c.id}`; } catch (e) { fail(e); } };
    $("#mem-btn").onclick = openMemories;
    const ta = $("#chat-text");
    ta.addEventListener("keydown", (e) => { if (e.key === "Enter" && !e.shiftKey && !e.isComposing) { e.preventDefault(); $("#chat-form").requestSubmit(); } });
    ta.addEventListener("input", () => { ta.style.height = "auto"; ta.style.height = Math.min(200, ta.scrollHeight) + "px"; });
    $("#chat-form").onsubmit = async (e) => {
      e.preventDefault();
      const text = ta.value.trim();
      if (!text) return;
      let id = current;
      try {
        if (!id) { const c = await post("/api/ai/conversations", {}); id = c.id; }
        if (log.querySelector(".empty")) log.innerHTML = "";
        addMsg("user", text); ta.value = "";
        const typing = document.createElement("div");
        typing.className = "msg assistant typing"; typing.innerHTML = "<span></span><span></span><span></span>";
        log.appendChild(typing); log.scrollTop = log.scrollHeight;
        try {
          const r = await post(`/api/ai/conversations/${id}/messages`, { content: text, mode });
          typing.remove(); addMsg("assistant", r.content);
          if (!current) history.replaceState(null, "", `#/ai/${id}`);
        } catch (err) {
          typing.remove();
          const w = addMsg("assistant", `⚠️ ${err.message}`); w.classList.add("notice");
          if (!current && id) history.replaceState(null, "", `#/ai/${id}`);
        }
      } catch (err) { fail(err); }
    };
  }, "ai");

  async function openMemories() {
    const list = await api("/api/ai/memories").catch((e) => { fail(e); return null; });
    if (!list) return;
    modal(`<h2>🧠 AI 개인 기억</h2><p class="muted small">여기에 적은 내용은 AI가 대답할 때 참고합니다. 언제든 지울 수 있어요.</p>
      <form id="mem-form" class="row"><input class="input grow" name="c" maxlength="500" placeholder="예: 나는 초등학교 선생님이야" required><button class="btn sm">추가</button></form>
      <div class="list" style="margin-top:1rem">${list.map((m) => `<div class="item"><div class="grow small">${esc(m.content)}</div><button class="btn sm ghost" data-mdel="${m.id}">삭제</button></div>`).join("") || `<div class="dim">저장된 기억이 없습니다</div>`}</div>
      <div class="row end" style="margin-top:1rem"><button class="btn ghost" data-close>닫기</button></div>`, (box) => {
      $("#mem-form", box).onsubmit = async (e) => { e.preventDefault(); try { await post("/api/ai/memories", { content: e.target.c.value }); openMemories(); } catch (err) { fail(err); } };
      $$("[data-mdel]", box).forEach((b) => (b.onclick = async () => { try { await del(`/api/ai/memories/${b.dataset.mdel}`); openMemories(); } catch (err) { fail(err); } }));
    });
  }

  // ================= 월드 =================
  route(/^\/worlds$/, async (v) => {
    const d = await api("/api/worlds");
    const official = d.items.filter((w) => w.is_official), mine = d.items.filter((w) => !w.is_official);
    const radii = [120, 175, 230, 285, 335];
    v.innerHTML = `<div class="view stack">
      ${page("OMNIVERSE WORLD", `행성을 골라 입장하세요 · 내 레벨 <b>${d.my_level}</b>`, `<button class="btn sm" id="new-world">＋ 내 월드 만들기</button>`)}
      <div class="galaxy glass" id="galaxy">
        <div class="galaxy-core"></div>
        <div class="orbit-plane">${radii.map((r) => `<div class="orbit-line" data-r="${r}"></div>`).join("")}</div>
        ${official.map((w, i) => `<a class="world-node ${w.locked ? "locked" : ""}" href="#/worlds/${enc(w.slug)}" data-i="${i}" title="${esc(w.name)}">
          ${planetHTML(w.color, 54 + i * 8)}${w.locked ? `<span class="lock">🔒</span>` : ""}
          <span class="name">${esc(w.name)}</span><span class="chip ${w.locked ? "" : "c2"}">${w.locked ? `Lv.${w.min_level}+` : `${num(w.members)}명`}</span></a>`).join("")}
      </div>
      <div class="grid auto">${official.map((w) => worldCard(w)).join("")}</div>
      <h2>🌱 사용자 제작 월드</h2>
      <div class="grid auto">${mine.map((w) => worldCard(w)).join("") || `<div class="glass card">${emptyBox("🌱", "아직 사용자 월드가 없습니다. 첫 번째 월드를 만들어 보세요!")}</div>`}</div>
    </div>`;
    // 궤도 배치 + 공전 애니메이션
    const g = $("#galaxy");
    $$(".orbit-line", g).forEach((o) => { const r = Number(o.dataset.r); o.style.width = o.style.height = r * 2 + "px"; });
    const nodes = $$(".world-node", g);
    const start = performance.now();
    let raf;
    const tick = (now) => {
      const W = g.clientWidth, H = g.clientHeight, scale = Math.min(1, W / 760);
      nodes.forEach((n) => {
        const i = Number(n.dataset.i), r = radii[i] * scale, a = (now - start) / (9000 + i * 5000) + i * 1.3;
        const x = Math.cos(a) * r, y = Math.sin(a) * r * 0.42;
        n.style.left = W / 2 + x + "px"; n.style.top = H / 2 + y + "px"; n.style.zIndex = String(Math.round(y + 400));
      });
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    S.stop = () => cancelAnimationFrame(raf);
    $("#new-world").onclick = () => modal(`<h2>🌱 새 월드 만들기</h2>
      <form id="w-form"><label class="field"><span>이름</span><input class="input" name="name" maxlength="30" required></label>
      <label class="field"><span>테마</span><select class="input" name="theme">${[["city", "네온 도시"], ["ocean", "바다"], ["forest", "숲"], ["volcano", "화산"], ["ice", "얼음"], ["desert", "사막"], ["nebula", "성운"]].map(([k, l]) => `<option value="${k}">${l}</option>`).join("")}</select></label>
      <label class="field"><span>행성 색</span><input class="input" type="color" name="color" value="#7c5cff"></label>
      <label class="field"><span>설명</span><textarea class="input" name="description" maxlength="300"></textarea></label>
      <div class="row end"><button type="button" class="btn ghost" data-close>취소</button><button class="btn">만들기</button></div></form>`, (box) => {
      $("#w-form", box).onsubmit = async (e) => {
        e.preventDefault(); const f = new FormData(e.target);
        try { const r = await post("/api/worlds", Object.fromEntries(f)); closeModal(); toast("월드가 만들어졌어요!"); location.hash = `#/worlds/${enc(r.slug)}`; } catch (err) { fail(err); }
      };
    });
  }, "worlds");

  function worldCard(w) {
    return `<a class="glass card tilt" href="#/worlds/${enc(w.slug)}"><div class="row">${planetHTML(w.color, 56, false)}
      <div class="grow"><h3>${esc(w.name)} ${w.locked ? "🔒" : ""}</h3><div class="muted small">${esc(w.description || "")}</div>
      <div class="row small" style="margin-top:.4rem"><span class="chip">${esc(w.theme)}</span><span class="chip">Lv.${w.min_level}+</span>${w.my_score != null ? `<span class="chip c2">내 점수 ${num(w.my_score)}</span>` : ""}${w.creator ? `<span class="chip">by @${esc(w.creator)}</span>` : ""}</div></div></div></a>`;
  }

  route(/^\/worlds\/([^/]+)$/, async (v, slug) => {
    const d = await api(`/api/worlds/${enc(slug)}`);
    const w = d.world;
    v.innerHTML = `<div class="view stack">
      <div class="world-hero glass">${planetHTML(w.color, 200)}
        <div><span class="chip c2">${esc(w.theme)}</span> ${w.is_official ? `<span class="chip c1">공식 월드</span>` : `<span class="chip">사용자 월드</span>`}
          <h1 class="grad" style="margin-top:.6rem">${esc(w.name)}</h1><p class="muted">${esc(w.description || "")}</p>
          <div class="row">${w.locked ? `<span class="chip warn">레벨 ${w.min_level} 이상 입장 가능</span>` :
            `<button class="btn" id="enter-btn">${d.membership ? "다시 입장" : "월드 입장"} 🚀</button>${d.membership ? `<a class="btn cyan" href="#/worlds/${enc(w.slug)}/explore">탐험 시작 ⚡</a>` : ""}`}
            <button class="btn ghost sm" id="report-world">신고</button></div>
          ${d.membership ? `<p class="dim">내 탐험 점수 ${num(d.membership.score)} · 마지막 방문 ${timeAgo(d.membership.last_visit_at)}</p>` : ""}</div></div>
      <div class="grid g2">
        <div class="glass card"><h3>🏆 월드 순위표</h3><div class="list">${d.leaderboard.map((r, i) => `<div class="item"><b>${i + 1}</b><div class="grow">${userLink(r.username, r.display_name)}</div><b>${num(r.score)}</b></div>`).join("") || emptyBox("🏆", "아직 기록이 없습니다")}</div></div>
        <div class="glass card"><h3>🎯 월드 퀘스트</h3><div class="list">${d.quests.map(questItem).join("") || emptyBox("🎯", "이 월드 전용 퀘스트는 준비 중입니다")}</div>
          <div class="divider"></div><h3>🐉 보스 콘텐츠 · 월드 이벤트</h3><span class="chip soon">PHASE 2에서 공개 예정</span></div>
      </div></div>`;
    const eb = $("#enter-btn");
    if (eb) eb.onclick = () => busy(eb, async () => {
      try { const r = await post(`/api/worlds/${enc(slug)}/enter`); toast(r.first_visit ? `${w.name}에 첫 착륙! EXP +20` : `${w.name}에 다시 왔어요`); location.hash = `#/worlds/${enc(slug)}/explore`; } catch (e) { fail(e); }
    });
    $("#report-world").onclick = () => reportBox("world", w.id);
    bindQuestClaims(v);
  }, "worlds");

  route(/^\/worlds\/([^/]+)\/explore$/, async (v, slug) => {
    const d = await api(`/api/worlds/${enc(slug)}`);
    const w = d.world;
    if (!d.membership) { location.hash = `#/worlds/${enc(slug)}`; return; }
    v.innerHTML = `<div class="view stack">${page(`${esc(w.name)} 탐험`, "에너지 구슬을 모으고 붉은 폭풍을 피하세요 · 클릭/터치 또는 방향키", `<a class="btn ghost sm" href="#/worlds/${enc(slug)}">← 월드로</a>`)}
      <div class="explore glass" id="stage"><div class="overlay" id="ov"><div class="planet-wrap">${planetHTML(w.color, 90, false)}</div><h2>준비되셨나요?</h2><p class="muted">45초 동안 최대 500 에너지를 모을 수 있어요</p><button class="btn" id="go">탐험 시작</button></div></div></div>`;
    const stage = $("#stage");
    const startGame = () => {
      $("#ov").remove();
      S.stop = window.OmniGames.explore(stage, w.color || "#7c5cff", async (score) => {
        S.stop = null;
        let msg = "";
        try { const r = await post(`/api/worlds/${enc(slug)}/score`, { score }); msg = `누적 탐험 점수 ${num(r.total)}`; await refreshMe(); } catch (e) { msg = e.message; }
        const ov = document.createElement("div"); ov.className = "overlay";
        ov.innerHTML = `<h2>⚡ ${num(score)} 에너지!</h2><p class="muted">${esc(msg)}</p><div class="row"><button class="btn" id="again">다시 탐험</button><a class="btn ghost" href="#/worlds/${enc(slug)}">월드로</a></div>`;
        stage.appendChild(ov);
        $("#again").onclick = () => { ov.remove(); stage.querySelector("canvas").remove(); startGame(); };
      });
    };
    $("#go").onclick = startGame;
  }, "worlds");

  // ================= 피드 / 소셜 =================
  function postHTML(p) {
    const mine = p.author_id === S.user.id, staff = ["admin", "moderator"].includes(S.user.role);
    return `<article class="glass post" data-post="${p.id}">
      <div class="post-head">${avatarHTML(p.author_name || p.author_username, "", "")}<div class="grow">${userLink(p.author_username, p.author_name)}
        <div class="dim">${timeAgo(p.created_at)} · ${{ public: "🌐 전체", friends: "🤝 친구", private: "🔒 나만" }[p.visibility] || ""}${p.community_name ? ` · <a href="#/c/${enc(p.community_slug)}">${esc(p.community_name)}</a>` : ""}</div></div></div>
      <div class="post-body">${esc(p.content)}</div>
      ${p.image_url ? `<img class="post-img" src="${esc(p.image_url)}" alt="첨부 이미지" loading="lazy" referrerpolicy="no-referrer">` : ""}
      <div class="post-actions">
        <button data-like class="${p.liked ? "on" : ""}">❤ <span>${num(p.like_count)}</span></button>
        <button data-cmt>💬 ${num(p.comment_count)}</button>
        <button data-share>↗ 공유</button>
        ${mine || staff ? `<button data-del>🗑 삭제</button>` : `<button data-rep>🚩 신고</button>`}
      </div><div class="comments hidden"></div></article>`;
  }
  function bindPosts(root) {
    $$("[data-post]", root).forEach((art) => {
      const id = art.dataset.post;
      const likeBtn = $("[data-like]", art);
      likeBtn.onclick = async () => {
        try { const on = likeBtn.classList.contains("on"); const r = on ? await del(`/api/posts/${id}/like`) : await post(`/api/posts/${id}/like`);
          likeBtn.classList.toggle("on", r.liked); $("span", likeBtn).textContent = num(r.like_count); } catch (e) { fail(e); }
      };
      $("[data-cmt]", art).onclick = () => loadComments(art, id);
      $("[data-share]", art).onclick = async () => {
        const url = `${location.origin}/#/feed`;
        try { if (navigator.share) await navigator.share({ title: "OMNIVERSE X", text: $(".post-body", art).textContent.slice(0, 100), url }); else { await navigator.clipboard.writeText(url); toast("링크를 복사했어요"); } } catch (e) { /* 취소 */ }
      };
      const d = $("[data-del]", art);
      if (d) d.onclick = async () => { if (await confirmBox("이 게시물을 삭제할까요?", "삭제", true)) { try { await del(`/api/posts/${id}`); art.remove(); toast("삭제했습니다"); } catch (e) { fail(e); } } };
      const rp = $("[data-rep]", art);
      if (rp) rp.onclick = () => reportBox("post", Number(id));
    });
  }
  async function loadComments(art, id) {
    const box = $(".comments", art);
    box.classList.remove("hidden");
    try {
      const list = await api(`/api/posts/${id}/comments`);
      box.innerHTML = list.map((c) => `<div class="comment">${userLink(c.username, c.display_name)} <span>${esc(c.content)}</span> <span class="dim">${timeAgo(c.created_at)}</span>
        ${c.author_id === S.user.id ? `<button class="btn sm ghost" data-cdel="${c.id}">삭제</button>` : ""}</div>`).join("") +
        `<form class="row" data-cform><input class="input grow" name="c" maxlength="1000" placeholder="댓글 달기" required><button class="btn sm">등록</button></form>`;
      $("[data-cform]", box).onsubmit = async (e) => { e.preventDefault(); try { await post(`/api/posts/${id}/comments`, { content: e.target.c.value }); loadComments(art, id); } catch (err) { fail(err); } };
      $$("[data-cdel]", box).forEach((b) => (b.onclick = async () => { try { await del(`/api/comments/${b.dataset.cdel}`); loadComments(art, id); } catch (err) { fail(err); } }));
    } catch (e) { fail(e); }
  }
  function reportBox(type, id) {
    modal(`<h2>🚩 신고하기</h2><form id="rep-form"><label class="field"><span>사유</span><textarea class="input" name="reason" maxlength="1000" required placeholder="어떤 문제가 있나요?"></textarea></label>
      <div class="row end"><button type="button" class="btn ghost" data-close>취소</button><button class="btn danger">신고</button></div></form>`, (box) => {
      $("#rep-form", box).onsubmit = async (e) => { e.preventDefault(); try { await post("/api/reports", { target_type: type, target_id: id, reason: e.target.reason.value }); closeModal(); toast("신고가 접수되었습니다. 운영진이 확인할게요"); } catch (err) { fail(err); } };
    });
  }
  function composerHTML(communityId) {
    return `<form class="glass card" id="composer"><textarea class="input" name="content" maxlength="5000" placeholder="무슨 일이 있었나요? 우주에 공유해 보세요" required></textarea>
      <div class="row" style="margin-top:.6rem"><input class="input grow" name="image_url" placeholder="이미지 주소 (https://, 선택)" maxlength="500">
      ${communityId ? "" : `<select class="input" name="visibility" style="width:auto"><option value="public">🌐 전체 공개</option><option value="friends">🤝 친구 공개</option><option value="private">🔒 나만 보기</option></select>`}
      <button class="btn">게시</button></div></form>`;
  }
  function bindComposer(root, communityId) {
    $("#composer", root).onsubmit = (e) => {
      e.preventDefault(); const f = new FormData(e.target);
      busy(e.submitter, async () => {
        try {
          await post("/api/posts", { content: f.get("content"), image_url: f.get("image_url") || undefined, visibility: f.get("visibility") || "public", community_id: communityId || undefined });
          toast("게시했습니다"); render();
        } catch (err) { fail(err); }
      });
    };
  }

  route(/^\/feed(?:\/(all|following|friends))?$/, async (v, scope = "all") => {
    const d = await api(`/api/feed?scope=${scope}`);
    v.innerHTML = `<div class="view stack" style="max-width:760px;margin:0 auto">${page("활동 피드", "친구와 우주 탐험가들의 소식")}
      ${composerHTML()}
      <div class="subtabs">${[["all", "전체"], ["following", "팔로잉"], ["friends", "친구"]].map(([k, l]) => `<a href="#/feed/${k}" class="${k === scope ? "on" : ""}">${l}</a>`).join("")}</div>
      <div class="stack" id="posts">${d.items.map(postHTML).join("") || `<div class="glass card">${emptyBox("📰", "아직 게시물이 없습니다. 첫 글을 남겨 보세요!")}</div>`}</div>
      ${d.items.length >= 20 ? `<button class="btn ghost" id="more">더 보기</button>` : ""}</div>`;
    bindComposer(v); bindPosts(v);
    let offset = 20;
    const more = $("#more");
    if (more) more.onclick = () => busy(more, async () => {
      const r = await api(`/api/feed?scope=${scope}&offset=${offset}`); offset += 20;
      const tmp = document.createElement("div"); tmp.innerHTML = r.items.map(postHTML).join(""); paint(tmp); bindPosts(tmp);
      $("#posts").append(...tmp.children); if (r.items.length < 20) more.remove();
    });
  }, "feed");

  route(/^\/communities$/, async (v) => {
    const list = await api("/api/communities");
    v.innerHTML = `<div class="view stack">${page("커뮤니티", "관심사가 같은 탐험가 모임", `<button class="btn sm" id="new-c">＋ 커뮤니티 만들기</button>`)}
      <div class="grid auto">${list.map((c) => `<a class="glass card tilt" href="#/c/${enc(c.slug)}"><h3>👥 ${esc(c.name)}</h3><p class="muted small">${esc(c.description || "")}</p><div class="row"><span class="chip">${num(c.members)}명</span>${c.joined ? `<span class="chip good">가입함</span>` : ""}</div></a>`).join("") || `<div class="glass card">${emptyBox("👥", "아직 커뮤니티가 없습니다")}</div>`}</div>
      <div class="glass card"><h3>🛡️ 클랜·길드</h3><span class="chip soon">PHASE 4에서 공개 예정</span></div></div>`;
    $("#new-c").onclick = () => modal(`<h2>👥 커뮤니티 만들기</h2><form id="c-form">
      <label class="field"><span>이름</span><input class="input" name="name" maxlength="40" required></label>
      <label class="field"><span>주소 (영문 소문자·숫자·-)</span><input class="input" name="slug" maxlength="40" pattern="[a-z0-9-]{2,40}" required></label>
      <label class="field"><span>소개</span><textarea class="input" name="description" maxlength="300"></textarea></label>
      <div class="row end"><button type="button" class="btn ghost" data-close>취소</button><button class="btn">만들기</button></div></form>`, (box) => {
      $("#c-form", box).onsubmit = async (e) => { e.preventDefault(); try { const r = await post("/api/communities", Object.fromEntries(new FormData(e.target))); closeModal(); location.hash = `#/c/${enc(r.slug)}`; } catch (err) { fail(err); } };
    });
  }, "communities");

  route(/^\/c\/([^/]+)$/, async (v, slug) => {
    const d = await api(`/api/communities/${enc(slug)}`);
    const c = d.community;
    v.innerHTML = `<div class="view stack" style="max-width:760px;margin:0 auto">
      ${page(`👥 ${esc(c.name)}`, `${esc(c.description || "")} · 멤버 ${num(c.members)}명`, c.joined ? `<button class="btn ghost sm" id="leave">탈퇴</button>` : `<button class="btn sm" id="join">가입하기</button>`)}
      ${c.joined ? composerHTML(c.id) : `<div class="notice info">가입하면 글을 쓸 수 있어요.</div>`}
      <div class="stack">${d.posts.map(postHTML).join("") || `<div class="glass card">${emptyBox("📝", "아직 글이 없습니다")}</div>`}</div></div>`;
    if (c.joined) bindComposer(v, c.id);
    bindPosts(v);
    const j = $("#join"), l = $("#leave");
    if (j) j.onclick = async () => { try { await post(`/api/communities/${enc(slug)}/join`); render(); } catch (e) { fail(e); } };
    if (l) l.onclick = async () => { try { await post(`/api/communities/${enc(slug)}/leave`); render(); } catch (e) { fail(e); } };
  }, "communities");

  // ================= 친구 =================
  route(/^\/friends$/, async (v) => {
    const d = await api("/api/friends");
    const invite = `${location.origin}/#/?ref=${enc(S.user.username)}`;
    const row = (f, actions) => `<div class="item">${avatarHTML(f.display_name, "", "")}<div class="grow">${userLink(f.username, f.display_name)}<div class="dim">Lv.${f.level} · ${timeAgo(f.created_at)}</div></div>${actions}</div>`;
    v.innerHTML = `<div class="view stack">${page("친구", `친구 ${d.friends.length}명`)}
      <div class="grid g2">
        <div class="glass card"><h3>➕ 친구 추가</h3><form id="add-f" class="row"><input class="input grow" name="u" placeholder="아이디 입력" required maxlength="20"><button class="btn">요청 보내기</button></form>
          <div class="divider"></div><h3>💌 친구 초대</h3><p class="muted small">이 링크로 가입하면 자동으로 친구 요청이 와요.</p>
          <div class="row"><input class="input grow mono small" value="${esc(invite)}" readonly id="inv"><button class="btn sm ghost" id="copy-inv">복사</button></div></div>
        <div class="glass card"><h3>📥 받은 요청 <span class="chip">${d.incoming.length}</span></h3><div class="list">${d.incoming.map((f) => row(f, `<button class="btn sm good" data-acc="${f.id}">수락</button><button class="btn sm ghost" data-dec="${f.id}">거절</button>`)).join("") || `<div class="dim">받은 요청이 없습니다</div>`}</div>
          <div class="divider"></div><h3>📤 보낸 요청</h3><div class="list">${d.outgoing.map((f) => row(f, `<button class="btn sm ghost" data-rm="${f.id}">취소</button>`)).join("") || `<div class="dim">보낸 요청이 없습니다</div>`}</div></div>
      </div>
      <div class="glass card"><h3>🤝 내 친구</h3><div class="grid g2">${d.friends.map((f) => row(f, `<button class="btn sm" data-dm="${esc(f.username)}">메시지</button><button class="btn sm ghost" data-rm="${f.id}">끊기</button>`)).join("") || emptyBox("🤝", "아직 친구가 없습니다. 아이디로 친구를 찾아보세요")}</div></div></div>`;
    $("#add-f").onsubmit = async (e) => { e.preventDefault(); try { const r = await post("/api/friends/request", { username: e.target.u.value.trim() }); toast(r.state === "friends" ? "친구가 되었어요!" : "친구 요청을 보냈어요"); render(); } catch (err) { fail(err); } };
    $("#copy-inv").onclick = async () => { try { await navigator.clipboard.writeText(invite); toast("초대 링크를 복사했어요"); } catch (e) { $("#inv").select(); } };
    $$("[data-acc]", v).forEach((b) => (b.onclick = async () => { try { await post(`/api/friends/${b.dataset.acc}/accept`); toast("친구가 되었어요!"); render(); } catch (e) { fail(e); } }));
    $$("[data-dec]", v).forEach((b) => (b.onclick = async () => { try { await post(`/api/friends/${b.dataset.dec}/decline`); render(); } catch (e) { fail(e); } }));
    $$("[data-rm]", v).forEach((b) => (b.onclick = async () => { if (await confirmBox("정말 진행할까요?")) { try { await del(`/api/friends/${b.dataset.rm}`); render(); } catch (e) { fail(e); } } }));
    $$("[data-dm]", v).forEach((b) => (b.onclick = () => startDM(b.dataset.dm)));
  }, "friends");

  async function startDM(username) {
    try { const r = await post("/api/dm/start", { username }); location.hash = `#/messages/${r.id}`; } catch (e) { fail(e); }
  }

  // ================= 메시지 =================
  route(/^\/messages(?:\/(\d+))?$/, async (v, cid) => {
    const list = await api("/api/dm");
    v.innerHTML = `<div class="view">${page("메시지", `1:1 대화 · <span class="chip soon">실시간 WebSocket 준비 중 · 지금은 4초마다 새로고침</span>`)}
      <div class="chat"><aside class="chat-side glass"><form id="dm-new" class="row"><input class="input grow" name="u" placeholder="아이디로 대화 시작" maxlength="20" required><button class="btn sm">시작</button></form>
        <div class="list">${list.map((c) => `<a class="item ${String(c.id) === cid ? "on" : ""}" href="#/messages/${c.id}"><div class="grow"><div class="small">${esc(c.display_name)} <span class="dim">@${esc(c.username)}</span></div><div class="dim">${esc((c.last_message || "").slice(0, 30))}</div></div>${c.unread ? `<span class="chip c1">${c.unread}</span>` : ""}</a>`).join("") || `<div class="dim">대화가 없습니다</div>`}</div></aside>
      <section class="chat-main glass">${cid ? `<div class="row" style="padding:.9rem 1rem;border-bottom:1px solid rgba(255,255,255,.07)" id="dm-head"></div><div class="chat-log" id="dm-log"></div>
        <form class="chat-input" id="dm-form"><textarea class="input" id="dm-text" rows="1" maxlength="2000" placeholder="메시지 입력"></textarea><button class="btn">전송</button></form>` : emptyBox("💬", "왼쪽에서 대화를 고르거나 새 대화를 시작하세요")}</section></div></div>`;
    $("#dm-new").onsubmit = (e) => { e.preventDefault(); startDM(e.target.u.value.trim()); };
    if (!cid) return;
    let last = 0;
    const log = $("#dm-log");
    const load = async () => {
      const r = await api(`/api/dm/${cid}/messages?after=${last}`);
      if (!last) $("#dm-head").innerHTML = `${avatarHTML(r.other.display_name, "", "")} ${userLink(r.other.username, r.other.display_name)}`, paint($("#dm-head"));
      if (!last && !r.items.length) log.innerHTML = emptyBox("👋", "첫 인사를 건네 보세요");
      r.items.forEach((m) => {
        const e0 = log.querySelector(".empty"); if (e0) e0.remove();
        const d = document.createElement("div");
        d.className = `msg ${m.sender_id === S.user.id ? "user" : "assistant"}`;
        d.textContent = m.content; d.title = fmt(m.created_at);
        log.appendChild(d); last = Math.max(last, m.id);
      });
      if (r.items.length) log.scrollTop = log.scrollHeight;
    };
    await load();
    S.timers.push(setInterval(() => load().catch(() => {}), 4000));
    const ta = $("#dm-text");
    ta.addEventListener("keydown", (e) => { if (e.key === "Enter" && !e.shiftKey && !e.isComposing) { e.preventDefault(); $("#dm-form").requestSubmit(); } });
    $("#dm-form").onsubmit = async (e) => { e.preventDefault(); const t = ta.value.trim(); if (!t) return; try { await post(`/api/dm/${cid}/messages`, { content: t }); ta.value = ""; await load(); } catch (err) { fail(err); } };
  }, "messages");

  // ================= 프로필 =================
  route(/^\/u\/([^/]+)$/, async (v, username) => {
    const d = await api(`/api/users/${enc(username)}`);
    const u = d.user;
    if (d.blocked) {
      v.innerHTML = `<div class="view glass card">${emptyBox("🚫", d.i_blocked ? `${u.display_name}님을 차단했습니다.` : "이 프로필을 볼 수 없습니다.")}${d.i_blocked ? `<div class="center"><button class="btn ghost" id="unblock">차단 해제</button></div>` : ""}</div>`;
      const ub = $("#unblock"); if (ub) ub.onclick = async () => { try { await del(`/api/block/${enc(username)}`); render(); } catch (e) { fail(e); } };
      return;
    }
    const fs = d.friend_state;
    const fbtn = d.is_self ? `<a class="btn" href="#/settings">프로필 편집</a><a class="btn ghost" href="#/avatar">아바타 꾸미기</a>`
      : `${fs === "friends" ? `<span class="chip good">친구</span>` : fs === "outgoing" ? `<span class="chip">요청 보냄</span>` : fs === "incoming" ? `<button class="btn good" id="f-acc">친구 수락</button>` : `<button class="btn" id="f-req">친구 요청</button>`}
         <button class="btn ${d.following ? "ghost" : "cyan"}" id="follow">${d.following ? "팔로잉 ✓" : "팔로우"}</button>
         <button class="btn ghost" id="dm">메시지</button><button class="btn ghost sm" id="block">차단</button><button class="btn ghost sm" id="rep">신고</button>`;
    v.innerHTML = `<div class="view stack">
      <div class="glass card world-hero">${avatarHTML(u.display_name, u.avatar_color, u.avatar_body, "xl", u.equipped)}
        <div><h1 class="grad">${esc(u.display_name)}</h1><div class="muted">@${esc(u.username)} · Lv.${u.level} ${u.title ? `<span class="chip c1">${esc(u.title)}</span>` : ""} ${u.is_public ? "" : `<span class="chip">🔒 비공개 프로필</span>`}</div>
          <p>${esc(u.bio || "")}</p>
          <div class="row"><span class="chip">팔로워 ${num(u.followers)}</span><span class="chip">팔로잉 ${num(u.following)}</span><span class="chip">친구 ${num(u.friends)}</span><span class="chip">가입 ${new Date(u.created_at).toLocaleDateString("ko-KR")}</span></div>
          <div class="row" style="margin-top:1rem">${fbtn}</div></div></div>
      ${d.limited ? `<div class="glass card">${emptyBox("🔒", "비공개 프로필입니다. 친구가 되면 볼 수 있어요.")}</div>` : `
      <div class="grid g2"><div class="glass card"><h3>🏅 업적·배지</h3><div class="row">${(d.achievements || []).map((a) => `<span class="chip c1" title="${esc(fmt(a.earned_at))}">${esc(a.icon || "🏅")} ${esc(a.title)}</span>`).join("") || `<span class="dim">아직 업적이 없습니다</span>`}</div></div>
        <div class="glass card"><h3>🪐 방문한 월드</h3><div class="list">${(d.worlds || []).map((w) => `<a class="item" href="#/worlds/${enc(w.slug)}">${planetHTML(w.color, 28, false)}<div class="grow">${esc(w.name)}</div><b>${num(w.score)}</b></a>`).join("") || `<span class="dim">아직 없습니다</span>`}</div></div></div>
      <h2>📰 게시물</h2><div class="stack" style="max-width:760px">${(d.posts || []).map(postHTML).join("") || `<div class="glass card">${emptyBox("📝", "게시물이 없습니다")}</div>`}</div>`}</div>`;
    bindPosts(v);
    const on = (id, fn) => { const el = $(id); if (el) el.onclick = fn; };
    on("#f-req", async () => { try { await post("/api/friends/request", { username }); toast("친구 요청을 보냈어요"); render(); } catch (e) { fail(e); } });
    on("#f-acc", async () => { try { await post(`/api/friends/${d.friendship_id}/accept`); toast("친구가 되었어요!"); render(); } catch (e) { fail(e); } });
    on("#follow", async () => { try { d.following ? await del(`/api/follow/${enc(username)}`) : await post(`/api/follow/${enc(username)}`); render(); } catch (e) { fail(e); } });
    on("#dm", () => startDM(username));
    on("#block", async () => { if (await confirmBox(`${u.display_name}님을 차단할까요? 친구·팔로우가 해제됩니다.`, "차단", true)) { try { await post(`/api/block/${enc(username)}`); render(); } catch (e) { fail(e); } } });
    on("#rep", () => reportBox("user", u.id));
  }, "");

  // ================= 게임 =================
  const GAME_ART = { "star-catcher": ["⭐", "#fbbf24"], "memory-orbit": ["🃏", "#a78bfa"], "type-warp": ["⌨️", "#22d3ee"] };
  route(/^\/games$/, async (v) => {
    const d = await api("/api/games");
    v.innerHTML = `<div class="view stack">${page("GAME CENTER", "공식 게임과 사용자 제작 게임", `<a class="btn sm" href="#/creator">🛠️ 게임 만들기</a>`)}
      <div class="grid g3">${d.official.map((g) => `<a class="glass game-card tilt" href="#/games/${enc(g.slug)}"><div class="game-art" data-gc="${(GAME_ART[g.slug] || ["", "#22d3ee"])[1]}">${(GAME_ART[g.slug] || ["🎮"])[0]}</div>
        <div class="row between"><h3>${esc(g.title)}</h3>${g.favorite ? "⭐" : ""}</div><div class="muted small">${esc(g.description)}</div>
        <div class="row small"><span class="chip">${esc(g.category)}</span><span class="chip">플레이 ${num(g.play_count)}</span>${g.my_best != null ? `<span class="chip c2">내 최고 ${num(g.my_best)}</span>` : ""}</div></a>`).join("")}</div>
      <h2>🧑‍🎨 사용자 제작 게임</h2>
      <div class="grid auto">${d.community.map((p) => `<a class="glass card tilt" href="#/creator/${p.id}"><h3>🎮 ${esc(p.title)}</h3><div class="muted small">${esc(p.description || "")}</div>
        <div class="row small"><span class="chip">by @${esc(p.creator)}</span><span class="chip">v${p.version}</span><span class="stars">${p.rating_count ? "★ " + (p.rating_sum / p.rating_count).toFixed(1) : "평가 없음"}</span></div></a>`).join("") || `<div class="glass card">${emptyBox("🎮", "아직 공개된 사용자 게임이 없습니다")}</div>`}</div>
      <div class="glass card"><h3>👾 멀티플레이</h3><span class="chip soon">PHASE 2에서 공개 예정</span></div></div>`;
    paint(v);
  }, "games");

  route(/^\/games\/([^/]+)$/, async (v, slug) => {
    const d = await api(`/api/games/${enc(slug)}`);
    const g = d.game;
    const engine = window.OmniGames[slug];
    v.innerHTML = `<div class="view stack">${page(`${(GAME_ART[slug] || ["🎮"])[0]} ${esc(g.title)}`, esc(g.description), `<button class="btn sm ghost" id="fav">즐겨찾기</button><a class="btn sm ghost" href="#/games">← 목록</a>`)}
      <div class="grid g3"><div class="span2"><div class="game-stage glass" id="stage"><div class="overlay" id="ov"><h2>${esc(g.title)}</h2>
        <p class="muted">${slug === "star-catcher" ? "마우스/터치나 ←→ 키로 우주선을 움직여 별을 모으세요. 운석을 3번 맞으면 끝!" : slug === "memory-orbit" ? "같은 행성 카드 두 장을 찾으세요. 적게 뒤집을수록 점수가 높아요." : "나오는 단어를 빠르게 입력하세요. 연속으로 맞히면 콤보!"}</p>
        ${engine ? `<button class="btn" id="play">게임 시작</button>` : `<span class="chip soon">준비 중</span>`}</div></div></div>
        <div class="glass card"><h3>🏆 랭킹</h3><p class="dim">내 최고 점수: <b>${d.my_best != null ? num(d.my_best) : "-"}</b></p>
          <div class="list" id="board">${boardHTML(d.leaderboard)}</div></div></div></div>`;
    $("#fav").onclick = async () => { try { await post(`/api/games/${enc(slug)}/favorite`); toast("즐겨찾기에 추가했어요"); } catch (e) { fail(e); } };
    const stage = $("#stage");
    const play = () => {
      $$(".overlay, canvas, .mem-grid, .card, .center", stage).forEach((n) => n.remove());
      S.stop = engine(stage, async (score) => {
        S.stop = null;
        let msg = "";
        try { const r = await post(`/api/games/${enc(slug)}/scores`, { score }); msg = `최고 기록 ${num(r.best)} · 현재 ${r.rank}위`; const b = await api(`/api/games/${enc(slug)}`); $("#board").innerHTML = boardHTML(b.leaderboard); }
        catch (e) { msg = e.message; }
        const ov = document.createElement("div"); ov.className = "overlay";
        ov.innerHTML = `<h2>🎉 ${num(score)}점!</h2><p class="muted">${esc(msg)}</p><button class="btn" id="again">다시 하기</button>`;
        stage.appendChild(ov); $("#again").onclick = play;
      });
    };
    const pb = $("#play"); if (pb) pb.onclick = play;
  }, "games");
  const boardHTML = (rows) => rows.map((r, i) => `<div class="item"><b>${["🥇", "🥈", "🥉"][i] || i + 1}</b><div class="grow">${userLink(r.username, r.display_name)}</div><b>${num(r.score)}</b></div>`).join("") || emptyBox("🏆", "첫 기록의 주인공이 되어 보세요");

  // ================= 지갑 / 상점 / 아바타 =================
  const TX_LABEL = { daily_reward: "출석 보상", quest_reward: "퀘스트 보상", event_reward: "업적·이벤트 보상", purchase: "상점 구매", trade_in: "받은 코인", trade_out: "보낸 코인", admin_adjust: "관리자 조정", signup_bonus: "가입 보너스" };
  route(/^\/wallet$/, async (v) => {
    const w = await api("/api/wallet?limit=50");
    v.innerHTML = `<div class="view stack">${page("OMNI 지갑", "플랫폼 통합 가상 화폐 · 실제 현금 결제·환전은 지원하지 않습니다")}
      <div class="glass wallet-hero"><div class="big-coin">O</div><div class="grow"><div class="muted">보유 코인</div><div class="big">${num(w.balance)}</div>
        ${w.frozen ? `<span class="chip bad">지갑 동결됨</span>` : `<span class="chip good">정상</span>`} <span class="chip">오늘 송금 ${num(w.sent_today)} / ${num(w.daily_limit)}</span></div>
        <button class="btn ${w.daily_claimed ? "ghost" : "cyan"}" id="daily" ${w.daily_claimed ? "disabled" : ""}>${w.daily_claimed ? "오늘 출석 완료 ✓" : `출석 체크 +${w.daily_reward}`}</button></div>
      <div class="grid g2"><div class="glass card"><h3>💸 코인 보내기</h3>
        <form id="tx-form"><label class="field"><span>받는 사람 아이디</span><input class="input" name="to" required maxlength="20"></label>
        <label class="field"><span>금액</span><input class="input" name="amount" type="number" min="1" max="1000000" required></label>
        <label class="field"><span>메모</span><input class="input" name="memo" maxlength="100" placeholder="선물이야!"></label>
        <button class="btn block">보내기</button><p class="dim">부정 거래 방지를 위해 하루 ${num(w.daily_limit)} 코인까지 보낼 수 있어요.</p></form>
        <div class="divider"></div><h3>🔁 아이템 직거래</h3><span class="chip soon">PHASE 5 통합 경제에서 공개 예정</span></div>
      <div class="glass card"><h3>📜 거래 기록</h3><div class="table-wrap"><table class="t"><thead><tr><th>일시</th><th>내용</th><th>금액</th><th>잔액</th></tr></thead><tbody>
        ${w.transactions.map((t) => `<tr><td class="nowrap dim">${fmt(t.created_at)}</td><td>${esc(TX_LABEL[t.kind] || t.kind)}${t.counterparty ? ` <span class="dim">@${esc(t.counterparty)}</span>` : ""}<div class="dim">${esc(t.memo || "")}</div></td>
          <td class="tx-amt ${t.amount > 0 ? "plus" : "minus"}">${t.amount > 0 ? "+" : ""}${num(t.amount)}</td><td>${num(t.balance_after)}</td></tr>`).join("")}</tbody></table></div></div></div></div>`;
    const db = $("#daily");
    if (!w.daily_claimed) db.onclick = () => busy(db, async () => { try { const r = await post("/api/wallet/daily"); toast(`출석 보상 ${r.amount} 코인!`); render(); refreshTop(); } catch (e) { fail(e); } });
    $("#tx-form").onsubmit = async (e) => {
      e.preventDefault(); const f = new FormData(e.target);
      const amount = Number(f.get("amount"));
      if (!(await confirmBox(`@${f.get("to")}님에게 ${num(amount)} 코인을 보낼까요?`, "보내기"))) return;
      try { await post("/api/wallet/transfer", { to: f.get("to").trim(), amount, memo: f.get("memo") }); toast("코인을 보냈어요"); render(); refreshTop(); } catch (err) { fail(err); }
    };
  }, "wallet");

  route(/^\/shop$/, async (v) => {
    const [items, inv] = await Promise.all([api("/api/shop/items"), api("/api/inventory")]);
    const card = (i) => `<div class="glass item-card tilt rarity-${esc(i.rarity)}"><div class="item-art">${ITEM_ICON[i.code] || CAT_ICON[i.category] || "✦"}</div>
      <div class="row between"><h3>${esc(i.name)}</h3><span class="chip">${esc(i.rarity)}</span></div><div class="muted small">${esc(i.description || "")}</div>
      <div class="row between"><b><span class="coin"></span> ${num(i.price)}</b>${i.category === "avatar" && i.owned ? `<span class="chip good">보유 중</span>` : `<button class="btn sm" data-buy="${esc(i.code)}">구매${i.owned ? ` (${i.owned}개 보유)` : ""}</button>`}</div></div>`;
    v.innerHTML = `<div class="view stack">${page("아이템 상점", `보유 코인 <b>${num(S.balance)}</b>`)}
      <div class="grid auto">${items.map(card).join("")}</div>
      <div class="glass card"><h3>🎒 내 인벤토리</h3><div class="grid auto">${inv.map((i) => `<div class="item"><span class="big">${ITEM_ICON[i.code] || CAT_ICON[i.category] || "✦"}</span><div class="grow"><div>${esc(i.name)}</div><div class="dim">${esc(i.category)} · ${i.quantity}개</div></div></div>`).join("") || emptyBox("🎒", "비어 있습니다")}</div></div>
      <div class="glass card"><h3>🎟️ 시즌 패스</h3><span class="chip soon">PHASE 2에서 공개 예정</span></div></div>`;
    $$("[data-buy]", v).forEach((b) => (b.onclick = async () => {
      if (!(await confirmBox("이 아이템을 구매할까요?", "구매"))) return;
      try { const r = await post("/api/shop/buy", { code: b.dataset.buy }); S.balance = r.balance; toast("구매 완료!"); render(); refreshTop(); } catch (e) { fail(e); }
    }));
  }, "shop");

  route(/^\/avatar$/, async (v) => {
    const d = await api("/api/avatar");
    const av = d.avatar, eq = new Set((av.equipped && av.equipped.items) || []);
    v.innerHTML = `<div class="view stack">${page("아바타 커스터마이징", "모습과 색을 고르고 아이템을 장착하세요")}
      <div class="grid g2"><div class="glass card center" id="preview-box"><div style="display:grid;place-items:center;min-height:240px">${avatarHTML(S.user.display_name, av.color, av.body, "xl", av.equipped)}</div><h2>${esc(S.user.display_name)}</h2></div>
      <form class="glass card" id="av-form"><label class="field"><span>모습</span><select class="input" name="body">${d.bodies.map((b) => `<option value="${b}" ${b === av.body ? "selected" : ""}>${{ default: "기본 구체", astronaut: "🧑‍🚀 우주비행사", android: "🤖 안드로이드", spirit: "👻 성운 정령" }[b]}</option>`).join("")}</select></label>
        <label class="field"><span>색상</span><input class="input" type="color" name="color" value="${esc(av.color)}"></label>
        <div class="field"><span>장착 아이템</span>${d.owned.map((i) => `<label class="item"><input type="checkbox" name="eq" value="${esc(i.code)}" ${eq.has(i.code) ? "checked" : ""}> ${ITEM_ICON[i.code] || "✦"} ${esc(i.name)} <span class="chip">${esc(i.rarity)}</span></label>`).join("") || `<span class="dim">아바타 아이템이 없습니다. <a href="#/shop">상점</a>에서 구매하세요.</span>`}</div>
        <button class="btn block">저장</button></form></div></div>`;
    const form = $("#av-form");
    const preview = () => {
      const f = new FormData(form);
      $("#preview-box").firstElementChild.innerHTML = avatarHTML(S.user.display_name, f.get("color"), f.get("body"), "xl", { items: f.getAll("eq") });
      paint($("#preview-box"));
    };
    form.oninput = preview;
    form.onsubmit = async (e) => {
      e.preventDefault(); const f = new FormData(form);
      try { await patch("/api/avatar", { body: f.get("body"), color: f.get("color"), equipped: f.getAll("eq") }); toast("아바타를 저장했어요"); } catch (err) { fail(err); }
    };
  }, "avatar");

  // ================= 퀘스트 / 업적 / 랭킹 =================
  route(/^\/quests$/, async (v) => {
    const [qs, ach] = await Promise.all([api("/api/quests"), api("/api/achievements")]);
    v.innerHTML = `<div class="view stack">${page("퀘스트 · 업적", "미션을 완료하고 보상을 받으세요")}
      <div class="grid g2"><div class="glass card"><h3>🎯 퀘스트 · 미션</h3><div class="list">${qs.map(questItem).join("")}</div></div>
      <div class="glass card"><h3>🏅 업적 · 칭호</h3><p class="dim">업적을 달성하면 그 이름을 칭호로 쓸 수 있어요 (설정 → 프로필).</p><div class="list">${ach.map((a) => `<div class="item"><span class="big">${esc(a.icon || "🏅")}</span><div class="grow"><div>${esc(a.title)}</div><div class="muted small">${esc(a.description || "")}</div><div class="dim">보상 ${num(a.reward_coins)} 코인</div></div>${a.earned_at ? `<span class="chip good">달성 ✓</span>` : `<span class="chip">미달성</span>`}</div>`).join("")}</div></div></div></div>`;
    bindQuestClaims(v);
  }, "quests");

  route(/^\/rankings$/, async (v) => {
    const d = await api("/api/rankings");
    const tbl = (rows, val, label) => `<div class="list">${rows.map((r, i) => `<div class="item"><b>${["🥇", "🥈", "🥉"][i] || i + 1}</b><div class="grow">${userLink(r.username, r.display_name)}</div><b>${val(r)}</b></div>`).join("") || emptyBox("🏆", label)}</div>`;
    v.innerHTML = `<div class="view stack">${page("통합 랭킹", "레벨, 월드 탐험, 크리에이터 순위")}
      <div class="grid g3"><div class="glass card"><h3>⚡ 레벨</h3>${tbl(d.levels, (r) => `Lv.${r.level}`, "기록 없음")}</div>
      <div class="glass card"><h3>🪐 탐험가</h3>${tbl(d.explorers, (r) => num(r.score), "기록 없음")}</div>
      <div class="glass card"><h3>🛠️ 크리에이터</h3>${tbl(d.creators, (r) => `★ ${num(r.stars)}`, "공개 작품 없음")}</div></div>
      <p class="dim">게임별 랭킹은 각 게임 화면에서 볼 수 있어요.</p></div>`;
  }, "rankings");

  // ================= 크리에이터 =================
  route(/^\/creator$/, async (v) => {
    const list = await api("/api/creator/projects");
    v.innerHTML = `<div class="view stack">${page("OMNIVERSE CREATOR", "앱 · 게임 · 웹사이트를 만들고 공개하세요", `<button class="btn sm ghost" id="import">가져오기</button><button class="btn sm" id="new-p">＋ 새 프로젝트</button>`)}
      <div class="grid auto">${list.map((p) => `<a class="glass card tilt" href="#/creator/${p.id}"><h3>${{ app: "📱", game: "🎮", website: "🌐", world: "🪐" }[p.kind] || "✦"} ${esc(p.title)}</h3><div class="muted small">${esc(p.description || "")}</div>
        <div class="row small"><span class="chip">${esc(p.kind)}</span><span class="chip">v${p.version}</span><span class="chip ${p.visibility === "public" ? "good" : ""}">${p.visibility === "public" ? "공개" : "비공개"}</span><span class="dim">${timeAgo(p.updated_at)}</span></div></a>`).join("") || `<div class="glass card">${emptyBox("🛠️", "첫 프로젝트를 만들어 보세요. 템플릿과 AI 생성 기능을 쓸 수 있어요")}</div>`}</div>
      <input type="file" id="imp-file" accept=".json,application/json" class="hidden"></div>`;
    $("#new-p").onclick = () => modal(`<h2>🛠️ 새 프로젝트</h2><form id="p-form">
      <label class="field"><span>제목</span><input class="input" name="title" maxlength="60" required></label>
      <label class="field"><span>종류</span><select class="input" name="kind"><option value="game">🎮 게임</option><option value="website">🌐 웹사이트</option><option value="app">📱 앱</option><option value="world">🪐 월드 콘텐츠</option></select></label>
      <label class="field"><span>템플릿</span><select class="input" name="template"><option value="game">별 모으기 게임</option><option value="website">소개 웹사이트</option><option value="app">할 일 앱</option><option value="blank">빈 프로젝트</option></select></label>
      <label class="field"><span>설명</span><textarea class="input" name="description" maxlength="500"></textarea></label>
      <div class="row end"><button type="button" class="btn ghost" data-close>취소</button><button class="btn">만들기</button></div></form>`, (box) => {
      $("#p-form", box).onsubmit = async (e) => { e.preventDefault(); try { const r = await post("/api/creator/projects", Object.fromEntries(new FormData(e.target))); closeModal(); location.hash = `#/creator/${r.id}`; } catch (err) { fail(err); } };
    });
    $("#import").onclick = () => $("#imp-file").click();
    $("#imp-file").onchange = async (e) => {
      const file = e.target.files[0]; if (!file) return;
      try { const data = JSON.parse(await file.text()); const r = await post("/api/creator/import", data); toast("가져왔어요"); location.hash = `#/creator/${r.id}`; } catch (err) { fail(err instanceof SyntaxError ? new Error("JSON 파일이 아닙니다") : err); }
    };
  }, "creator");

  route(/^\/gallery$/, async (v) => {
    const list = await api("/api/creator/gallery");
    v.innerHTML = `<div class="view stack">${page("작품 갤러리", "모두가 공개한 작품")}
      <div class="grid auto">${list.map((p) => `<a class="glass card tilt" href="#/creator/${p.id}"><h3>${{ app: "📱", game: "🎮", website: "🌐", world: "🪐" }[p.kind] || "✦"} ${esc(p.title)}</h3><div class="muted small">${esc(p.description || "")}</div>
        <div class="row small"><span class="chip">by @${esc(p.owner)}</span><span class="chip">v${p.version}</span><span class="stars">${p.rating_count ? "★ " + (p.rating_sum / p.rating_count).toFixed(1) + ` (${p.rating_count})` : "평가 없음"}</span></div></a>`).join("") || `<div class="glass card">${emptyBox("🖼️", "아직 공개된 작품이 없습니다")}</div>`}</div></div>`;
  }, "gallery");

  route(/^\/creator\/(\d+)$/, async (v, pid) => {
    const d = await api(`/api/creator/projects/${pid}`);
    const p = d.project, owner = p.is_owner;
    const files = d.files;
    let cur = files.find((f) => f.path === "index.html") || files[0];
    let dirty = false;
    v.innerHTML = `<div class="view stack">
      ${page(`${esc(p.title)}`, `@${esc(p.owner)} · ${esc(p.kind)} · v${p.version} · ${p.visibility === "public" ? "공개" : "비공개"}${p.rating_count ? ` · ★ ${(p.rating_sum / p.rating_count).toFixed(1)}` : ""}`,
        owner ? `<button class="btn sm ghost" id="vis">${p.visibility === "public" ? "비공개로" : "공개하기"}</button><button class="btn sm ghost" id="export">내보내기</button><button class="btn sm ghost" id="del-p">삭제</button><button class="btn sm" id="save">저장 <span class="kbd">Ctrl+S</span></button>`
          : `<button class="btn sm ghost" id="export">내보내기</button><button class="btn sm ghost" id="rep">신고</button>`)}
      ${owner ? `<form class="glass card row" id="ai-form"><span>🤖</span><input class="input grow" name="prompt" maxlength="2000" placeholder="AI에게 부탁하기: 예) 벽돌깨기 게임으로 바꿔줘 (index.html을 새로 만듭니다)"><button class="btn cyan">AI 생성</button></form>` : ""}
      <div class="editor"><div class="glass editor-pane"><div class="file-tabs" id="tabs"></div>
        <textarea class="code" id="code" spellcheck="false" ${owner ? "" : "readonly"} aria-label="코드 편집기"></textarea>
        ${owner ? `<div class="row" style="padding:.6rem"><input class="input grow mono small" id="new-file" placeholder="새 파일 이름 (예: data.json)"><button class="btn sm ghost" id="add-file">파일 추가</button><button class="btn sm ghost" id="rm-file">현재 파일 삭제</button></div>` : ""}</div>
        <div class="glass editor-pane"><div class="row between" style="padding:.6rem .9rem"><b>▶ 미리보기</b><button class="btn sm ghost" id="reload">새로고침</button></div>
          <iframe class="preview" id="preview" title="미리보기" sandbox="allow-scripts allow-pointer-lock"></iframe></div></div>
      ${!owner && p.visibility === "public" ? `<div class="glass card row"><b>이 작품 평가하기</b>${[1, 2, 3, 4, 5].map((n) => `<button class="star-btn ${d.my_rating >= n ? "on" : ""}" data-star="${n}">★</button>`).join("")}</div>` : ""}</div>`;
    const code = $("#code"), tabs = $("#tabs"), frame = $("#preview");
    const drawTabs = () => {
      tabs.innerHTML = files.map((f) => `<button data-file="${esc(f.path)}" class="${f === cur ? "on" : ""}">${esc(f.path)}</button>`).join("");
      $$("[data-file]", tabs).forEach((b) => (b.onclick = () => { syncCur(); cur = files.find((f) => f.path === b.dataset.file); code.value = cur.content; drawTabs(); }));
    };
    const syncCur = () => { if (cur && cur.content !== code.value) { cur.content = code.value; cur.dirty = true; dirty = true; } };
    const reload = () => { frame.src = `/api/creator/projects/${pid}/preview?t=${Date.now()}`; };
    code.value = cur ? cur.content : "";
    drawTabs(); reload();
    $("#reload").onclick = reload;
    code.addEventListener("keydown", (e) => {
      if (e.key === "Tab" && owner) { e.preventDefault(); const s = code.selectionStart; code.setRangeText("  ", s, code.selectionEnd, "end"); }
      if ((e.ctrlKey || e.metaKey) && e.key === "s") { e.preventDefault(); save(); }
    });
    code.addEventListener("input", () => { dirty = true; });
    async function save() {
      if (!owner) return;
      syncCur();
      const changed = files.filter((f) => f.dirty);
      if (!changed.length) { toast("바뀐 내용이 없어요"); return; }
      try {
        for (const f of changed) { await put(`/api/creator/projects/${pid}/files`, { path: f.path, content: f.content }); f.dirty = false; }
        dirty = false; toast(`${changed.length}개 파일 저장 (새 버전)`); reload();
      } catch (e) { fail(e); }
    }
    if (owner) {
      $("#save").onclick = save;
      $("#vis").onclick = async () => { try { await patch(`/api/creator/projects/${pid}`, { visibility: p.visibility === "public" ? "private" : "public" }); render(); } catch (e) { fail(e); } };
      $("#del-p").onclick = async () => { if (await confirmBox("프로젝트를 영구 삭제할까요? 되돌릴 수 없습니다.", "삭제", true)) { try { await del(`/api/creator/projects/${pid}`); location.hash = "#/creator"; } catch (e) { fail(e); } } };
      $("#add-file").onclick = () => {
        const name = $("#new-file").value.trim();
        if (!/^[A-Za-z0-9_-]{1,40}\.(html|css|js|json|md|txt)$/.test(name)) { toast("파일 이름 형식이 올바르지 않아요", "err"); return; }
        if (files.some((f) => f.path === name)) { toast("이미 있는 파일이에요", "err"); return; }
        syncCur(); cur = { path: name, content: "", dirty: true }; files.push(cur); dirty = true; code.value = ""; drawTabs(); $("#new-file").value = "";
      };
      $("#rm-file").onclick = async () => {
        if (!cur || cur.path === "index.html") { toast("index.html은 지울 수 없어요", "err"); return; }
        if (!(await confirmBox(`${cur.path} 파일을 삭제할까요?`, "삭제", true))) return;
        try { if (!cur.dirty || d.files.some((f) => f.path === cur.path && f.version)) await del(`/api/creator/projects/${pid}/files/${enc(cur.path)}`); } catch (e) { if (e.status !== 404) { fail(e); return; } }
        files.splice(files.indexOf(cur), 1); cur = files[0]; code.value = cur.content; drawTabs(); reload();
      };
      $("#ai-form").onsubmit = (e) => {
        e.preventDefault(); const prompt = e.target.prompt.value.trim(); if (!prompt) return;
        busy(e.submitter, async () => {
          try { await post(`/api/creator/projects/${pid}/ai-generate`, { prompt }); toast("AI가 index.html을 만들었어요"); render(); } catch (err) { fail(err); }
        });
      };
      const leave = (e) => { if (dirty) { e.preventDefault(); e.returnValue = ""; } };
      window.addEventListener("beforeunload", leave);
      S.stop = () => window.removeEventListener("beforeunload", leave);
    } else {
      const r = $("#rep"); if (r) r.onclick = () => reportBox("project", p.id);
    }
    $("#export").onclick = async () => {
      try {
        const data = await api(`/api/creator/projects/${pid}/export`);
        const a = document.createElement("a");
        a.href = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: "application/json" }));
        a.download = `${p.title.replace(/[^\w가-힣-]+/g, "_")}.omniverse.json`; a.click(); URL.revokeObjectURL(a.href);
      } catch (e) { fail(e); }
    };
    $$("[data-star]", v).forEach((b) => (b.onclick = async () => { try { await post(`/api/creator/projects/${pid}/rate`, { stars: Number(b.dataset.star) }); toast("평가했어요"); render(); } catch (e) { fail(e); } }));
  }, "creator");

  // ================= 알림 / 검색 =================
  route(/^\/notifications$/, async (v) => {
    const d = await api("/api/notifications?limit=50");
    v.innerHTML = `<div class="view stack" style="max-width:760px;margin:0 auto">${page("알림 센터", `읽지 않은 알림 ${d.unread}개`, `<button class="btn sm ghost" id="read-all">모두 읽음</button>`)}
      <div class="glass card list">${d.items.map((n) => `<a class="item" href="${esc(/^#\//.test(n.link || "") ? n.link : "#/notifications")}"><span>${{ friend_request: "🤝", friend_accept: "🎉", like: "❤", comment: "💬", follow: "👣", message: "✉️", coins: "💰", quest: "🎯", achievement: "🏅" }[n.kind] || "🔔"}</span>
        <div class="grow"><div class="${n.read_at ? "muted" : ""}">${esc(n.message)}</div><div class="dim">${timeAgo(n.created_at)}</div></div>${n.read_at ? "" : `<span class="chip c1">새 알림</span>`}</a>`).join("") || emptyBox("🔔", "알림이 없습니다")}</div></div>`;
    $("#read-all").onclick = async () => { try { await post("/api/notifications/read-all"); render(); refreshTop(); } catch (e) { fail(e); } };
  }, "notifications");

  route(/^\/search\/(.+)$/, async (v, q) => {
    const d = await api(`/api/search?q=${enc(q)}`);
    $("#search-q").value = q;
    const sec = (title, html) => `<div class="glass card"><h3>${title}</h3>${html}</div>`;
    v.innerHTML = `<div class="view stack">${page("통합 검색", `“${esc(q)}” 검색 결과`)}
      <div class="grid g3">${sec("👤 사용자", `<div class="list">${d.users.map((u) => `<div class="item">${avatarHTML(u.display_name, "", "")}<div class="grow">${userLink(u.username, u.display_name)}</div><span class="chip">Lv.${u.level}</span></div>`).join("") || `<span class="dim">없음</span>`}</div>`)}
      ${sec("🪐 월드", `<div class="list">${d.worlds.map((w) => `<a class="item" href="#/worlds/${enc(w.slug)}">${planetHTML(w.color, 28, false)}<div class="grow">${esc(w.name)}</div></a>`).join("") || `<span class="dim">없음</span>`}</div>`)}
      ${sec("🎮 게임", `<div class="list">${d.games.map((g) => `<a class="item" href="#/games/${enc(g.slug)}"><div class="grow">${esc(g.title)}</div><span class="chip">${esc(g.category)}</span></a>`).join("") || `<span class="dim">없음</span>`}</div>`)}</div>
      <h2>📰 게시물</h2><div class="stack" style="max-width:760px">${d.posts.map(postHTML).join("") || `<div class="glass card">${emptyBox("🔍", "일치하는 게시물이 없습니다")}</div>`}</div></div>`;
    bindPosts(v);
  }, "");

  // ================= 설정 =================
  route(/^\/settings$/, async (v) => {
    const [prof, st, ach, blocks] = await Promise.all([api(`/api/users/${enc(S.user.username)}`), api("/api/me/settings"), api("/api/achievements"), api("/api/blocks")]);
    const u = prof.user, titles = ach.filter((a) => a.earned_at).map((a) => a.title);
    v.innerHTML = `<div class="view stack">${page("설정", "프로필, 테마, 보안, 개인정보")}
      <div class="grid g2">
        <form class="glass card" id="prof-form"><h3>👤 프로필</h3>
          <label class="field"><span>표시 이름</span><input class="input" name="display_name" value="${esc(u.display_name)}" maxlength="30" required></label>
          <label class="field"><span>소개</span><textarea class="input" name="bio" maxlength="500">${esc(u.bio || "")}</textarea></label>
          <label class="field"><span>칭호</span><select class="input" name="title"><option value="">없음</option>${titles.map((t) => `<option ${t === u.title ? "selected" : ""}>${esc(t)}</option>`).join("")}</select></label>
          <label class="item"><span class="switch"><input type="checkbox" name="is_public" ${u.is_public ? "checked" : ""}><i></i></span><span class="grow">공개 프로필 <span class="dim">(끄면 친구만 자세히 볼 수 있음)</span></span></label>
          <br><button class="btn">프로필 저장</button></form>
        <div class="stack">
          <form class="glass card" id="pref-form"><h3>🎨 테마 · 언어 · 알림</h3>
            <label class="field"><span>테마</span><select class="input" name="theme">${[["nebula", "네뷸라 (퍼플·시안)"], ["aurora", "오로라 (그린·시안)"], ["solar", "솔라 (오렌지·핑크)"]].map(([k, l]) => `<option value="${k}" ${k === st.theme ? "selected" : ""}>${l}</option>`).join("")}</select></label>
            <label class="field"><span>언어</span><select class="input" name="language"><option value="ko" selected>한국어</option><option value="en" disabled>English (준비 중)</option></select></label>
            <label class="item"><span class="switch"><input type="checkbox" name="notify_push" ${st.notify_push ? "checked" : ""}><i></i></span><span class="grow">앱 알림 받기</span></label>
            <label class="item"><span class="switch"><input type="checkbox" name="notify_email" ${st.notify_email ? "checked" : ""}><i></i></span><span class="grow">이메일 알림 <span class="chip soon">발송 기능 준비 중</span></span></label>
            <br><button class="btn">저장</button></form>
          <form class="glass card" id="pw-form"><h3>🔐 비밀번호 변경</h3>
            <label class="field"><span>현재 비밀번호</span><input class="input" type="password" name="current" autocomplete="current-password" required></label>
            <label class="field"><span>새 비밀번호</span><input class="input" type="password" name="new" autocomplete="new-password" minlength="8" required></label>
            <button class="btn">변경 (다른 기기는 로그아웃)</button></form>
        </div></div>
      <div class="grid g2"><div class="glass card"><h3>💾 데이터 백업</h3><p class="muted small">내 계정, 지갑, 게시물, AI 기억, 프로젝트 정보를 JSON 파일로 내려받습니다.</p><button class="btn ghost" id="export-me">내 데이터 내려받기</button> <span class="chip soon">복원 기능 준비 중</span></div>
        <div class="glass card"><h3>🚫 차단한 사용자</h3><div class="list">${blocks.map((b) => `<div class="item"><div class="grow">${userLink(b.username, b.display_name)}</div><button class="btn sm ghost" data-unb="${esc(b.username)}">해제</button></div>`).join("") || `<span class="dim">없음</span>`}</div></div></div></div>`;
    $("#prof-form").onsubmit = async (e) => {
      e.preventDefault(); const f = new FormData(e.target);
      try { await patch("/api/me/profile", { display_name: f.get("display_name"), bio: f.get("bio"), title: f.get("title"), is_public: f.get("is_public") === "on" }); await refreshMe(); shellFor = null; toast("프로필을 저장했어요"); render(); } catch (err) { fail(err); }
    };
    $("#pref-form").onsubmit = async (e) => {
      e.preventDefault(); const f = new FormData(e.target);
      try { await patch("/api/me/settings", { theme: f.get("theme"), language: "ko", notify_push: f.get("notify_push") === "on", notify_email: f.get("notify_email") === "on" }); document.body.dataset.theme = f.get("theme"); toast("설정을 저장했어요"); } catch (err) { fail(err); }
    };
    $("#pw-form").onsubmit = async (e) => {
      e.preventDefault(); const f = new FormData(e.target);
      try { await post("/api/auth/password", { current: f.get("current"), new: f.get("new") }); e.target.reset(); toast("비밀번호를 바꿨어요"); } catch (err) { fail(err); }
    };
    $("#export-me").onclick = async () => {
      try {
        const data = await api("/api/me/export");
        const a = document.createElement("a");
        a.href = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: "application/json" }));
        a.download = `omniverse-${S.user.username}-backup.json`; a.click(); URL.revokeObjectURL(a.href);
      } catch (err) { fail(err); }
    };
    $$("[data-unb]", v).forEach((b) => (b.onclick = async () => { try { await del(`/api/block/${enc(b.dataset.unb)}`); render(); } catch (e) { fail(e); } }));
  }, "settings");

  // ================= 로드맵 (미구현 기능 명시) =================
  route(/^\/roadmap$/, async (v) => {
    const done = ["회원가입·로그인·세션 보안", "프로필·설정·테마", "대시보드", "OMNI AI 채팅·기록·기억·프롬프트 라이브러리", "5개 행성 월드·탐험·월드 순위", "아바타 커스터마이징", "퀘스트·업적·칭호·레벨", "게임 센터 3종·랭킹·즐겨찾기", "친구·팔로우·차단·신고", "피드·댓글·좋아요·공유", "커뮤니티", "1:1 메시지 (폴링)", "가상 지갑·출석·송금·상점·인벤토리", "크리에이터 (편집기·미리보기·템플릿·AI 생성·공개·평가·버전·내보내기/가져오기)", "통합 검색·알림 센터", "관리자 (통계·사용자·신고·공지·기능 스위치·아이템·월드·경제·로그)", "내 데이터 백업"];
    const soon = [["PHASE 2", "3D 월드 고도화(WebGL), 보스 콘텐츠, 월드 이벤트, 멀티플레이, 시즌 패스"], ["PHASE 3", "AI 에이전트, AI 이미지 생성, AI 음성 대화, AI 개인화 추천"], ["PHASE 4", "실시간 채팅(WebSocket), 그룹 채팅, 클랜·길드, 소셜 이벤트"], ["PHASE 5", "아이템 직거래, 플러그인, 공개 API·API 키 관리, 외부 서비스 연동, 영어 등 다국어, 데이터 복원, 이메일 발송"]];
    v.innerHTML = `<div class="view stack">${page("로드맵", "ALPHA 1.0에서 실제로 작동하는 기능과 준비 중인 기능")}
      <div class="grid g2"><div class="glass card"><h3>✅ ALPHA 1.0 작동 기능</h3><div class="list">${done.map((d) => `<div class="item"><span>✅</span><div class="grow small">${d}</div></div>`).join("")}</div></div>
      <div class="glass card roadmap"><h3>🧭 준비 중 (미구현)</h3><div class="list">${soon.map(([p, d]) => `<div class="item"><span class="chip soon">${p}</span><div class="grow small">${d}</div></div>`).join("")}</div>
      <p class="dim">미구현 기능은 화면에 ‘준비 중’으로 표시되며, 작동하는 것처럼 보이지 않게 했습니다.</p></div></div></div>`;
  }, "roadmap");

  // ================= 관리자 =================
  const ADMIN_TABS = [["stats", "📊 통계"], ["users", "👥 사용자"], ["reports", "🚩 신고"], ["announcements", "📢 공지"], ["settings", "⚙️ 기능·설정"], ["items", "🛍️ 아이템"], ["worlds", "🪐 월드"], ["logs", "📜 활동 기록"]];
  route(/^\/admin(?:\/(\w+))?$/, async (v, tab = "stats") => {
    const isAdmin = S.user.role === "admin";
    if (!isAdmin && tab !== "reports") tab = "reports";
    const tabs = `<div class="subtabs">${ADMIN_TABS.filter(([k]) => isAdmin || k === "reports").map(([k, l]) => `<a href="#/admin/${k}" class="${k === tab ? "on" : ""}">${l}</a>`).join("")}</div>`;
    const head = page("관리자 센터", `${isAdmin ? "관리자" : "운영자"} 권한 · 모든 조치는 활동 기록에 남습니다`) + tabs;
    const T = ADMIN_VIEWS[tab];
    if (!T) throw Object.assign(new Error("없는 탭입니다"), { status: 404 });
    await T(v, head);
  }, "admin");

  const ADMIN_VIEWS = {
    async stats(v, head) {
      const d = await api("/api/admin/stats");
      const s = d.stats, max = Math.max(1, ...d.daily.map((x) => x.signups));
      v.innerHTML = `<div class="view stack">${head}
        <div class="grid g4">${[["👥", s.users, "전체 사용자"], ["🆕", s.signups_today, "오늘 가입"], ["🟢", s.active_7d, "7일 활성"], ["⛔", s.suspended, "정지 계정"], ["📰", s.posts, "게시물"], ["💬", s.messages, "메시지"], ["🎮", s.plays, "게임 플레이"], ["🛠️", s.projects, "프로젝트"], ["💰", s.coin_supply, "코인 총 발행량"], ["🔁", s.tx_today, "오늘 거래"], ["🚩", s.open_reports, "처리 대기 신고"]]
          .map(([i, n, l]) => `<div class="glass card stat"><span class="ico">${i}</span><span class="v">${num(n)}</span><span class="l">${l}</span></div>`).join("")}</div>
        <div class="grid g2"><div class="glass card"><h3>📈 최근 7일 가입</h3><div class="chart">${d.daily.map((x) => `<div class="col"><b class="small">${x.signups}</b><i data-h="${Math.round((x.signups / max) * 100)}"></i><span>${esc(x.day)}</span></div>`).join("")}</div></div>
        <div class="glass card"><h3>💹 경제 통계 (거래 종류별)</h3><table class="t"><thead><tr><th>종류</th><th>건수</th><th>합계</th></tr></thead><tbody>${d.economy.map((e) => `<tr><td>${esc(TX_LABEL[e.kind] || e.kind)}</td><td>${num(e.n)}</td><td>${num(e.total)}</td></tr>`).join("")}</tbody></table></div></div></div>`;
    },
    async users(v, head) {
      const q = (location.hash.split("?q=")[1] || "");
      const rows = await api(`/api/admin/users?q=${q}`);
      v.innerHTML = `<div class="view stack">${head}<form class="row" id="uq"><input class="input grow" name="q" placeholder="아이디·이메일 검색" value="${esc(decodeURIComponent(q))}"><button class="btn">검색</button></form>
        <div class="glass card table-wrap"><table class="t"><thead><tr><th>ID</th><th>사용자</th><th>권한</th><th>상태</th><th>코인</th><th>가입/최근 로그인</th><th>조치</th></tr></thead><tbody>
        ${rows.map((u) => `<tr><td>${u.id}</td><td>${userLink(u.username, u.username)}<div class="dim">${esc(u.email)}</div></td>
          <td><select class="input" data-role="${u.id}" ${u.id === S.user.id ? "disabled" : ""}>${["user", "moderator", "admin"].map((r) => `<option ${r === u.role ? "selected" : ""}>${r}</option>`).join("")}</select></td>
          <td>${u.status === "active" ? `<span class="chip good">정상</span>` : `<span class="chip bad">정지</span>`} ${u.is_frozen ? `<span class="chip warn">지갑 동결</span>` : ""}</td>
          <td>${num(u.balance)}</td><td class="dim nowrap">${fmt(u.created_at)}<br>${fmt(u.last_login_at)}</td>
          <td class="nowrap">${u.id === S.user.id ? "<span class='dim'>본인</span>" : `${u.status === "active" ? `<button class="btn sm danger" data-st="${u.id}" data-v="suspended">정지</button>` : `<button class="btn sm good" data-st="${u.id}" data-v="active">복구</button>`}
            <button class="btn sm ghost" data-fz="${u.id}" data-v="${u.is_frozen ? "0" : "1"}">${u.is_frozen ? "동결 해제" : "지갑 동결"}</button>`}
            <button class="btn sm ghost" data-coin="${u.id}">코인 조정</button></td></tr>`).join("")}</tbody></table></div></div>`;
      $("#uq").onsubmit = (e) => { e.preventDefault(); location.hash = `#/admin/users?q=${enc(e.target.q.value)}`; };
      $$("[data-role]", v).forEach((s) => (s.onchange = async () => { if (await confirmBox(`권한을 ${s.value}(으)로 바꿀까요?`)) { try { await post(`/api/admin/users/${s.dataset.role}/role`, { role: s.value }); toast("권한 변경"); } catch (e) { fail(e); } } render(); }));
      $$("[data-st]", v).forEach((b) => (b.onclick = async () => { if (await confirmBox(b.dataset.v === "suspended" ? "이 계정을 정지할까요? 즉시 로그아웃됩니다." : "계정을 복구할까요?", "확인", b.dataset.v === "suspended")) { try { await post(`/api/admin/users/${b.dataset.st}/status`, { status: b.dataset.v }); render(); } catch (e) { fail(e); } } }));
      $$("[data-fz]", v).forEach((b) => (b.onclick = async () => { try { await post(`/api/admin/users/${b.dataset.fz}/freeze`, { frozen: b.dataset.v === "1" }); render(); } catch (e) { fail(e); } }));
      $$("[data-coin]", v).forEach((b) => (b.onclick = () => modal(`<h2>💰 코인 조정</h2><form id="cf"><label class="field"><span>금액 (빼려면 음수)</span><input class="input" type="number" name="amount" required></label><label class="field"><span>사유</span><input class="input" name="memo" required maxlength="100"></label><div class="row end"><button type="button" class="btn ghost" data-close>취소</button><button class="btn">적용</button></div></form>`, (box) => {
        $("#cf", box).onsubmit = async (e) => { e.preventDefault(); try { await post(`/api/admin/users/${b.dataset.coin}/coins`, { amount: Number(e.target.amount.value), memo: e.target.memo.value }); closeModal(); toast("조정 완료"); render(); } catch (err) { fail(err); } };
      })));
    },
    async reports(v, head) {
      const rows = await api("/api/admin/reports?status=all");
      v.innerHTML = `<div class="view stack">${head}<div class="glass card table-wrap"><table class="t"><thead><tr><th>접수</th><th>대상</th><th>내용 미리보기</th><th>사유</th><th>상태</th><th>처리</th></tr></thead><tbody>
        ${rows.map((r) => `<tr><td class="dim nowrap">${fmt(r.created_at)}<br>@${esc(r.reporter)}</td><td>${esc(r.target_type)} #${r.target_id}</td><td class="small">${esc((r.preview || "").slice(0, 80))}</td><td class="small">${esc(r.reason)}</td>
          <td><span class="chip ${r.status === "open" ? "warn" : r.status === "resolved" ? "good" : ""}">${esc(r.status)}</span>${r.handler ? `<div class="dim">@${esc(r.handler)}</div>` : ""}</td>
          <td class="nowrap">${["post", "comment"].includes(r.target_type) ? `<button class="btn sm danger" data-rp="${r.id}" data-s="resolved" data-hide="1">숨기고 해결</button>` : ""}
            <button class="btn sm good" data-rp="${r.id}" data-s="resolved">해결</button><button class="btn sm ghost" data-rp="${r.id}" data-s="rejected">기각</button></td></tr>`).join("") || `<tr><td colspan="6">${emptyBox("✅", "신고가 없습니다")}</td></tr>`}</tbody></table></div></div>`;
      $$("[data-rp]", v).forEach((b) => (b.onclick = async () => { try { await post(`/api/admin/reports/${b.dataset.rp}`, { status: b.dataset.s, hide_target: !!b.dataset.hide }); toast("처리했습니다"); render(); } catch (e) { fail(e); } }));
    },
    async announcements(v, head) {
      const rows = await api("/api/admin/announcements");
      v.innerHTML = `<div class="view stack">${head}<form class="glass card" id="an"><label class="field"><span>제목</span><input class="input" name="title" maxlength="100" required></label><label class="field"><span>내용</span><textarea class="input" name="body" maxlength="3000" required></textarea></label><button class="btn">공지 등록</button></form>
        <div class="glass card list">${rows.map((a) => `<div class="item"><div class="grow"><div>${esc(a.title)}</div><div class="muted small">${esc(a.body)}</div><div class="dim">${fmt(a.created_at)}</div></div><button class="btn sm ghost" data-adel="${a.id}">삭제</button></div>`).join("") || emptyBox("📢", "공지가 없습니다")}</div></div>`;
      $("#an").onsubmit = async (e) => { e.preventDefault(); try { await post("/api/admin/announcements", Object.fromEntries(new FormData(e.target))); toast("등록했습니다"); render(); } catch (err) { fail(err); } };
      $$("[data-adel]", v).forEach((b) => (b.onclick = async () => { if (await confirmBox("공지를 삭제할까요?", "삭제", true)) { try { await del(`/api/admin/announcements/${b.dataset.adel}`); render(); } catch (e) { fail(e); } } }));
    },
    async settings(v, head) {
      const s = await api("/api/admin/settings");
      const f = s.features || {};
      const labels = { ai: "🤖 OMNI AI", world: "🪐 월드", social: "📰 소셜 피드", games: "🎮 게임 센터", economy: "💰 경제", creator: "🛠️ 크리에이터", realtime_chat: "⚡ 실시간 채팅 (미구현)", voice: "🎙️ 음성 (미구현)", image_gen: "🖼️ 이미지 생성 (미구현)" };
      const unbuilt = ["realtime_chat", "voice", "image_gen"];
      v.innerHTML = `<div class="view stack">${head}<div class="grid g2">
        <form class="glass card" id="ff"><h3>기능 활성화 · 비활성화</h3>${Object.keys(labels).map((k) => `<label class="item"><span class="switch"><input type="checkbox" name="${k}" ${f[k] ? "checked" : ""} ${unbuilt.includes(k) ? "disabled" : ""}><i></i></span><span class="grow">${labels[k]}</span></label>`).join("")}
          <br><button class="btn">기능 저장</button></form>
        <form class="glass card" id="nf"><h3>서비스 설정</h3>
          <label class="field"><span>가입 보너스 코인</span><input class="input" type="number" name="signup_bonus" value="${esc(s.signup_bonus)}" min="0"></label>
          <label class="field"><span>출석 보상 코인</span><input class="input" type="number" name="daily_reward" value="${esc(s.daily_reward)}" min="0"></label>
          <label class="field"><span>하루 송금 한도</span><input class="input" type="number" name="trade_daily_limit" value="${esc(s.trade_daily_limit)}" min="0"></label>
          <label class="item"><span class="switch"><input type="checkbox" name="maintenance" ${s.maintenance ? "checked" : ""}><i></i></span><span class="grow">점검 모드 <span class="dim">(관리자 외 쓰기 차단)</span></span></label>
          <br><button class="btn">설정 저장</button></form></div></div>`;
      $("#ff").onsubmit = async (e) => {
        e.preventDefault(); const features = {};
        Object.keys(labels).filter((k) => !unbuilt.includes(k)).forEach((k) => (features[k] = e.target[k].checked));
        try { await patch("/api/admin/settings", { features }); await refreshMe(); toast("기능 설정 저장"); } catch (err) { fail(err); }
      };
      $("#nf").onsubmit = async (e) => {
        e.preventDefault(); const t = e.target;
        try { await patch("/api/admin/settings", { signup_bonus: Number(t.signup_bonus.value), daily_reward: Number(t.daily_reward.value), trade_daily_limit: Number(t.trade_daily_limit.value), maintenance: t.maintenance.checked }); toast("서비스 설정 저장"); } catch (err) { fail(err); }
      };
    },
    async items(v, head) {
      const rows = await api("/api/admin/items");
      v.innerHTML = `<div class="view stack">${head}<div class="glass card table-wrap"><table class="t"><thead><tr><th>코드</th><th>이름</th><th>분류</th><th>등급</th><th>가격</th><th>판매</th></tr></thead><tbody>
        ${rows.map((i) => `<tr><td class="mono small">${esc(i.code)}</td><td>${esc(i.name)}</td><td>${esc(i.category)}</td><td>${esc(i.rarity)}</td>
          <td><input class="input" type="number" min="0" value="${i.price}" data-price="${i.id}" style="width:110px"></td>
          <td><label class="switch"><input type="checkbox" data-act="${i.id}" ${i.is_active ? "checked" : ""}><i></i></label></td></tr>`).join("")}</tbody></table></div>
        <form class="glass card" id="ni"><h3>＋ 새 아이템</h3><div class="grid g3">
          <label class="field"><span>코드</span><input class="input" name="code" required maxlength="60"></label><label class="field"><span>이름</span><input class="input" name="name" required maxlength="60"></label>
          <label class="field"><span>가격</span><input class="input" type="number" name="price" min="0" value="100" required></label>
          <label class="field"><span>분류</span><select class="input" name="category">${["avatar", "game", "world", "consumable", "badge"].map((c) => `<option>${c}</option>`).join("")}</select></label>
          <label class="field"><span>등급</span><select class="input" name="rarity">${["common", "rare", "epic", "legendary"].map((c) => `<option>${c}</option>`).join("")}</select></label>
          <label class="field"><span>설명</span><input class="input" name="description" maxlength="300"></label></div><button class="btn">추가</button></form></div>`;
      $$("[data-price]", v).forEach((inp) => (inp.onchange = async () => { try { await patch(`/api/admin/items/${inp.dataset.price}`, { price: Number(inp.value) }); toast("가격 변경"); } catch (e) { fail(e); } }));
      $$("[data-act]", v).forEach((c) => (c.onchange = async () => { try { await patch(`/api/admin/items/${c.dataset.act}`, { is_active: c.checked }); toast(c.checked ? "판매 시작" : "판매 중지"); } catch (e) { fail(e); } }));
      $("#ni").onsubmit = async (e) => { e.preventDefault(); const f = Object.fromEntries(new FormData(e.target)); f.price = Number(f.price); try { await post("/api/admin/items", f); toast("추가했습니다"); render(); } catch (err) { fail(err); } };
    },
    async worlds(v, head) {
      const rows = await api("/api/admin/worlds");
      v.innerHTML = `<div class="view stack">${head}<div class="glass card table-wrap"><table class="t"><thead><tr><th>월드</th><th>테마</th><th>종류</th><th>멤버</th><th>최소 레벨</th><th>활성</th></tr></thead><tbody>
        ${rows.map((w) => `<tr><td><a href="#/worlds/${enc(w.slug)}">${esc(w.name)}</a></td><td>${esc(w.theme)}</td><td>${w.is_official ? "공식" : `사용자 @${esc(w.creator || "-")}`}</td><td>${num(w.members)}</td>
          <td><input class="input" type="number" min="1" max="100" value="${w.min_level}" data-lvl="${w.id}" style="width:90px"></td>
          <td><label class="switch"><input type="checkbox" data-wact="${w.id}" ${w.is_active ? "checked" : ""}><i></i></label></td></tr>`).join("")}</tbody></table></div></div>`;
      $$("[data-lvl]", v).forEach((i) => (i.onchange = async () => { try { await patch(`/api/admin/worlds/${i.dataset.lvl}`, { min_level: Number(i.value) }); toast("변경했습니다"); } catch (e) { fail(e); } }));
      $$("[data-wact]", v).forEach((c) => (c.onchange = async () => { try { await patch(`/api/admin/worlds/${c.dataset.wact}`, { is_active: c.checked }); toast("변경했습니다"); } catch (e) { fail(e); } }));
    },
    async logs(v, head) {
      const rows = await api("/api/admin/logs?limit=200");
      v.innerHTML = `<div class="view stack">${head}<div class="glass card table-wrap"><table class="t"><thead><tr><th>일시</th><th>관리자</th><th>작업</th><th>대상</th><th>상세</th><th>IP</th></tr></thead><tbody>
        ${rows.map((l) => `<tr><td class="dim nowrap">${fmt(l.created_at)}</td><td>${l.admin ? "@" + esc(l.admin) : "<span class='dim'>시스템</span>"}</td><td class="mono small">${esc(l.action)}</td><td>${esc(l.target_type || "")} ${l.target_id ? "#" + l.target_id : ""}</td>
          <td class="mono small">${esc(JSON.stringify(l.detail))}</td><td class="dim">${esc(l.ip || "")}</td></tr>`).join("") || `<tr><td colspan="6">${emptyBox("📜", "기록이 없습니다")}</td></tr>`}</tbody></table></div></div>`;
    },
  };

  // ---------------- 시작 ----------------
  async function boot() {
    try { await refreshMe(); if (S.user) await applyTheme(); }
    catch (e) { S.user = null; toast("서버에 연결하지 못했습니다. 잠시 후 새로고침하세요", "err"); }
    await render();
    const boot = $("#boot");
    boot.classList.add("done");
    setTimeout(() => boot.remove(), 800);
    setInterval(refreshTop, 30000);
  }
  boot();
})();
