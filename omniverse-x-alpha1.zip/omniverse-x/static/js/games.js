/* OMNIVERSE X — 공식 게임 3종 + 월드 탐험 미니게임
   각 함수는 (container, onEnd(score)) 를 받고, 정리용 stop() 함수를 돌려준다. */
(function () {
  "use strict";

  function makeCanvas(el, w, h) {
    const c = document.createElement("canvas");
    c.width = w; c.height = h;
    el.appendChild(c);
    return c;
  }
  function pointerPos(canvas, e) {
    const r = canvas.getBoundingClientRect();
    return { x: ((e.clientX - r.left) / r.width) * canvas.width, y: ((e.clientY - r.top) / r.height) * canvas.height };
  }
  function keyTracker() {
    const keys = {};
    const down = (e) => { if (["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown"].includes(e.key)) { keys[e.key] = true; e.preventDefault(); } };
    const up = (e) => { keys[e.key] = false; };
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    return { keys, off() { window.removeEventListener("keydown", down); window.removeEventListener("keyup", up); } };
  }
  function drawStar(ctx, x, y, r, color) {
    ctx.save(); ctx.translate(x, y); ctx.beginPath();
    for (let i = 0; i < 10; i++) {
      const a = (i * Math.PI) / 5 - Math.PI / 2, rr = i % 2 ? r * 0.45 : r;
      ctx.lineTo(Math.cos(a) * rr, Math.sin(a) * rr);
    }
    ctx.closePath(); ctx.fillStyle = color; ctx.shadowColor = color; ctx.shadowBlur = 16; ctx.fill(); ctx.restore();
  }
  function bgStars(n, w, h) {
    return Array.from({ length: n }, () => ({ x: Math.random() * w, y: Math.random() * h, s: Math.random() * 1.6 + 0.3, v: Math.random() * 0.8 + 0.2 }));
  }

  /* ---------- 1. 스타 캐처 ---------- */
  function starCatcher(el, onEnd) {
    const W = 800, H = 500;
    const c = makeCanvas(el, W, H), ctx = c.getContext("2d");
    const kt = keyTracker();
    const sky = bgStars(120, W, H);
    let px = W / 2, target = W / 2, score = 0, lives = 3, timeLeft = 60, items = [], last = performance.now(), spawnT = 0, alive = true, raf;
    const move = (e) => { target = pointerPos(c, e).x; };
    c.addEventListener("pointermove", move);
    c.addEventListener("pointerdown", move);

    function loop(now) {
      if (!alive) return;
      const dt = Math.min(0.05, (now - last) / 1000); last = now;
      timeLeft -= dt;
      if (kt.keys.ArrowLeft) target = px - 400 * dt * 2;
      if (kt.keys.ArrowRight) target = px + 400 * dt * 2;
      px += (target - px) * Math.min(1, dt * 12);
      px = Math.max(30, Math.min(W - 30, px));
      const speedUp = 1 + (60 - timeLeft) / 40;
      spawnT -= dt;
      if (spawnT <= 0) {
        spawnT = 0.45 / speedUp;
        const r = Math.random();
        items.push({ x: 30 + Math.random() * (W - 60), y: -20, v: (140 + Math.random() * 120) * speedUp,
                     kind: r < 0.07 ? "gold" : r < 0.32 ? "rock" : "star", rot: Math.random() * 6 });
      }
      for (const it of items) {
        it.y += it.v * dt; it.rot += dt * 2;
        if (!it.hit && it.y > H - 70 && it.y < H - 20 && Math.abs(it.x - px) < 42) {
          it.hit = true;
          if (it.kind === "rock") lives -= 1; else score += it.kind === "gold" ? 50 : 10;
        }
      }
      items = items.filter((i) => !i.hit && i.y < H + 30);

      ctx.fillStyle = "#050816"; ctx.fillRect(0, 0, W, H);
      for (const s of sky) { s.y = (s.y + s.v * speedUp) % H; ctx.fillStyle = "rgba(200,220,255,.7)"; ctx.fillRect(s.x, s.y, s.s, s.s); }
      for (const it of items) {
        if (it.kind === "rock") {
          ctx.save(); ctx.translate(it.x, it.y); ctx.rotate(it.rot);
          ctx.fillStyle = "#7c4a3a"; ctx.shadowColor = "#f97316"; ctx.shadowBlur = 12;
          ctx.beginPath(); ctx.moveTo(-16, -6); ctx.lineTo(-6, -16); ctx.lineTo(12, -12); ctx.lineTo(16, 6); ctx.lineTo(4, 16); ctx.lineTo(-12, 12); ctx.closePath(); ctx.fill();
          ctx.restore();
        } else drawStar(ctx, it.x, it.y, it.kind === "gold" ? 18 : 13, it.kind === "gold" ? "#fbbf24" : "#fef08a");
      }
      // 우주선
      ctx.save(); ctx.translate(px, H - 45);
      ctx.fillStyle = "#22d3ee"; ctx.shadowColor = "#22d3ee"; ctx.shadowBlur = 20;
      ctx.beginPath(); ctx.moveTo(0, -24); ctx.lineTo(26, 16); ctx.lineTo(0, 8); ctx.lineTo(-26, 16); ctx.closePath(); ctx.fill();
      ctx.fillStyle = "#a78bfa"; ctx.beginPath(); ctx.arc(0, -2, 7, 0, 7); ctx.fill();
      ctx.fillStyle = `rgba(251,146,60,${0.5 + Math.random() * 0.5})`; ctx.beginPath(); ctx.moveTo(-8, 12); ctx.lineTo(0, 30 + Math.random() * 8); ctx.lineTo(8, 12); ctx.fill();
      ctx.restore();
      ctx.shadowBlur = 0; ctx.fillStyle = "#fff"; ctx.font = "bold 22px sans-serif";
      ctx.fillText(`★ ${score}`, 18, 34); ctx.fillText("❤".repeat(Math.max(0, lives)), W - 110, 34);
      ctx.fillText(`${Math.max(0, Math.ceil(timeLeft))}s`, W / 2 - 20, 34);

      if (lives <= 0 || timeLeft <= 0) { stop(); onEnd(Math.min(score, 5000)); return; }
      raf = requestAnimationFrame(loop);
    }
    function stop() { alive = false; cancelAnimationFrame(raf); kt.off(); }
    raf = requestAnimationFrame(loop);
    return stop;
  }

  /* ---------- 2. 메모리 오빗 ---------- */
  function memoryOrbit(el, onEnd) {
    const icons = ["🪐", "🌍", "🌙", "☄️", "⭐", "🛸", "🌌", "🚀"];
    const deck = icons.concat(icons).map((v, i) => ({ v, i })).sort(() => Math.random() - 0.5);
    const grid = document.createElement("div");
    grid.className = "mem-grid";
    const info = document.createElement("div");
    info.className = "center muted";
    info.style.padding = "0 0 1rem";
    el.append(grid, info);
    let open = [], moves = 0, done = 0, busy = false, alive = true;
    const start = performance.now();
    const timer = setInterval(update, 500);
    function update() { info.textContent = `시도 ${moves}회 · ${Math.floor((performance.now() - start) / 1000)}초 · 맞춘 짝 ${done}/8`; }
    deck.forEach((card) => {
      const b = document.createElement("button");
      b.className = "mem-card"; b.type = "button"; b.setAttribute("aria-label", "카드");
      const f = document.createElement("span"); f.className = "f"; f.textContent = card.v;
      const bk = document.createElement("span"); bk.className = "b";
      b.append(f, bk);
      b.addEventListener("click", () => {
        if (!alive || busy || b.classList.contains("open")) return;
        b.classList.add("open"); open.push({ b, card });
        if (open.length === 2) {
          moves++; busy = true;
          const [a, z] = open;
          if (a.card.v === z.card.v) {
            a.b.classList.add("done"); z.b.classList.add("done"); open = []; busy = false; done++;
            if (done === 8) {
              const secs = (performance.now() - start) / 1000;
              finish(Math.max(100, Math.round(2000 - moves * 25 - secs * 8)));
            }
          } else setTimeout(() => { a.b.classList.remove("open"); z.b.classList.remove("open"); open = []; busy = false; }, 750);
        }
        update();
      });
      grid.appendChild(b);
    });
    update();
    function finish(score) { stop(); onEnd(Math.min(score, 2000)); }
    function stop() { alive = false; clearInterval(timer); }
    return stop;
  }

  /* ---------- 3. 타이핑 워프 ---------- */
  function typeWarp(el, onEnd) {
    const words = ["우주", "은하수", "행성", "블랙홀", "성운", "우주선", "탐험가", "중력", "궤도", "혜성", "별빛", "워프",
      "galaxy", "planet", "orbit", "nebula", "comet", "rocket", "quasar", "nova", "photon", "meteor", "cosmos", "warp"];
    const box = document.createElement("div");
    box.className = "card";
    const hud = document.createElement("div"); hud.className = "row between";
    const sEl = document.createElement("b"), tEl = document.createElement("b"), cEl = document.createElement("span");
    cEl.className = "chip c2"; hud.append(sEl, cEl, tEl);
    const wordEl = document.createElement("div"); wordEl.className = "type-word";
    const input = document.createElement("input");
    input.className = "input"; input.autocomplete = "off"; input.spellcheck = false; input.placeholder = "단어를 입력하고 Enter 또는 스페이스";
    input.setAttribute("aria-label", "단어 입력");
    box.append(hud, wordEl, input);
    el.appendChild(box);
    let score = 0, combo = 1, left = 60, word = "", alive = true;
    function next() { word = words[Math.floor(Math.random() * words.length)]; render(); }
    function render() {
      const typed = input.value;
      let ok = 0;
      while (ok < typed.length && ok < word.length && typed[ok] === word[ok]) ok++;
      wordEl.textContent = "";
      const a = document.createElement("span"); a.className = "ok"; a.textContent = word.slice(0, ok);
      const b = document.createElement("span"); b.className = "rest"; b.textContent = word.slice(ok);
      wordEl.append(a, b);
      sEl.textContent = `점수 ${score}`; tEl.textContent = `${left}초`; cEl.textContent = `콤보 x${combo}`;
    }
    input.addEventListener("input", () => {
      const v = input.value;
      if (v.endsWith(" ")) { check(v.trim()); return; }
      render();
    });
    input.addEventListener("keydown", (e) => { if (e.key === "Enter" && !e.isComposing) { e.preventDefault(); check(input.value.trim()); } });
    function check(v) {
      if (!alive) return;
      if (v === word) { score += word.length * 10 * combo; combo = Math.min(5, combo + 1); }
      else if (v.length) combo = 1;
      input.value = ""; next();
    }
    const timer = setInterval(() => {
      left--; render();
      if (left <= 0) { stop(); onEnd(Math.min(score, 5000)); }
    }, 1000);
    next(); setTimeout(() => input.focus(), 50);
    function stop() { alive = false; clearInterval(timer); input.disabled = true; }
    return stop;
  }

  /* ---------- 월드 탐험: 에너지 수집 ---------- */
  function explore(el, color, onEnd) {
    const W = 800, H = 450;
    const c = makeCanvas(el, W, H), ctx = c.getContext("2d");
    const kt = keyTracker();
    const craters = Array.from({ length: 14 }, () => ({ x: Math.random() * W, y: Math.random() * H, r: 10 + Math.random() * 40 }));
    let p = { x: W / 2, y: H / 2 }, target = { ...p }, orbs = [], storms = [], energy = 0, left = 45, last = performance.now(), alive = true, raf;
    const move = (e) => { target = pointerPos(c, e); };
    c.addEventListener("pointerdown", move);
    c.addEventListener("pointermove", (e) => { if (e.buttons || e.pointerType === "mouse") move(e); });
    function spawnOrb() { orbs.push({ x: 30 + Math.random() * (W - 60), y: 30 + Math.random() * (H - 60), ph: Math.random() * 6 }); }
    for (let i = 0; i < 5; i++) spawnOrb();
    storms.push({ x: 0, y: H * 0.3, vx: 90, vy: 40 }, { x: W, y: H * 0.7, vx: -70, vy: -50 });

    function loop(now) {
      if (!alive) return;
      const dt = Math.min(0.05, (now - last) / 1000); last = now;
      left -= dt;
      const sp = 260 * dt;
      if (kt.keys.ArrowLeft) target.x = p.x - sp * 3; if (kt.keys.ArrowRight) target.x = p.x + sp * 3;
      if (kt.keys.ArrowUp) target.y = p.y - sp * 3; if (kt.keys.ArrowDown) target.y = p.y + sp * 3;
      const dx = target.x - p.x, dy = target.y - p.y, d = Math.hypot(dx, dy);
      if (d > 1) { const k = Math.min(1, (sp) / d); p.x += dx * k; p.y += dy * k; }
      p.x = Math.max(16, Math.min(W - 16, p.x)); p.y = Math.max(16, Math.min(H - 16, p.y));
      for (const o of orbs) {
        o.ph += dt * 4;
        if (!o.got && Math.hypot(o.x - p.x, o.y - p.y) < 26) { o.got = true; energy += 10; }
      }
      orbs = orbs.filter((o) => !o.got);
      while (orbs.length < 5) spawnOrb();
      for (const s of storms) {
        s.x += s.vx * dt; s.y += s.vy * dt;
        if (s.x < 0 || s.x > W) s.vx *= -1; if (s.y < 0 || s.y > H) s.vy *= -1;
        if (Math.hypot(s.x - p.x, s.y - p.y) < 40 && !s.cool) { left -= 3; s.cool = 1; setTimeout(() => (s.cool = 0), 1200); }
      }
      // 지표면
      const g = ctx.createRadialGradient(W / 2, H * 1.4, 50, W / 2, H * 0.6, W);
      g.addColorStop(0, color); g.addColorStop(1, "#050816");
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
      for (const cr of craters) { ctx.fillStyle = "rgba(0,0,0,.18)"; ctx.beginPath(); ctx.ellipse(cr.x, cr.y, cr.r, cr.r * 0.5, 0, 0, 7); ctx.fill(); }
      for (const s of storms) {
        const sg = ctx.createRadialGradient(s.x, s.y, 4, s.x, s.y, 46);
        sg.addColorStop(0, "rgba(248,113,113,.7)"); sg.addColorStop(1, "rgba(248,113,113,0)");
        ctx.fillStyle = sg; ctx.beginPath(); ctx.arc(s.x, s.y, 46, 0, 7); ctx.fill();
      }
      for (const o of orbs) {
        const r = 9 + Math.sin(o.ph) * 2;
        ctx.fillStyle = "#a5f3fc"; ctx.shadowColor = "#22d3ee"; ctx.shadowBlur = 18;
        ctx.beginPath(); ctx.arc(o.x, o.y, r, 0, 7); ctx.fill();
      }
      ctx.shadowColor = "#fff"; ctx.shadowBlur = 24; ctx.fillStyle = "#fff";
      ctx.beginPath(); ctx.arc(p.x, p.y, 14, 0, 7); ctx.fill();
      ctx.shadowBlur = 0; ctx.fillStyle = color; ctx.beginPath(); ctx.arc(p.x, p.y, 8, 0, 7); ctx.fill();
      ctx.fillStyle = "#fff"; ctx.font = "bold 20px sans-serif";
      ctx.fillText(`⚡ ${energy}`, 16, 30); ctx.fillText(`${Math.max(0, Math.ceil(left))}s`, W - 60, 30);
      if (left <= 0 || energy >= 500) { stop(); onEnd(Math.min(energy, 500)); return; }
      raf = requestAnimationFrame(loop);
    }
    function stop() { alive = false; cancelAnimationFrame(raf); kt.off(); }
    raf = requestAnimationFrame(loop);
    return stop;
  }

  window.OmniGames = { "star-catcher": starCatcher, "memory-orbit": memoryOrbit, "type-warp": typeWarp, explore };
})();
