/* OMNIVERSE X — 움직이는 은하수 배경 (경량화 버전)
   - 은하 먼지는 화면 밖 캔버스에 한 번만 그려 두고, 매 프레임 회전시켜 붙이기만 한다
   - 30fps 제한, 해상도 배율 1 고정, 탭이 숨겨지면 정지
   - 저사양 기기/모바일/동작 줄이기 설정이면 별 수를 줄이고 정지 화면에 가깝게 그린다 */
(function () {
  "use strict";
  const canvas = document.getElementById("space");
  if (!canvas) return;
  const ctx = canvas.getContext("2d", { alpha: true });
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const lite = reduce || window.innerWidth < 860 || (navigator.hardwareConcurrency || 8) <= 4;
  document.documentElement.classList.toggle("lite", lite);
  const FRAME_MS = lite ? 1000 / 20 : 1000 / 30;
  let W = 0, H = 0, stars = [], meteors = [], galaxy = null, galaxyR = 0;
  let mx = 0, my = 0, tx = 0, ty = 0, t = 0, last = 0, running = true, colorKey = "";

  function rand(a, b) { return a + Math.random() * (b - a); }
  function themeColor(name) { return getComputedStyle(document.body).getPropertyValue(name).trim() || "#7c5cff"; }

  function buildGalaxy() {
    const c1 = themeColor("--c1"), c2 = themeColor("--c2");
    colorKey = c1 + c2;
    galaxyR = Math.round(Math.max(W, H) * 0.55);
    const size = galaxyR * 2;
    galaxy = document.createElement("canvas");
    galaxy.width = size; galaxy.height = size;
    const g = galaxy.getContext("2d");
    g.translate(galaxyR, galaxyR);
    const n = lite ? 260 : 520;
    for (let i = 0; i < n; i++) {
      const arm = i % 3, d = Math.pow(Math.random(), 0.6), off = rand(-0.35, 0.35) * (1 - d * 0.5);
      const ang = arm * (Math.PI * 2 / 3) + d * 5.2 + off;
      g.globalAlpha = rand(0.15, 0.6) * (1 - d * 0.7);
      g.fillStyle = d < 0.35 ? c2 : c1;
      const s = rand(0.6, 1.8);
      g.fillRect(Math.cos(ang) * d * galaxyR, Math.sin(ang) * d * galaxyR, s, s);
    }
    const core = g.createRadialGradient(0, 0, 0, 0, 0, galaxyR * 0.2);
    core.addColorStop(0, "rgba(255,255,255,0.35)"); core.addColorStop(1, "rgba(255,255,255,0)");
    g.globalAlpha = 1; g.fillStyle = core;
    g.beginPath(); g.arc(0, 0, galaxyR * 0.2, 0, Math.PI * 2); g.fill();
  }

  function resize() {
    W = window.innerWidth; H = window.innerHeight;
    canvas.width = W; canvas.height = H;
    const n = Math.min(lite ? 140 : 260, Math.floor((W * H) / 5000));
    stars = Array.from({ length: n }, () => ({
      x: Math.random() * W, y: Math.random() * H, z: Math.random() * 0.9 + 0.1,
      r: Math.random() * 1.2 + 0.3, tw: Math.random() * Math.PI * 2,
      color: Math.random() < 0.15 ? `hsl(${Math.round(rand(180, 280))},90%,85%)` : "#dfe8ff",
    }));
    buildGalaxy();
  }

  function frame(now) {
    if (!running) return;
    requestAnimationFrame(frame);
    if (now - last < FRAME_MS) return;
    last = now;
    if (!reduce) t += 1;
    tx += (mx - tx) * 0.08; ty += (my - ty) * 0.08;
    const ck = themeColor("--c1") + themeColor("--c2");
    if (ck !== colorKey) buildGalaxy();
    ctx.clearRect(0, 0, W, H);

    // 은하: 미리 그려 둔 이미지를 회전·납작하게 붙이기만 함
    ctx.save();
    ctx.translate(W * 0.72 + tx * 30, H * 0.28 + ty * 20);
    ctx.scale(1, 0.42);
    ctx.rotate(t * 0.0008);
    ctx.drawImage(galaxy, -galaxyR, -galaxyR);
    ctx.restore();

    // 별 (깊이별 시차, 반짝임)
    for (const s of stars) {
      s.tw += 0.04 + s.z * 0.04;
      const x = (s.x + tx * 40 * s.z + W) % W, y = (s.y + ty * 30 * s.z - t * 0.1 * s.z + H * 10) % H;
      ctx.globalAlpha = 0.35 + Math.sin(s.tw) * 0.3 + s.z * 0.35;
      ctx.fillStyle = s.color;
      const r = s.r * (0.6 + s.z) * 2;
      ctx.fillRect(x, y, r, r);
    }

    // 별똥별
    if (!lite && Math.random() < 0.01 && meteors.length < 2) {
      meteors.push({ x: rand(W * 0.2, W), y: rand(-50, H * 0.4), vx: -rand(12, 18), vy: rand(5, 8), life: 1 });
    }
    meteors = meteors.filter((m) => m.life > 0);
    ctx.lineWidth = 2;
    for (const m of meteors) {
      m.x += m.vx; m.y += m.vy; m.life -= 0.025;
      ctx.globalAlpha = Math.max(0, m.life);
      ctx.strokeStyle = "#dcfaff";
      ctx.beginPath(); ctx.moveTo(m.x, m.y); ctx.lineTo(m.x - m.vx * 6, m.y - m.vy * 6); ctx.stroke();
    }
    ctx.globalAlpha = 1;
  }

  let resizeTimer;
  window.addEventListener("resize", () => { clearTimeout(resizeTimer); resizeTimer = setTimeout(resize, 200); });
  window.addEventListener("pointermove", (e) => { mx = e.clientX / W - 0.5; my = e.clientY / H - 0.5; }, { passive: true });
  document.addEventListener("visibilitychange", () => {
    const was = running;
    running = !document.hidden;
    if (running && !was) requestAnimationFrame(frame);
  });
  resize();
  requestAnimationFrame(frame);
})();
