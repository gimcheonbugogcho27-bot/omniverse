/* OMNIVERSE X — 움직이는 은하수 배경 (마우스 시차 반응, 별똥별, 회전하는 은하 먼지) */
(function () {
  "use strict";
  const canvas = document.getElementById("space");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  let W = 0, H = 0, DPR = 1, stars = [], dust = [], meteors = [];
  let mx = 0, my = 0, tx = 0, ty = 0, t = 0, running = true;

  function rand(a, b) { return a + Math.random() * (b - a); }

  function resize() {
    DPR = Math.min(window.devicePixelRatio || 1, 2);
    W = window.innerWidth; H = window.innerHeight;
    canvas.width = W * DPR; canvas.height = H * DPR;
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    const n = Math.min(520, Math.floor((W * H) / 3200));
    stars = Array.from({ length: n }, () => ({
      x: Math.random() * W, y: Math.random() * H, z: Math.random() * 0.9 + 0.1,
      r: Math.random() * 1.3 + 0.2, tw: Math.random() * Math.PI * 2, hue: Math.random() < 0.15 ? rand(180, 280) : 220,
    }));
    const m = Math.min(900, Math.floor((W * H) / 1800));
    dust = Array.from({ length: m }, () => {
      const arm = Math.floor(Math.random() * 3);
      const d = Math.pow(Math.random(), 0.6);
      return { arm, d, off: rand(-0.35, 0.35) * (1 - d * 0.5), s: rand(0.4, 1.6), a: rand(0.15, 0.6) };
    });
  }

  function themeColor(name) {
    return getComputedStyle(document.body).getPropertyValue(name).trim() || "#7c5cff";
  }

  function frame() {
    if (!running) return;
    t += reduce ? 0 : 1;
    tx += (mx - tx) * 0.04; ty += (my - ty) * 0.04;
    ctx.clearRect(0, 0, W, H);

    // 은하 나선 먼지
    const cx = W * 0.72 + tx * 30, cy = H * 0.28 + ty * 20;
    const R = Math.max(W, H) * 0.55;
    const c1 = themeColor("--c1"), c2 = themeColor("--c2");
    ctx.save();
    ctx.translate(cx, cy);
    ctx.scale(1, 0.42);
    ctx.rotate(t * 0.0004);
    for (const p of dust) {
      const ang = p.arm * (Math.PI * 2 / 3) + p.d * 5.2 + p.off;
      const x = Math.cos(ang) * p.d * R, y = Math.sin(ang) * p.d * R;
      ctx.globalAlpha = p.a * (1 - p.d * 0.7);
      ctx.fillStyle = p.d < 0.35 ? c2 : c1;
      ctx.fillRect(x, y, p.s, p.s);
    }
    ctx.restore();
    const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, R * 0.18);
    g.addColorStop(0, "rgba(255,255,255,0.35)"); g.addColorStop(1, "rgba(255,255,255,0)");
    ctx.globalAlpha = 1; ctx.fillStyle = g;
    ctx.beginPath(); ctx.ellipse(cx, cy, R * 0.18, R * 0.08, 0, 0, Math.PI * 2); ctx.fill();

    // 별 (깊이별 시차)
    for (const s of stars) {
      s.tw += 0.02 + s.z * 0.02;
      const x = (s.x + tx * 40 * s.z + W) % W, y = (s.y + ty * 30 * s.z - t * 0.05 * s.z + H * 10) % H;
      ctx.globalAlpha = 0.35 + Math.sin(s.tw) * 0.3 + s.z * 0.35;
      ctx.fillStyle = `hsl(${s.hue}, 90%, ${80 + s.z * 15}%)`;
      ctx.beginPath(); ctx.arc(x, y, s.r * (0.6 + s.z), 0, Math.PI * 2); ctx.fill();
    }

    // 별똥별
    if (!reduce && Math.random() < 0.006 && meteors.length < 2) {
      meteors.push({ x: rand(W * 0.2, W), y: rand(-50, H * 0.4), vx: -rand(6, 10), vy: rand(2.5, 4.5), life: 1 });
    }
    meteors = meteors.filter((m) => m.life > 0);
    for (const m of meteors) {
      m.x += m.vx; m.y += m.vy; m.life -= 0.012;
      const grad = ctx.createLinearGradient(m.x, m.y, m.x - m.vx * 14, m.y - m.vy * 14);
      grad.addColorStop(0, `rgba(220,250,255,${m.life})`); grad.addColorStop(1, "rgba(220,250,255,0)");
      ctx.globalAlpha = 1; ctx.strokeStyle = grad; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(m.x, m.y); ctx.lineTo(m.x - m.vx * 14, m.y - m.vy * 14); ctx.stroke();
    }
    ctx.globalAlpha = 1;
    requestAnimationFrame(frame);
  }

  window.addEventListener("resize", resize);
  window.addEventListener("pointermove", (e) => { mx = e.clientX / W - 0.5; my = e.clientY / H - 0.5; }, { passive: true });
  document.addEventListener("visibilitychange", () => {
    const wasRunning = running;
    running = !document.hidden;
    if (running && !wasRunning) requestAnimationFrame(frame);
  });
  resize();
  requestAnimationFrame(frame);
})();
