"""계정, 프로필, 설정, 대시보드, 검색, 알림, 공지, 내 데이터 내보내기."""
import re

from flask import Blueprint, g, request
from werkzeug.security import check_password_hash, generate_password_hash

import db
import services as sv
from security import (APIError, EMAIL_RE, USERNAME_RE, body, choice, client_ip, csrf_token, end_session,
                      is_admin_email, limiter, login_required, ok, page_args, rate_limit, setting,
                      settings, start_session, text)

bp = Blueprint("core", __name__)

_DUMMY_HASH = generate_password_hash("omniverse-dummy-password")
THEMES = ("nebula", "aurora", "solar")


def _validate_password(pw):
    if not isinstance(pw, str) or not (8 <= len(pw) <= 128):
        raise APIError(400, "비밀번호는 8자 이상 128자 이하여야 합니다")
    if not re.search(r"[A-Za-z]", pw) or not re.search(r"\d", pw):
        raise APIError(400, "비밀번호에는 영문과 숫자가 모두 들어가야 합니다")


def _public_user():
    u = g.get("user")
    if not u:
        return None
    return {"id": u["id"], "username": u["username"], "display_name": u["display_name"] or u["username"],
            "role": u["role"], "level": u["level"], "exp": u["exp"]}


# ---------------- 인증 ----------------

@bp.get("/api/auth/me")
def me():
    feats = setting("features", {}) or {}
    return ok({"user": _public_user(), "csrf": csrf_token(), "features": feats,
               "maintenance": bool(setting("maintenance", False))})


@bp.post("/api/auth/signup")
@rate_limit("signup", 5, 600)
def signup():
    d = body()
    email = text(d, "email", max_len=254).lower()
    username = text(d, "username", max_len=20)
    password = d.get("password")
    display_name = text(d, "display_name", required=False, max_len=30) or username
    ref = text(d, "ref", required=False, max_len=20)
    if not EMAIL_RE.match(email):
        raise APIError(400, "이메일 형식이 올바르지 않습니다")
    if not USERNAME_RE.match(username):
        raise APIError(400, "아이디는 2~20자의 한글, 영문, 숫자, _ 만 쓸 수 있습니다")
    _validate_password(password)
    if setting("maintenance", False):
        raise APIError(503, "점검 중에는 가입할 수 없습니다")
    bonus = int(setting("signup_bonus", 0) or 0)
    role = "admin" if is_admin_email(email) else "user"
    try:
        row = db.one(
            """
            with u as (
              insert into public.users (email, username, password_hash, role)
              values (%(e)s, %(n)s, %(h)s, %(r)s) returning id),
            p as (insert into public.user_profiles (user_id, display_name) select id, %(dn)s from u),
            s as (insert into public.user_settings (user_id) select id from u),
            a as (insert into public.avatars (user_id) select id from u),
            w as (insert into public.wallets (user_id, balance) select id, %(b)s from u),
            t as (insert into public.transactions (user_id, kind, amount, balance_after, memo, idempotency_key)
                  select id, 'signup_bonus', %(b)s, %(b)s, '가입 보너스', 'signup:' || id from u where %(b)s > 0),
            i as (insert into public.inventory (user_id, item_id, quantity)
                  select u.id, it.id, 1 from u, public.items it where it.code = 'badge_pioneer')
            select id from u
            """,
            {"e": email, "n": username, "h": generate_password_hash(password), "r": role,
             "dn": display_name, "b": bonus},
        )
    except db.IntegrityError:
        raise APIError(409, "이미 사용 중인 이메일 또는 아이디입니다")
    uid = row["id"]
    if ref:
        inviter = sv.user_by_username(ref)
        if inviter and inviter["id"] != uid:
            try:
                db.execute("insert into public.friendships (requester_id, addressee_id) values (%(a)s, %(b)s)",
                           {"a": uid, "b": inviter["id"]})
                sv.notify(inviter["id"], "friend_request", f"초대한 {username}님이 가입해 친구 요청을 보냈습니다",
                          "#/friends", uid)
            except db.IntegrityError:
                pass
    start_session(uid)
    return ok({"ok": True, "csrf": csrf_token()}, 201)


@bp.post("/api/auth/login")
@rate_limit("login", 20, 900)
def login():
    d = body()
    ident = text(d, "login", max_len=254)
    password = d.get("password") or ""
    ip = client_ip()
    if limiter.count(f"login_fail:{ip}", 900) >= 8:
        raise APIError(429, "로그인 실패가 너무 많습니다. 15분 뒤에 다시 시도하세요")
    user = db.one(
        "select id, email, password_hash, status, role from public.users "
        "where lower(email) = lower(%(i)s) or lower(username) = lower(%(i)s) limit 1", {"i": ident})
    valid = check_password_hash(user["password_hash"] if user else _DUMMY_HASH, password)
    if not user or not valid:
        limiter.hit(f"login_fail:{ip}", 1000, 900)
        if limiter.count(f"login_fail:{ip}", 900) == 8:
            # 비정상 활동 감지 기록
            db.execute("insert into public.admin_logs (action, detail, ip) values "
                       "('security.login_fail_burst', '{\"count\": 8}'::jsonb, %(ip)s)", {"ip": ip[:64]})
        raise APIError(401, "아이디(이메일) 또는 비밀번호가 올바르지 않습니다")
    if user["status"] == "suspended":
        raise APIError(403, "정지된 계정입니다. 관리자에게 문의하세요")
    if user["status"] != "active":
        raise APIError(403, "사용할 수 없는 계정입니다")
    if user["role"] != "admin" and is_admin_email(user["email"]):
        db.execute("update public.users set role = 'admin' where id = %(u)s", {"u": user["id"]})
        db.execute("insert into public.admin_logs (admin_id, action, target_type, target_id, ip) "
                   "values (%(u)s, 'role.bootstrap_admin', 'user', %(u)s, %(ip)s)", {"u": user["id"], "ip": ip[:64]})
    db.execute("update public.users set last_login_at = now() where id = %(u)s", {"u": user["id"]})
    start_session(user["id"])
    return ok({"ok": True, "csrf": csrf_token()})


@bp.post("/api/auth/logout")
def logout():
    end_session()
    return ok({"ok": True, "csrf": csrf_token()})


@bp.post("/api/auth/password")
@login_required
@rate_limit("pwchange", 5, 600, per="user")
def change_password():
    d = body()
    cur = db.one("select password_hash from public.users where id = %(u)s", {"u": g.user["id"]})
    if not check_password_hash(cur["password_hash"], d.get("current") or ""):
        raise APIError(400, "현재 비밀번호가 올바르지 않습니다")
    _validate_password(d.get("new"))
    db.execute("update public.users set password_hash = %(h)s where id = %(u)s",
               {"h": generate_password_hash(d["new"]), "u": g.user["id"]})
    db.execute("update public.user_sessions set revoked_at = now() where user_id = %(u)s and revoked_at is null",
               {"u": g.user["id"]})
    start_session(g.user["id"])
    return ok({"ok": True, "csrf": csrf_token()})


# ---------------- 대시보드 ----------------

@bp.get("/api/me/dashboard")
@login_required
def dashboard():
    uid = g.user["id"]
    me_row = db.one(
        "select p.display_name, p.bio, p.title, p.level, p.exp, p.is_public, u.username, u.role, u.created_at, "
        "w.balance, a.color as avatar_color, a.body as avatar_body, a.equipped, "
        "exists (select 1 from public.transactions t where t.idempotency_key = %(k)s) as daily_claimed, "
        "(select count(*) from public.world_members where user_id = u.id) as worlds_visited, "
        "(select count(*) from public.friendships where status = 'accepted' and (requester_id = u.id or addressee_id = u.id)) as friends, "
        "(select count(*) from public.posts where author_id = u.id) as posts, "
        "(select count(*) from public.user_achievements where user_id = u.id) as achievements, "
        "(select count(*) from public.notifications where user_id = u.id and read_at is null) as unread "
        "from public.users u join public.user_profiles p on p.user_id = u.id "
        "left join public.wallets w on w.user_id = u.id left join public.avatars a on a.user_id = u.id "
        "where u.id = %(u)s", {"u": uid, "k": f"daily:{uid}:{sv.today_key()}"})
    daily_claimed = me_row.pop("daily_claimed")
    stats = {k: me_row.pop(k) for k in ("worlds_visited", "friends", "posts", "achievements", "unread")}
    quests = db.query(
        f"select q.code, q.title, q.description, q.reward_coins, q.reward_exp, q.is_daily, "
        f"coalesce(uq.status, 'in_progress') as status from public.quests q "
        f"left join public.user_quests uq on uq.quest_id = q.id and uq.user_id = %(u)s and uq.period = {sv.QUEST_PERIOD_SQL} "
        f"where q.is_active order by q.is_daily desc, q.id", {"u": uid})
    news = db.query("select id, title, body, created_at from public.announcements where is_published "
                    "order by created_at desc limit 3")
    next_level_exp = (me_row["level"] ** 2) * 100
    return ok({"me": me_row, "daily_claimed": daily_claimed, "quests": quests, "stats": stats,
               "announcements": news, "next_level_exp": next_level_exp,
               "daily_reward": int(setting("daily_reward", 0) or 0)})


# ---------------- 프로필 ----------------

@bp.get("/api/users/<username>")
@login_required
def profile(username):
    me_id = g.user["id"]
    u = sv.user_by_username(username)
    if not u or u["status"] != "active":
        raise APIError(404, "사용자를 찾을 수 없습니다")
    if u["id"] != me_id and sv.blocked_between(me_id, u["id"]):
        i_blocked = bool(db.scalar("select exists (select 1 from public.blocks where blocker_id = %(a)s and blocked_id = %(b)s) as x",
                                   {"a": me_id, "b": u["id"]}))
        return ok({"user": {"id": u["id"], "username": u["username"], "display_name": u["display_name"]},
                   "blocked": True, "i_blocked": i_blocked, "limited": True})
    is_self = u["id"] == me_id
    friendship = db.one(
        "select id, requester_id, status from public.friendships where "
        "least(requester_id, addressee_id) = least(%(a)s::bigint, %(b)s::bigint) and "
        "greatest(requester_id, addressee_id) = greatest(%(a)s::bigint, %(b)s::bigint)", {"a": me_id, "b": u["id"]})
    friend_state = "none"
    if friendship:
        if friendship["status"] == "accepted":
            friend_state = "friends"
        elif friendship["status"] == "pending":
            friend_state = "outgoing" if friendship["requester_id"] == me_id else "incoming"
    can_see = is_self or u["is_public"] or friend_state == "friends" or g.user["role"] in ("admin", "moderator")
    info = db.one(
        "select p.display_name, p.bio, p.title, p.level, p.exp, p.is_public, u.username, u.created_at, "
        "a.color as avatar_color, a.body as avatar_body, a.equipped, "
        "(select count(*) from public.follows where following_id = u.id) as followers, "
        "(select count(*) from public.follows where follower_id = u.id) as following, "
        "(select count(*) from public.friendships where status = 'accepted' and (requester_id = u.id or addressee_id = u.id)) as friends "
        "from public.users u join public.user_profiles p on p.user_id = u.id left join public.avatars a on a.user_id = u.id "
        "where u.id = %(u)s", {"u": u["id"]})
    following = bool(db.scalar("select exists (select 1 from public.follows where follower_id = %(a)s and following_id = %(b)s) as x",
                               {"a": me_id, "b": u["id"]}))
    result = {"user": {"id": u["id"], **info}, "is_self": is_self, "friend_state": friend_state,
              "friendship_id": friendship["id"] if friendship else None,
              "following": following, "limited": not can_see, "blocked": False}
    if can_see:
        result["achievements"] = db.query(
            "select a.code, a.title, a.icon, ua.earned_at from public.user_achievements ua "
            "join public.achievements a on a.id = ua.achievement_id where ua.user_id = %(u)s order by ua.earned_at",
            {"u": u["id"]})
        result["posts"] = db.query(sv.POST_SELECT_SQL + " where p.author_id = %(a)s and " + sv.VISIBLE_POST_SQL +
                                   " order by p.created_at desc limit 20", {"me": me_id, "a": u["id"]})
        result["worlds"] = db.query(
            "select w.slug, w.name, w.color, m.score from public.world_members m join public.worlds w on w.id = m.world_id "
            "where m.user_id = %(u)s order by m.score desc", {"u": u["id"]})
    return ok(result)


@bp.patch("/api/me/profile")
@login_required
def update_profile():
    d = body()
    uid = g.user["id"]
    fields, params = [], {"u": uid}
    if "display_name" in d:
        params["dn"] = text(d, "display_name", max_len=30)
        fields.append("display_name = %(dn)s")
    if "bio" in d:
        params["bio"] = text(d, "bio", required=False, min_len=0, max_len=500) or ""
        fields.append("bio = %(bio)s")
    if "is_public" in d:
        params["pub"] = bool(d["is_public"])
        fields.append("is_public = %(pub)s")
    if "title" in d:
        title = text(d, "title", required=False, min_len=0, max_len=60) or ""
        if title:
            earned = db.scalar(
                "select exists (select 1 from public.user_achievements ua join public.achievements a on a.id = ua.achievement_id "
                "where ua.user_id = %(u)s and a.title = %(t)s) as x", {"u": uid, "t": title})
            if not earned:
                raise APIError(400, "획득한 업적의 칭호만 쓸 수 있습니다")
        params["title"] = title or None
        fields.append("title = %(title)s")
    if not fields:
        raise APIError(400, "바꿀 내용이 없습니다")
    db.execute(f"update public.user_profiles set {', '.join(fields)} where user_id = %(u)s", params)
    return ok()


@bp.get("/api/me/settings")
@login_required
def get_settings():
    return ok(db.one("select language, theme, notify_email, notify_push from public.user_settings where user_id = %(u)s",
                     {"u": g.user["id"]}))


@bp.patch("/api/me/settings")
@login_required
def patch_settings():
    d = body()
    params = {"u": g.user["id"]}
    sets = []
    if "language" in d:
        params["lang"] = choice(d, "language", ("ko", "en"))
        sets.append("language = %(lang)s")
    if "theme" in d:
        params["theme"] = choice(d, "theme", THEMES)
        sets.append("theme = %(theme)s")
    for k in ("notify_email", "notify_push"):
        if k in d:
            params[k] = bool(d[k])
            sets.append(f"{k} = %({k})s")
    if not sets:
        raise APIError(400, "바꿀 내용이 없습니다")
    db.execute(f"update public.user_settings set {', '.join(sets)} where user_id = %(u)s", params)
    return ok()


@bp.get("/api/me/export")
@login_required
def export_me():
    """내 데이터 백업(JSON 다운로드)."""
    uid = g.user["id"]
    p = {"u": uid}
    data = {
        "account": db.one("select id, email, username, role, created_at from public.users where id = %(u)s", p),
        "profile": db.one("select * from public.user_profiles where user_id = %(u)s", p),
        "settings": db.one("select * from public.user_settings where user_id = %(u)s", p),
        "wallet": db.one("select balance, updated_at from public.wallets where user_id = %(u)s", p),
        "transactions": db.query("select kind, amount, balance_after, memo, created_at from public.transactions where user_id = %(u)s order by id", p),
        "inventory": db.query("select i.code, i.name, inv.quantity from public.inventory inv join public.items i on i.id = inv.item_id where inv.user_id = %(u)s", p),
        "posts": db.query("select id, content, visibility, created_at from public.posts where author_id = %(u)s order by id", p),
        "ai_memories": db.query("select content, importance, created_at from public.ai_memories where user_id = %(u)s", p),
        "projects": db.query("select id, title, kind, description, visibility, version, created_at from public.creator_projects where owner_id = %(u)s", p),
    }
    return ok(data)


# ---------------- 검색 ----------------

@bp.get("/api/search")
@login_required
@rate_limit("search", 60, 60, per="user")
def search():
    q = (request.args.get("q") or "").strip()[:50]
    if len(q) < 1:
        return ok({"users": [], "worlds": [], "games": [], "posts": []})
    pat = f"%{sv.like_escape(q)}%"
    me_id = g.user["id"]
    users = db.query(
        "select u.username, p.display_name, p.level from public.users u join public.user_profiles p on p.user_id = u.id "
        "where u.status = 'active' and (u.username ilike %(p)s or p.display_name ilike %(p)s) "
        "and not exists (select 1 from public.blocks b where (b.blocker_id = %(me)s and b.blocked_id = u.id) "
        "or (b.blocker_id = u.id and b.blocked_id = %(me)s)) order by p.level desc limit 10", {"p": pat, "me": me_id})
    worlds = db.query("select slug, name, theme, color from public.worlds where is_active and (name ilike %(p)s or description ilike %(p)s) limit 10", {"p": pat})
    games = db.query("select slug, title, category from public.games where status = 'published' and (title ilike %(p)s or description ilike %(p)s) limit 10", {"p": pat})
    posts = db.query(sv.POST_SELECT_SQL + " where p.content ilike %(p)s and " + sv.VISIBLE_POST_SQL +
                     " order by p.created_at desc limit 10", {"p": pat, "me": me_id})
    return ok({"users": users, "worlds": worlds, "games": games, "posts": posts})


# ---------------- 알림 / 공지 ----------------

@bp.get("/api/notifications")
@login_required
def notifications():
    limit, offset = page_args(30)
    rows = db.query(
        "select n.id, n.kind, n.message, n.link, n.read_at, n.created_at, u.username as actor "
        "from public.notifications n left join public.users u on u.id = n.actor_id "
        "where n.user_id = %(u)s order by n.created_at desc limit %(l)s offset %(o)s",
        {"u": g.user["id"], "l": limit, "o": offset})
    unread = db.scalar("select count(*) as n from public.notifications where user_id = %(u)s and read_at is null",
                       {"u": g.user["id"]})
    return ok({"items": rows, "unread": unread})


@bp.get("/api/me/summary")
@login_required
def summary():
    """상단바용: 코인과 읽지 않은 알림 수를 쿼리 1번으로"""
    return ok(db.one(
        "select (select balance from public.wallets where user_id = %(u)s) as balance, "
        "(select count(*) from public.notifications where user_id = %(u)s and read_at is null) as unread",
        {"u": g.user["id"]}))


@bp.post("/api/notifications/read-all")
@login_required
def read_all():
    db.execute("update public.notifications set read_at = now() where user_id = %(u)s and read_at is null",
               {"u": g.user["id"]})
    return ok()


@bp.get("/api/announcements")
def announcements():
    return ok(db.query("select id, title, body, created_at from public.announcements where is_published "
                       "order by created_at desc limit 20"))


@bp.get("/api/rankings")
@login_required
def rankings():
    levels = db.query(
        "select u.username, p.display_name, p.level, p.exp from public.user_profiles p join public.users u on u.id = p.user_id "
        "where u.status = 'active' order by p.exp desc, u.id limit 20")
    explorers = db.query(
        "select u.username, p.display_name, sum(m.score) as score, count(*) as worlds from public.world_members m "
        "join public.users u on u.id = m.user_id join public.user_profiles p on p.user_id = u.id "
        "where u.status = 'active' group by u.username, p.display_name order by score desc limit 20")
    creators = db.query(
        "select u.username, p.display_name, count(*) as projects, coalesce(sum(cp.rating_sum), 0) as stars "
        "from public.creator_projects cp join public.users u on u.id = cp.owner_id join public.user_profiles p on p.user_id = u.id "
        "where cp.visibility = 'public' and u.status = 'active' group by u.username, p.display_name order by stars desc, projects desc limit 20")
    return ok({"levels": levels, "explorers": explorers, "creators": creators})


@bp.get("/api/settings/public")
def public_settings():
    s = settings()
    return ok({"features": s.get("features", {}), "daily_reward": s.get("daily_reward"),
               "signup_bonus": s.get("signup_bonus"), "trade_daily_limit": s.get("trade_daily_limit")})

