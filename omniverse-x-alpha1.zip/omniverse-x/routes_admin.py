"""관리자: 통계, 사용자/권한, 신고, 공지, 기능 스위치, 아이템, 월드, 경제 조정, 활동 기록.

모든 쓰기 작업은 admin_logs에 남는다. 일반 사용자는 접근할 수 없다(admin_required).
"""
import json

from flask import Blueprint, g, request

import db
import services as sv
from security import (APIError, admin_required, body, choice, integer, ok, omni_to_api, page_args, settings,
                      staff_required, text)

bp = Blueprint("admin", __name__)

FEATURE_KEYS = ("ai", "world", "social", "games", "economy", "creator", "realtime_chat", "voice", "image_gen")
NUMBER_SETTINGS = {"signup_bonus": (0, 100000), "daily_reward": (0, 10000), "trade_daily_limit": (0, 10_000_000)}


@bp.get("/api/admin/stats")
@admin_required
def stats():
    s = db.one(
        "select (select count(*) from public.users) as users, "
        "(select count(*) from public.users where created_at > now() - interval '1 day') as signups_today, "
        "(select count(*) from public.users where status = 'suspended') as suspended, "
        "(select count(distinct user_id) from public.user_sessions where revoked_at is null and expires_at > now() "
        "   and created_at > now() - interval '7 days') as active_7d, "
        "(select count(*) from public.posts) as posts, "
        "(select count(*) from public.messages) as messages, "
        "(select count(*) from public.game_scores) as plays, "
        "(select coalesce(sum(balance), 0) from public.wallets) as coin_supply, "
        "(select count(*) from public.transactions where created_at > now() - interval '1 day') as tx_today, "
        "(select count(*) from public.reports where status in ('open','reviewing')) as open_reports, "
        "(select count(*) from public.creator_projects) as projects")
    daily = db.query(
        "select to_char(d, 'MM-DD') as day, "
        "(select count(*) from public.users u where u.created_at >= d and u.created_at < d + interval '1 day') as signups "
        "from generate_series(date_trunc('day', now()) - interval '6 days', date_trunc('day', now()), interval '1 day') d")
    economy = db.query("select kind, count(*) as n, sum(amount) as total from public.transactions group by kind order by kind")
    return ok({"stats": s, "daily": daily, "economy": economy})


@bp.get("/api/admin/users")
@admin_required
def users():
    q = (request.args.get("q") or "").strip()[:50]
    limit, offset = page_args(30, 100)
    rows = db.query(
        "select u.id, u.email, u.username, u.role, u.status, u.is_demo, u.created_at, u.last_login_at, "
        "p.level, w.balance, w.is_frozen from public.users u join public.user_profiles p on p.user_id = u.id "
        "left join public.wallets w on w.user_id = u.id "
        "where (%(q)s = '' or u.username ilike %(p)s or u.email ilike %(p)s) "
        "order by u.id desc limit %(l)s offset %(o)s",
        {"q": q, "p": f"%{sv.like_escape(q)}%", "l": limit, "o": offset})
    return ok(rows)


def _target_user(uid):
    u = db.one("select id, username, role, status from public.users where id = %(u)s", {"u": uid})
    if not u:
        raise APIError(404, "사용자를 찾을 수 없습니다")
    return u


@bp.post("/api/admin/users/<int:uid>/status")
@admin_required
def set_status(uid):
    u = _target_user(uid)
    status = choice(body(), "status", ("active", "suspended"))
    if u["id"] == g.user["id"]:
        raise APIError(400, "자기 계정은 정지할 수 없습니다")
    if u["role"] == "admin" and status == "suspended":
        raise APIError(400, "관리자 계정은 정지할 수 없습니다. 먼저 권한을 낮추세요")
    db.execute("update public.users set status = %(s)s where id = %(u)s", {"s": status, "u": uid})
    if status == "suspended":
        db.execute("update public.user_sessions set revoked_at = now() where user_id = %(u)s and revoked_at is null", {"u": uid})
    sv.admin_log(f"user.{'suspend' if status == 'suspended' else 'restore'}", "user", uid, {"username": u["username"]})
    return ok()


@bp.post("/api/admin/users/<int:uid>/role")
@admin_required
def set_role(uid):
    u = _target_user(uid)
    role = choice(body(), "role", ("user", "moderator", "admin"))
    if u["id"] == g.user["id"]:
        raise APIError(400, "자기 권한은 바꿀 수 없습니다")
    db.execute("update public.users set role = %(r)s where id = %(u)s", {"r": role, "u": uid})
    sv.admin_log("user.role", "user", uid, {"from": u["role"], "to": role})
    return ok()


@bp.post("/api/admin/users/<int:uid>/coins")
@admin_required
def adjust_coins(uid):
    _target_user(uid)
    d = body()
    amount = integer(d, "amount", lo=-1_000_000, hi=1_000_000)
    memo = text(d, "memo", max_len=100)
    try:
        bal = db.scalar("select public.omni_credit(%(u)s, %(a)s, 'admin_adjust', %(m)s, null) as b",
                        {"u": uid, "a": amount, "m": f"관리자 조정: {memo}"})
    except db.OmniError as e:
        raise omni_to_api(e)
    sv.admin_log("economy.adjust", "user", uid, {"amount": amount, "memo": memo})
    sv.notify(uid, "coins", f"관리자가 코인을 {amount:+d} 조정했습니다: {memo}", "#/wallet")
    return ok({"balance": bal})


@bp.post("/api/admin/users/<int:uid>/freeze")
@admin_required
def freeze(uid):
    _target_user(uid)
    frozen = bool(body().get("frozen"))
    db.execute("update public.wallets set is_frozen = %(f)s where user_id = %(u)s", {"f": frozen, "u": uid})
    sv.admin_log("economy.freeze" if frozen else "economy.unfreeze", "user", uid)
    return ok()


@bp.get("/api/admin/reports")
@staff_required
def reports():
    status = request.args.get("status", "open")
    if status not in ("open", "reviewing", "resolved", "rejected", "all"):
        raise APIError(400, "status 값이 올바르지 않습니다")
    return ok(db.query(
        "select r.id, r.target_type, r.target_id, r.reason, r.status, r.created_at, ru.username as reporter, hu.username as handler, "
        "case when r.target_type = 'post' then (select content from public.posts where id = r.target_id) "
        "     when r.target_type = 'comment' then (select content from public.comments where id = r.target_id) "
        "     when r.target_type = 'user' then (select username from public.users where id = r.target_id) end as preview "
        "from public.reports r join public.users ru on ru.id = r.reporter_id left join public.users hu on hu.id = r.handled_by "
        "where (%(s)s = 'all' or r.status = %(s)s) order by r.created_at desc limit 100", {"s": status}))


@bp.post("/api/admin/reports/<int:rid>")
@staff_required
def handle_report(rid):
    d = body()
    status = choice(d, "status", ("reviewing", "resolved", "rejected"))
    r = db.one("update public.reports set status = %(s)s, handled_by = %(h)s, handled_at = now() where id = %(r)s "
               "returning target_type, target_id", {"s": status, "h": g.user["id"], "r": rid})
    if not r:
        raise APIError(404, "신고를 찾을 수 없습니다")
    if d.get("hide_target") and r["target_type"] in ("post", "comment"):
        table = "posts" if r["target_type"] == "post" else "comments"
        db.execute(f"update public.{table} set is_hidden = true where id = %(i)s", {"i": r["target_id"]})
    sv.admin_log("report.handle", "report", rid, {"status": status, "hide": bool(d.get("hide_target"))})
    return ok()


@bp.get("/api/admin/announcements")
@admin_required
def list_announcements():
    return ok(db.query("select id, title, body, is_published, created_at from public.announcements order by id desc"))


@bp.post("/api/admin/announcements")
@admin_required
def create_announcement():
    d = body()
    row = db.one("insert into public.announcements (title, body, author_id) values (%(t)s, %(b)s, %(a)s) returning id",
                 {"t": text(d, "title", max_len=100), "b": text(d, "body", max_len=3000), "a": g.user["id"]})
    sv.admin_log("announcement.create", "announcement", row["id"])
    return ok(row, 201)


@bp.delete("/api/admin/announcements/<int:aid>")
@admin_required
def delete_announcement(aid):
    if not db.execute("delete from public.announcements where id = %(a)s", {"a": aid}):
        raise APIError(404, "공지를 찾을 수 없습니다")
    sv.admin_log("announcement.delete", "announcement", aid)
    return ok()


@bp.get("/api/admin/settings")
@admin_required
def get_settings():
    return ok(settings(refresh=True))


@bp.patch("/api/admin/settings")
@admin_required
def patch_settings():
    d = body()
    changed = {}
    if "features" in d:
        feats = d["features"]
        if not isinstance(feats, dict) or not set(feats) <= set(FEATURE_KEYS) or not all(isinstance(v, bool) for v in feats.values()):
            raise APIError(400, "features 값이 올바르지 않습니다")
        merged = {**(settings(refresh=True).get("features") or {}), **feats}
        db.execute("update public.system_settings set value = %(v)s::jsonb, updated_by = %(u)s where key = 'features'",
                   {"v": json.dumps(merged), "u": g.user["id"]})
        changed["features"] = feats
    for key, (lo, hi) in NUMBER_SETTINGS.items():
        if key in d:
            v = integer(d, key, lo=lo, hi=hi)
            db.execute("update public.system_settings set value = %(v)s::jsonb, updated_by = %(u)s where key = %(k)s",
                       {"v": json.dumps(v), "u": g.user["id"], "k": key})
            changed[key] = v
    if "maintenance" in d:
        db.execute("update public.system_settings set value = %(v)s::jsonb, updated_by = %(u)s where key = 'maintenance'",
                   {"v": json.dumps(bool(d["maintenance"])), "u": g.user["id"]})
        changed["maintenance"] = bool(d["maintenance"])
    if not changed:
        raise APIError(400, "바꿀 설정이 없습니다")
    sv.admin_log("settings.update", "system", None, changed)
    return ok(settings(refresh=True))


@bp.get("/api/admin/items")
@admin_required
def items():
    return ok(db.query("select id, code, name, category, rarity, price, tradable, is_active, description from public.items order by id"))


@bp.post("/api/admin/items")
@admin_required
def create_item():
    d = body()
    try:
        row = db.one(
            "insert into public.items (code, name, category, rarity, price, tradable, description) "
            "values (%(c)s, %(n)s, %(cat)s, %(r)s, %(p)s, %(t)s, %(d)s) returning id",
            {"c": text(d, "code", max_len=60), "n": text(d, "name", max_len=60),
             "cat": choice(d, "category", ("avatar", "game", "world", "badge", "consumable")),
             "r": choice(d, "rarity", ("common", "rare", "epic", "legendary"), default="common"),
             "p": integer(d, "price", lo=0, hi=1_000_000), "t": bool(d.get("tradable", True)),
             "d": text(d, "description", required=False, min_len=0, max_len=300)})
    except db.IntegrityError:
        raise APIError(409, "이미 있는 아이템 코드입니다")
    sv.admin_log("item.create", "item", row["id"])
    return ok(row, 201)


@bp.patch("/api/admin/items/<int:iid>")
@admin_required
def update_item(iid):
    d = body()
    sets, params = [], {"i": iid}
    if "price" in d:
        params["p"] = integer(d, "price", lo=0, hi=1_000_000)
        sets.append("price = %(p)s")
    if "is_active" in d:
        params["a"] = bool(d["is_active"])
        sets.append("is_active = %(a)s")
    if not sets:
        raise APIError(400, "바꿀 내용이 없습니다")
    if not db.execute(f"update public.items set {', '.join(sets)} where id = %(i)s", params):
        raise APIError(404, "아이템을 찾을 수 없습니다")
    sv.admin_log("item.update", "item", iid, {k: d[k] for k in ("price", "is_active") if k in d})
    return ok()


@bp.get("/api/admin/worlds")
@admin_required
def admin_worlds():
    return ok(db.query("select w.id, w.slug, w.name, w.theme, w.is_official, w.is_active, w.min_level, u.username as creator, "
                       "(select count(*) from public.world_members m where m.world_id = w.id) as members "
                       "from public.worlds w left join public.users u on u.id = w.creator_id order by w.id"))


@bp.patch("/api/admin/worlds/<int:wid>")
@admin_required
def update_world(wid):
    d = body()
    sets, params = [], {"w": wid}
    if "is_active" in d:
        params["a"] = bool(d["is_active"])
        sets.append("is_active = %(a)s")
    if "min_level" in d:
        params["m"] = integer(d, "min_level", lo=1, hi=100)
        sets.append("min_level = %(m)s")
    if not sets:
        raise APIError(400, "바꿀 내용이 없습니다")
    if not db.execute(f"update public.worlds set {', '.join(sets)} where id = %(w)s", params):
        raise APIError(404, "월드를 찾을 수 없습니다")
    sv.admin_log("world.update", "world", wid, {k: d[k] for k in ("is_active", "min_level") if k in d})
    return ok()


@bp.get("/api/admin/logs")
@admin_required
def logs():
    limit, offset = page_args(50, 200)
    return ok(db.query("select l.id, l.action, l.target_type, l.target_id, l.detail, l.ip, l.created_at, u.username as admin "
                       "from public.admin_logs l left join public.users u on u.id = l.admin_id "
                       "order by l.id desc limit %(l)s offset %(o)s", {"l": limit, "o": offset}))
