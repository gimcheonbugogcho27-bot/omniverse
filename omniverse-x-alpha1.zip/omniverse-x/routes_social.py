"""소셜: 친구, 팔로우, 차단, 신고, 게시물/댓글/좋아요, 커뮤니티, 1:1 메시지."""
import re

from flask import Blueprint, g, request

import db
import services as sv
from security import (APIError, body, choice, feature_required, integer, login_required, ok, page_args,
                      rate_limit, text)

bp = Blueprint("social", __name__)


def _target(username):
    u = sv.user_by_username(username)
    if not u or u["status"] != "active":
        raise APIError(404, "사용자를 찾을 수 없습니다")
    if u["id"] == g.user["id"]:
        raise APIError(400, "자기 자신에게는 할 수 없습니다")
    return u


# ---------------- 친구 ----------------

@bp.get("/api/friends")
@login_required
def friends():
    me = g.user["id"]
    rows = db.query(
        "select f.id, f.status, f.requester_id, f.created_at, u.id as user_id, u.username, p.display_name, p.level "
        "from public.friendships f "
        "join public.users u on u.id = case when f.requester_id = %(me)s then f.addressee_id else f.requester_id end "
        "join public.user_profiles p on p.user_id = u.id "
        "where (f.requester_id = %(me)s or f.addressee_id = %(me)s) and f.status in ('accepted','pending') "
        "and u.status = 'active' order by f.updated_at desc", {"me": me})
    out = {"friends": [], "incoming": [], "outgoing": []}
    for r in rows:
        if r["status"] == "accepted":
            out["friends"].append(r)
        elif r["requester_id"] == me:
            out["outgoing"].append(r)
        else:
            out["incoming"].append(r)
    return ok(out)


@bp.post("/api/friends/request")
@login_required
@rate_limit("friend_req", 30, 3600, per="user")
def friend_request():
    me = g.user["id"]
    u = _target(text(body(), "username", max_len=20))
    if sv.blocked_between(me, u["id"]):
        raise APIError(403, "친구 요청을 보낼 수 없습니다")
    existing = db.one(
        "select id, requester_id, status from public.friendships where "
        "least(requester_id, addressee_id) = least(%(a)s::bigint, %(b)s::bigint) and "
        "greatest(requester_id, addressee_id) = greatest(%(a)s::bigint, %(b)s::bigint)", {"a": me, "b": u["id"]})
    if existing:
        if existing["status"] == "accepted":
            raise APIError(409, "이미 친구입니다")
        if existing["status"] == "pending":
            if existing["requester_id"] == me:
                raise APIError(409, "이미 친구 요청을 보냈습니다")
            return _accept(existing["id"])  # 상대가 먼저 보낸 요청이 있으면 바로 수락
        db.execute("update public.friendships set requester_id = %(a)s, addressee_id = %(b)s, status = 'pending' "
                   "where id = %(id)s", {"a": me, "b": u["id"], "id": existing["id"]})
    else:
        try:
            db.execute("insert into public.friendships (requester_id, addressee_id) values (%(a)s, %(b)s)",
                       {"a": me, "b": u["id"]})
        except db.IntegrityError:
            raise APIError(409, "이미 요청이 있습니다")
    sv.notify(u["id"], "friend_request", f"{g.user['username']}님이 친구 요청을 보냈습니다", "#/friends", me)
    return ok({"ok": True, "state": "outgoing"}, 201)


def _accept(fid):
    me = g.user["id"]
    row = db.one("update public.friendships set status = 'accepted' where id = %(id)s and addressee_id = %(me)s "
                 "and status = 'pending' returning requester_id", {"id": fid, "me": me})
    if not row:
        raise APIError(404, "받은 친구 요청을 찾을 수 없습니다")
    sv.notify(row["requester_id"], "friend_accept", f"{g.user['username']}님이 친구 요청을 수락했습니다",
              f"#/u/{g.user['username']}", me)
    sv.check_social(me)
    sv.check_social(row["requester_id"])
    return ok({"ok": True, "state": "friends"})


@bp.post("/api/friends/<int:fid>/accept")
@login_required
def accept(fid):
    return _accept(fid)


@bp.post("/api/friends/<int:fid>/decline")
@login_required
def decline(fid):
    n = db.execute("update public.friendships set status = 'declined' where id = %(id)s and addressee_id = %(me)s "
                   "and status = 'pending'", {"id": fid, "me": g.user["id"]})
    if not n:
        raise APIError(404, "받은 친구 요청을 찾을 수 없습니다")
    return ok()


@bp.delete("/api/friends/<int:fid>")
@login_required
def unfriend(fid):
    """친구 끊기 또는 보낸 요청 취소"""
    n = db.execute("delete from public.friendships where id = %(id)s and (requester_id = %(me)s or addressee_id = %(me)s) "
                   "and status in ('accepted','pending')", {"id": fid, "me": g.user["id"]})
    if not n:
        raise APIError(404, "친구 관계를 찾을 수 없습니다")
    return ok()


# ---------------- 팔로우 / 차단 ----------------

@bp.post("/api/follow/<username>")
@login_required
def follow(username):
    u = _target(username)
    if sv.blocked_between(g.user["id"], u["id"]):
        raise APIError(403, "팔로우할 수 없습니다")
    row = db.one("insert into public.follows (follower_id, following_id) values (%(a)s, %(b)s) "
                 "on conflict do nothing returning follower_id", {"a": g.user["id"], "b": u["id"]})
    if row:
        sv.notify(u["id"], "follow", f"{g.user['username']}님이 회원님을 팔로우합니다", f"#/u/{g.user['username']}", g.user["id"])
    return ok({"following": True})


@bp.delete("/api/follow/<username>")
@login_required
def unfollow(username):
    u = _target(username)
    db.execute("delete from public.follows where follower_id = %(a)s and following_id = %(b)s",
               {"a": g.user["id"], "b": u["id"]})
    return ok({"following": False})


@bp.get("/api/blocks")
@login_required
def blocks():
    return ok(db.query("select u.username, p.display_name, b.created_at from public.blocks b "
                       "join public.users u on u.id = b.blocked_id join public.user_profiles p on p.user_id = u.id "
                       "where b.blocker_id = %(me)s order by b.created_at desc", {"me": g.user["id"]}))


@bp.post("/api/block/<username>")
@login_required
def block(username):
    me = g.user["id"]
    u = _target(username)
    db.execute("insert into public.blocks (blocker_id, blocked_id) values (%(a)s, %(b)s) on conflict do nothing",
               {"a": me, "b": u["id"]})
    db.execute("delete from public.friendships where least(requester_id, addressee_id) = least(%(a)s::bigint, %(b)s::bigint) "
               "and greatest(requester_id, addressee_id) = greatest(%(a)s::bigint, %(b)s::bigint)", {"a": me, "b": u["id"]})
    db.execute("delete from public.follows where (follower_id = %(a)s and following_id = %(b)s) "
               "or (follower_id = %(b)s and following_id = %(a)s)", {"a": me, "b": u["id"]})
    return ok({"blocked": True})


@bp.delete("/api/block/<username>")
@login_required
def unblock(username):
    u = _target(username)
    db.execute("delete from public.blocks where blocker_id = %(a)s and blocked_id = %(b)s",
               {"a": g.user["id"], "b": u["id"]})
    return ok({"blocked": False})


@bp.post("/api/reports")
@login_required
@rate_limit("report", 10, 3600, per="user")
def report():
    d = body()
    ttype = choice(d, "target_type", ("user", "post", "comment", "game", "world", "project"))
    tid = integer(d, "target_id", lo=1)
    reason = text(d, "reason", max_len=1000)
    db.execute("insert into public.reports (reporter_id, target_type, target_id, reason) values (%(r)s, %(t)s, %(i)s, %(m)s)",
               {"r": g.user["id"], "t": ttype, "i": tid, "m": reason})
    return ok({"ok": True}, 201)


# ---------------- 게시물 ----------------

@bp.get("/api/feed")
@login_required
@feature_required("social")
def feed():
    me = g.user["id"]
    scope = request.args.get("scope", "all")
    limit, offset = page_args(20)
    extra = ""
    if scope == "following":
        extra = " and (p.author_id = %(me)s or p.author_id in (select following_id from public.follows where follower_id = %(me)s))"
    elif scope == "friends":
        extra = (" and (p.author_id = %(me)s or p.author_id in (select case when requester_id = %(me)s then addressee_id "
                 "else requester_id end from public.friendships where status = 'accepted' and (requester_id = %(me)s or addressee_id = %(me)s)))")
    rows = db.query(sv.POST_SELECT_SQL + " where p.community_id is null and " + sv.VISIBLE_POST_SQL + extra +
                    " order by p.created_at desc limit %(l)s offset %(o)s", {"me": me, "l": limit, "o": offset})
    return ok({"items": rows})


def _image_url(d):
    url = text(d, "image_url", required=False, min_len=0, max_len=500)
    if url and not re.match(r"^https://[^\s\"'<>]+$", url):
        raise APIError(400, "이미지 주소는 https:// 로 시작해야 합니다")
    return url or None


@bp.post("/api/posts")
@login_required
@feature_required("social")
@rate_limit("post", 10, 60, per="user")
def create_post():
    d = body()
    me = g.user["id"]
    content = text(d, "content", max_len=5000)
    vis = choice(d, "visibility", ("public", "friends", "private"), default="public")
    cid = integer(d, "community_id", required=False, lo=1)
    if cid:
        member = db.scalar("select exists (select 1 from public.community_members where community_id = %(c)s and user_id = %(u)s) as x",
                           {"c": cid, "u": me})
        if not member:
            raise APIError(403, "커뮤니티 멤버만 글을 쓸 수 있습니다")
    row = db.one("insert into public.posts (author_id, community_id, content, image_url, visibility) "
                 "values (%(a)s, %(c)s, %(t)s, %(i)s, %(v)s) returning id",
                 {"a": me, "c": cid, "t": content, "i": _image_url(d), "v": vis})
    sv.complete_quest(me, "first_post")
    return ok({"id": row["id"]}, 201)


def _visible_post(pid):
    post = db.one(sv.POST_SELECT_SQL + " where p.id = %(id)s and " + sv.VISIBLE_POST_SQL, {"me": g.user["id"], "id": pid})
    if not post:
        raise APIError(404, "게시물을 찾을 수 없습니다")
    return post


@bp.delete("/api/posts/<int:pid>")
@login_required
def delete_post(pid):
    me = g.user
    n = db.execute("delete from public.posts where id = %(id)s and (author_id = %(me)s or %(staff)s)",
                   {"id": pid, "me": me["id"], "staff": me["role"] in ("admin", "moderator")})
    if not n:
        raise APIError(404, "삭제할 수 있는 게시물이 없습니다")
    if me["role"] in ("admin", "moderator"):
        sv.admin_log("post.delete", "post", pid)
    return ok()


@bp.post("/api/posts/<int:pid>/like")
@login_required
def like(pid):
    post = _visible_post(pid)
    row = db.one("insert into public.likes (user_id, post_id) values (%(u)s, %(p)s) on conflict do nothing returning post_id",
                 {"u": g.user["id"], "p": pid})
    if row:
        db.execute("update public.posts set like_count = like_count + 1 where id = %(p)s", {"p": pid})
        sv.notify(post["author_id"], "like", f"{g.user['username']}님이 게시물을 좋아합니다", "#/feed", g.user["id"])
    return ok({"liked": True, "like_count": db.scalar("select like_count from public.posts where id = %(p)s", {"p": pid})})


@bp.delete("/api/posts/<int:pid>/like")
@login_required
def unlike(pid):
    row = db.one("delete from public.likes where user_id = %(u)s and post_id = %(p)s returning post_id",
                 {"u": g.user["id"], "p": pid})
    if row:
        db.execute("update public.posts set like_count = greatest(like_count - 1, 0) where id = %(p)s", {"p": pid})
    return ok({"liked": False, "like_count": db.scalar("select like_count from public.posts where id = %(p)s", {"p": pid})})


@bp.get("/api/posts/<int:pid>/comments")
@login_required
def comments(pid):
    _visible_post(pid)
    return ok(db.query(
        "select c.id, c.content, c.created_at, u.username, p.display_name, c.author_id from public.comments c "
        "join public.users u on u.id = c.author_id join public.user_profiles p on p.user_id = u.id "
        "where c.post_id = %(p)s and not c.is_hidden and u.status = 'active' "
        "and not exists (select 1 from public.blocks b where (b.blocker_id = %(me)s and b.blocked_id = c.author_id) "
        "or (b.blocker_id = c.author_id and b.blocked_id = %(me)s)) order by c.created_at", {"p": pid, "me": g.user["id"]}))


@bp.post("/api/posts/<int:pid>/comments")
@login_required
@rate_limit("comment", 20, 60, per="user")
def add_comment(pid):
    post = _visible_post(pid)
    content = text(body(), "content", max_len=1000)
    row = db.one("insert into public.comments (post_id, author_id, content) values (%(p)s, %(a)s, %(c)s) returning id",
                 {"p": pid, "a": g.user["id"], "c": content})
    db.execute("update public.posts set comment_count = comment_count + 1 where id = %(p)s", {"p": pid})
    sv.notify(post["author_id"], "comment", f"{g.user['username']}님이 댓글을 남겼습니다: {content[:40]}", "#/feed", g.user["id"])
    return ok({"id": row["id"]}, 201)


@bp.delete("/api/comments/<int:cid>")
@login_required
def delete_comment(cid):
    me = g.user
    row = db.one("delete from public.comments where id = %(id)s and (author_id = %(me)s or %(staff)s) returning post_id",
                 {"id": cid, "me": me["id"], "staff": me["role"] in ("admin", "moderator")})
    if not row:
        raise APIError(404, "삭제할 수 있는 댓글이 없습니다")
    db.execute("update public.posts set comment_count = greatest(comment_count - 1, 0) where id = %(p)s", {"p": row["post_id"]})
    return ok()


# ---------------- 커뮤니티 ----------------

@bp.get("/api/communities")
@login_required
def communities():
    return ok(db.query(
        "select c.id, c.slug, c.name, c.description, c.created_at, "
        "(select count(*) from public.community_members m where m.community_id = c.id) as members, "
        "exists (select 1 from public.community_members m where m.community_id = c.id and m.user_id = %(me)s) as joined "
        "from public.communities c order by members desc, c.created_at desc limit 50", {"me": g.user["id"]}))


@bp.post("/api/communities")
@login_required
@rate_limit("community_new", 3, 3600, per="user")
def create_community():
    d = body()
    name = text(d, "name", min_len=2, max_len=40)
    slug = text(d, "slug", min_len=2, max_len=40).lower()
    if not re.match(r"^[a-z0-9-]{2,40}$", slug):
        raise APIError(400, "주소(slug)는 영문 소문자, 숫자, - 만 쓸 수 있습니다")
    desc = text(d, "description", required=False, min_len=0, max_len=300)
    try:
        row = db.one("insert into public.communities (slug, name, description, owner_id) values (%(s)s, %(n)s, %(d)s, %(o)s) returning id",
                     {"s": slug, "n": name, "d": desc, "o": g.user["id"]})
    except db.IntegrityError:
        raise APIError(409, "이미 있는 주소입니다")
    db.execute("insert into public.community_members (community_id, user_id, role) values (%(c)s, %(u)s, 'owner')",
               {"c": row["id"], "u": g.user["id"]})
    return ok({"id": row["id"], "slug": slug}, 201)


def _community(slug):
    c = db.one("select id, slug, name, description, owner_id, created_at from public.communities where slug = %(s)s", {"s": slug})
    if not c:
        raise APIError(404, "커뮤니티를 찾을 수 없습니다")
    return c


@bp.get("/api/communities/<slug>")
@login_required
def community(slug):
    c = _community(slug)
    me = g.user["id"]
    c["joined"] = bool(db.scalar("select exists (select 1 from public.community_members where community_id = %(c)s and user_id = %(u)s) as x",
                                 {"c": c["id"], "u": me}))
    c["members"] = db.scalar("select count(*) as n from public.community_members where community_id = %(c)s", {"c": c["id"]})
    posts = db.query(sv.POST_SELECT_SQL + " where p.community_id = %(c)s and " + sv.VISIBLE_POST_SQL +
                     " order by p.created_at desc limit 30", {"me": me, "c": c["id"]})
    return ok({"community": c, "posts": posts})


@bp.post("/api/communities/<slug>/join")
@login_required
def join_community(slug):
    c = _community(slug)
    db.execute("insert into public.community_members (community_id, user_id) values (%(c)s, %(u)s) on conflict do nothing",
               {"c": c["id"], "u": g.user["id"]})
    return ok({"joined": True})


@bp.post("/api/communities/<slug>/leave")
@login_required
def leave_community(slug):
    c = _community(slug)
    if c["owner_id"] == g.user["id"]:
        raise APIError(400, "만든 사람은 커뮤니티를 떠날 수 없습니다")
    db.execute("delete from public.community_members where community_id = %(c)s and user_id = %(u)s",
               {"c": c["id"], "u": g.user["id"]})
    return ok({"joined": False})


# ---------------- 1:1 메시지 ----------------

def _dm(cid):
    conv = db.one("select id, owner_id, peer_id from public.conversations where id = %(c)s and kind = 'direct' "
                  "and (owner_id = %(me)s or peer_id = %(me)s)", {"c": cid, "me": g.user["id"]})
    if not conv:
        raise APIError(404, "대화를 찾을 수 없습니다")
    conv["other_id"] = conv["peer_id"] if conv["owner_id"] == g.user["id"] else conv["owner_id"]
    return conv


@bp.get("/api/dm")
@login_required
def dm_list():
    me = g.user["id"]
    return ok(db.query(
        "select c.id, c.updated_at, u.username, p.display_name, "
        "(select content from public.messages m where m.conversation_id = c.id order by m.id desc limit 1) as last_message, "
        "(select count(*) from public.messages m where m.conversation_id = c.id and m.sender_id <> %(me)s and m.read_at is null) as unread "
        "from public.conversations c "
        "join public.users u on u.id = case when c.owner_id = %(me)s then c.peer_id else c.owner_id end "
        "join public.user_profiles p on p.user_id = u.id "
        "where c.kind = 'direct' and (c.owner_id = %(me)s or c.peer_id = %(me)s) order by c.updated_at desc limit 50", {"me": me}))


@bp.post("/api/dm/start")
@login_required
def dm_start():
    me = g.user["id"]
    u = _target(text(body(), "username", max_len=20))
    if sv.blocked_between(me, u["id"]):
        raise APIError(403, "메시지를 보낼 수 없습니다")
    conv = db.one("select id from public.conversations where kind = 'direct' and ((owner_id = %(a)s and peer_id = %(b)s) "
                  "or (owner_id = %(b)s and peer_id = %(a)s))", {"a": me, "b": u["id"]})
    if not conv:
        conv = db.one("insert into public.conversations (kind, owner_id, peer_id) values ('direct', %(a)s, %(b)s) returning id",
                      {"a": me, "b": u["id"]})
    return ok({"id": conv["id"]})


@bp.get("/api/dm/<int:cid>/messages")
@login_required
def dm_messages(cid):
    conv = _dm(cid)
    after = request.args.get("after", "0")
    after = int(after) if after.isdigit() else 0
    rows = db.query("select m.id, m.content, m.created_at, m.sender_id, u.username from public.messages m "
                    "left join public.users u on u.id = m.sender_id where m.conversation_id = %(c)s and m.id > %(a)s "
                    "order by m.id limit 200", {"c": cid, "a": after})
    db.execute("update public.messages set read_at = now() where conversation_id = %(c)s and sender_id <> %(me)s and read_at is null",
               {"c": cid, "me": g.user["id"]})
    other = db.one("select u.username, p.display_name from public.users u join public.user_profiles p on p.user_id = u.id "
                   "where u.id = %(o)s", {"o": conv["other_id"]})
    return ok({"items": rows, "other": other})


@bp.post("/api/dm/<int:cid>/messages")
@login_required
@rate_limit("dm", 30, 60, per="user")
def dm_send(cid):
    conv = _dm(cid)
    if sv.blocked_between(g.user["id"], conv["other_id"]):
        raise APIError(403, "메시지를 보낼 수 없습니다")
    content = text(body(), "content", max_len=2000)
    row = db.one("insert into public.messages (conversation_id, sender_id, role, content) values (%(c)s, %(s)s, 'user', %(t)s) "
                 "returning id, created_at", {"c": cid, "s": g.user["id"], "t": content})
    db.execute("update public.conversations set updated_at = now() where id = %(c)s", {"c": cid})
    sv.notify(conv["other_id"], "message", f"{g.user['username']}님의 메시지: {content[:40]}", f"#/messages/{cid}", g.user["id"])
    return ok(row, 201)
