"""OMNIVERSE X ALPHA 1.0 — Flask 애플리케이션 진입점 (gunicorn app:app)."""
import datetime
import decimal
import logging
import os
import secrets

from flask import Flask, g, jsonify, request
from flask.json.provider import DefaultJSONProvider
from werkzeug.exceptions import HTTPException
from werkzeug.middleware.proxy_fix import ProxyFix

import db
import routes_admin
import routes_ai
import routes_core
import routes_creator
import routes_economy
import routes_games
import routes_social
import routes_world
from security import APIError, check_csrf, load_user, setting

VERSION = "ALPHA 1.0"
ASSET_VERSION = "1.0.2"
HERE = os.path.dirname(os.path.abspath(__file__))
log = logging.getLogger("omniverse")


class JSONProvider(DefaultJSONProvider):
    ensure_ascii = False

    @staticmethod
    def default(o):
        if isinstance(o, (datetime.datetime, datetime.date)):
            return o.isoformat()
        if isinstance(o, decimal.Decimal):
            return int(o) if o == o.to_integral_value() else float(o)
        return DefaultJSONProvider.default(o)


def create_app():
    app = Flask(__name__, static_folder="static", template_folder="templates")
    app.json = JSONProvider(app)
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)

    secret = os.environ.get("SECRET_KEY")
    if not secret:
        log.warning("SECRET_KEY가 없어 임시 키를 사용합니다. 재시작하면 모두 로그아웃됩니다.")
        secret = secrets.token_hex(32)
    app.config.update(
        SECRET_KEY=secret,
        SESSION_COOKIE_NAME="omni_session",
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE", "1") == "1",
        PERMANENT_SESSION_LIFETIME=datetime.timedelta(days=30),
        MAX_CONTENT_LENGTH=2 * 1024 * 1024,
        JSON_SORT_KEYS=False,
        SEND_FILE_MAX_AGE_DEFAULT=60 * 60 * 24 * 7,
    )

    for mod in (routes_core, routes_social, routes_world, routes_economy, routes_ai, routes_games, routes_creator, routes_admin):
        app.register_blueprint(mod.bp)

    @app.before_request
    def before():
        g.user = None
        if not request.path.startswith("/api/"):
            return None
        load_user()
        check_csrf()
        if request.method != "GET" and not request.path.startswith("/api/auth/") and setting("maintenance", False):
            if not (g.user and g.user["role"] == "admin"):
                raise APIError(503, "서비스 점검 중입니다. 잠시 후 이용하세요", "maintenance")
        return None

    @app.after_request
    def headers(resp):
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        resp.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
        resp.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
        resp.headers.setdefault(
            "Content-Security-Policy",
            "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; "
            "connect-src 'self'; frame-src 'self'; font-src 'self' data:; object-src 'none'; base-uri 'self'; "
            "form-action 'self'; frame-ancestors 'self'")
        resp.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        if request.path.startswith("/api/"):
            resp.headers.setdefault("Cache-Control", "no-store")
        return resp

    @app.errorhandler(APIError)
    def api_error(e):
        return jsonify({"error": e.message, "code": e.code}), e.status

    @app.errorhandler(db.DBError)
    def db_error(e):
        log.exception("DB 오류")
        return jsonify({"error": "데이터베이스 처리 중 오류가 발생했습니다", "code": "db_error"}), 500

    @app.errorhandler(HTTPException)
    def http_error(e):
        if request.path.startswith("/api/"):
            return jsonify({"error": e.description or e.name, "code": "http_%d" % e.code}), e.code
        return e

    @app.errorhandler(Exception)
    def unexpected(e):
        log.exception("처리하지 못한 오류")
        if request.path.startswith("/api/"):
            return jsonify({"error": "서버 오류가 발생했습니다", "code": "server_error"}), 500
        return "서버 오류가 발생했습니다", 500

    @app.get("/healthz")
    def healthz():
        try:
            db_ok = db.ping()
        except Exception:
            db_ok = False
        return jsonify({"status": "ok" if db_ok else "degraded", "db": db_ok, "version": VERSION}), (200 if db_ok else 503)

    @app.get("/")
    @app.get("/app")
    def index():
        with open(os.path.join(HERE, "templates", "index.html"), encoding="utf-8") as fh:
            html = fh.read().replace("{{v}}", ASSET_VERSION)
        resp = app.response_class(html, mimetype="text/html")
        resp.headers["Cache-Control"] = "no-cache"
        return resp

    return app


app = create_app()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "5000")), debug=os.environ.get("FLASK_DEBUG") == "1")
