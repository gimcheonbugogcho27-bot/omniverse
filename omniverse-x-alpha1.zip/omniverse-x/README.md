# OMNIVERSE X · ALPHA 1.0

AI, 3D 행성 월드, 게임 센터, 소셜 네트워크, 가상 경제, 창작 도구를 하나의 계정과 PostgreSQL 데이터베이스로 연결한 반응형 웹 플랫폼입니다.

- **백엔드**: Python 3.12 · Flask 3 · gunicorn · psycopg2 (PostgreSQL / Supabase)
- **프론트엔드**: HTML · CSS · JavaScript (빌드 도구 없음, 해시 라우팅 SPA)
- **디자인**: 미래형 3D 글래스모피즘. 움직이는 은하수 캔버스, CSS 3D 행성, 마우스에 반응하는 3D 기울기 카드, 테마 3종
- **AI**: Gemini REST API (`GEMINI_API_KEY`가 없으면 '미설정'으로 명확히 표시)

## 폴더 구조

```
omniverse-x/
├─ app.py              Flask 앱 (gunicorn app:app), 보안 헤더, 오류 처리, /healthz
├─ db.py               PostgreSQL 연결 풀, 쿼리 함수 (자리표시자만 사용 → SQL Injection 방지)
├─ security.py         세션, CSRF, 요청 제한, 입력값 검증, 권한 데코레이터, 시스템 설정 캐시
├─ services.py         알림, 퀘스트, 업적, 경험치, 관리자 기록, 게시물 가시성 규칙
├─ migrate.py          마이그레이션 실행기 (적용 기록: schema_migrations)
├─ routes_core.py      회원가입·로그인·로그아웃·비밀번호, 대시보드, 프로필, 설정, 검색, 알림, 공지, 랭킹, 내 데이터 내보내기
├─ routes_social.py    친구, 팔로우, 차단, 신고, 피드·게시물·댓글·좋아요, 커뮤니티, 1:1 메시지
├─ routes_world.py     월드 목록·입장·탐험 점수·사용자 월드, 아바타, 퀘스트, 업적
├─ routes_economy.py   지갑, 출석 보상, 송금(하루 한도), 상점, 인벤토리
├─ routes_ai.py        AI 채팅(5가지 모드), 대화 기록, 개인 기억, 프롬프트 라이브러리
├─ routes_games.py     게임 목록, 점수 저장, 랭킹, 즐겨찾기
├─ routes_creator.py   프로젝트·파일, 템플릿, 샌드박스 미리보기, 갤러리, 평가, 버전, 내보내기/가져오기, AI 생성
├─ routes_admin.py     통계, 사용자·권한·정지, 코인 조정·지갑 동결, 신고, 공지, 기능 스위치, 아이템, 월드, 활동 기록
├─ migrations/         0001~0005 SQL (테이블 38개, 외래 키, 인덱스, RLS, 경제 함수, 기본 데이터)
├─ templates/index.html
├─ static/css/style.css, static/js/{app,games,space}.js
└─ tests/              실제 PostgreSQL 대상 통합 테스트 20개
```

## 실제로 작동하는 기능 (ALPHA 1.0)

| 영역 | 기능 |
|---|---|
| 계정·보안 | 회원가입, 로그인(아이디/이메일), 로그아웃, 비밀번호 변경(다른 세션 종료), scrypt 비밀번호 해시, DB 세션(30일·폐기 가능), CSRF 토큰, 요청 제한, 로그인 실패 8회 잠금 + 관리자 기록, 정지 계정 차단, CSP·보안 헤더 |
| 대시보드 | 레벨·경험치 바, 코인, 출석 체크, 오늘의 퀘스트, 통계, 공지 |
| OMNI AI | Gemini 채팅, 모드(대화·코드·문서·게임 제작·학습), 대화 기록, 개인 기억, 프롬프트 라이브러리, 하루 사용 한도 |
| WORLD | 5개 공식 행성(레벨 잠금), 공전하는 은하 지도, 입장·첫 착륙 퀘스트, 에너지 수집 탐험 게임, 월드 순위표, 사용자 제작 월드 |
| 성장 | 레벨·경험치, 퀘스트(일일·일반) 보상 수령, 업적 자동 달성, 칭호, 아바타(모습·색·장착 아이템) |
| SOCIAL | 프로필(공개/비공개), 친구 요청·수락·거절·끊기, 팔로우, 차단, 신고, 피드(전체·팔로잉·친구), 게시물 공개 범위, 댓글, 좋아요, 공유, 커뮤니티, 1:1 메시지(4초 폴링), 초대 링크, 통합 검색, 알림 센터 |
| GAME CENTER | 스타 캐처·메모리 오빗·타이핑 워프, 점수 저장·랭킹·즐겨찾기·플레이 수, 사용자 제작 게임 목록 |
| ECONOMY | 가상 코인 지갑, 거래 기록, 출석 보상, 송금(하루 한도, 원자적 처리), 상점·인벤토리, 동결 |
| CREATOR | 프로젝트(앱·게임·웹·월드), 템플릿 4종, 코드 편집기, 샌드박스 미리보기, AI로 index.html 생성, 공개·평가, 버전, JSON 내보내기/가져오기 |
| ADMIN | 통계·7일 가입 그래프·경제 통계, 사용자 검색·권한·정지/복구·코인 조정·지갑 동결, 신고 처리(게시물 숨김), 공지, 기능 스위치·점검 모드·경제 수치, 아이템·월드 관리, 활동 기록 |

## 미구현(화면에 '준비 중'으로 표시)

WebGL 3D 월드, 보스·월드 이벤트, 멀티플레이, 시즌 패스, AI 에이전트·이미지 생성·음성, 실시간 WebSocket 채팅, 클랜·길드, 아이템 직거래, 플러그인, 공개 API·키 관리, 영어 UI, 데이터 복원, 이메일 발송. 실제 현금 결제·환전은 법률·보안 검토 전까지 구현하지 않습니다.

## Render 배포

1. 저장소에 이 폴더를 압축한 `omniverse-x-alpha1.zip`을 올립니다 (또는 압축을 푼 소스를 그대로 올리고 이 폴더의 `render.yaml` 사용).
2. Render → New → Web Service → 저장소 선택
   - Runtime: **Python 3**, Region: Singapore
   - Build Command: `python3 -m zipfile -e omniverse-x-alpha1.zip . && pip install -r omniverse-x/requirements.txt`
   - Start Command: `cd omniverse-x && python migrate.py && gunicorn app:app --workers 1 --threads 4 --timeout 120 --bind 0.0.0.0:$PORT`
   - Health Check Path: `/healthz`
3. Environment 탭에 환경변수를 넣습니다 (`.env.example` 참고).

| 변수 | 설명 |
|---|---|
| `DATABASE_URL` | Supabase **Session pooler** 주소 (Render는 IPv4라 Direct 연결 불가). `[ ]` 없이 비밀번호를 넣습니다 |
| `SECRET_KEY` | 긴 임의 문자열. 바꾸면 모두 로그아웃됩니다 |
| `GEMINI_API_KEY` | Google AI Studio API 키 |
| `GEMINI_MODEL` | 기본 `gemini-2.5-flash` |
| `ADMIN_EMAILS` | 이 이메일 계정이 관리자가 됩니다. **먼저 이 이메일로 직접 가입한 뒤** 넣는 것이 안전합니다 |
| `PYTHON_VERSION` | `3.12.7` |

시작할 때 `migrate.py`가 실행되어 아직 적용하지 않은 마이그레이션만 적용합니다(이미 있는 테이블은 기록만 남김). 서버를 다시 시작해도 데이터는 PostgreSQL에 그대로 남습니다.

## 로컬 실행

```bash
pip install -r requirements-dev.txt
export DATABASE_URL=postgresql://postgres@localhost:5432/omniverse SECRET_KEY=dev COOKIE_SECURE=0
python migrate.py && python app.py   # http://localhost:5000
```

## 테스트

빈 테스트 전용 데이터베이스를 준비한 뒤:

```bash
OMNI_TEST_DATABASE_URL=postgresql://postgres@localhost:5432/omni_test pytest -q
```

psycopg2를 쓸 수 없는 환경에서는 `OMNI_TEST_PSQL="psql -h HOST -U postgres"`로 psql 명령을 통해 실행할 수 있습니다(테스트 DB를 자동 생성·삭제).
