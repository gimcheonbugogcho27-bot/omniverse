"""데이터베이스 마이그레이션 실행기.

python migrate.py  → migrations/*.sql 중 아직 적용하지 않은 파일을 순서대로 적용한다.
Supabase MCP 등으로 이미 적용된 DB라면 객체 존재 여부를 보고 기록만 남긴다(baseline).
각 파일과 적용 기록은 하나의 트랜잭션으로 실행된다.
"""
import os
import sys

import db

HERE = os.path.dirname(os.path.abspath(__file__))
MIG_DIR = os.path.join(HERE, "migrations")

# 이 마이그레이션이 이미 적용되었는지 판단하는 SQL (true면 적용된 것으로 기록)
BASELINE_CHECKS = {
    "0001_core_users_social_ai": "select to_regclass('public.ai_memories') is not null as x",
    "0002_world_economy_game": "select to_regclass('public.game_favorites') is not null as x",
    "0003_community_creator_admin": "select to_regclass('public.announcements') is not null as x",
    "0004_seed_official_content": "select exists (select 1 from public.system_settings where key = 'features') as x",
    "0005_economy_functions": "select to_regclass('public.project_ratings') is not null as x",
}


def migration_files():
    names = sorted(f for f in os.listdir(MIG_DIR) if f.endswith(".sql"))
    return [(n[:-4], os.path.join(MIG_DIR, n)) for n in names]


def applied_versions():
    db.execute("create table if not exists public.schema_migrations ("
               "version text primary key, applied_at timestamptz not null default now())")
    return {r["version"] for r in db.query("select version from public.schema_migrations")}


def run(verbose=True):
    done = applied_versions()
    applied = []
    for version, path in migration_files():
        if version in done:
            continue
        check = BASELINE_CHECKS.get(version)
        if check:
            try:
                exists = db.scalar(check)
            except db.DBError:
                exists = False
            if exists:
                db.execute("insert into public.schema_migrations (version) values (%(v)s) on conflict do nothing",
                           {"v": version})
                if verbose:
                    print(f"[migrate] {version}: 이미 존재 → 기록만 남김")
                continue
        with open(path, encoding="utf-8") as fh:
            sql = fh.read()
        safe_version = version.replace("'", "")
        db.execute(sql + f"\n;insert into public.schema_migrations (version) values ('{safe_version}');")
        applied.append(version)
        if verbose:
            print(f"[migrate] {version}: 적용 완료")
    if verbose and not applied:
        print("[migrate] 적용할 마이그레이션이 없습니다")
    return applied


if __name__ == "__main__":
    try:
        run()
    except Exception as exc:  # 배포 로그에서 원인을 바로 볼 수 있게
        print(f"[migrate] 실패: {exc}", file=sys.stderr)
        sys.exit(1)
