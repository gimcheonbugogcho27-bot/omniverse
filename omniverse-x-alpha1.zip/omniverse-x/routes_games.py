"""게임 센터: 게임 목록, 점수 저장, 랭킹, 즐겨찾기. 사용자 제작 게임은 크리에이터의 공개 'game' 프로젝트."""
from flask import Blueprint, g

import db
import services as sv
from security import APIError, body, feature_required, integer, login_required, ok, rate_limit

bp = Blueprint("games", __name__)

SCORE_CAPS = {"star-catcher": 5000, "memory-orbit": 2000, "type-warp": 5000}


def _game(slug):
    gm = db.one("select id, slug, title, category, description, is_official, play_count, created_at "
                "from public.games where slug = %(s)s and status = 'published'", {"s": slug})
    if not gm:
        raise APIError(404, "게임을 찾을 수 없습니다")
    return gm


@bp.get("/api/games")
@login_required
@feature_required("games")
def games():
    me = g.user["id"]
    official = db.query(
        "select gm.id, gm.slug, gm.title, gm.category, gm.description, gm.play_count, "
        "(select max(score) from public.game_scores s where s.game_id = gm.id and s.user_id = %(u)s) as my_best, "
        "exists (select 1 from public.game_favorites f where f.game_id = gm.id and f.user_id = %(u)s) as favorite "
        "from public.games gm where gm.status = 'published' order by gm.id", {"u": me})
    community = db.query(
        "select cp.id, cp.title, cp.description, cp.version, cp.rating_sum, cp.rating_count, u.username as creator "
        "from public.creator_projects cp join public.users u on u.id = cp.owner_id "
        "where cp.kind = 'game' and cp.visibility = 'public' and u.status = 'active' "
        "order by cp.rating_sum desc, cp.updated_at desc limit 30")
    return ok({"official": official, "community": community})


@bp.get("/api/games/<slug>")
@login_required
@feature_required("games")
def game(slug):
    gm = _game(slug)
    board = db.query(
        "select u.username, p.display_name, max(s.score) as score from public.game_scores s "
        "join public.users u on u.id = s.user_id join public.user_profiles p on p.user_id = u.id "
        "where s.game_id = %(g)s and u.status = 'active' group by u.username, p.display_name "
        "order by score desc limit 10", {"g": gm["id"]})
    best = db.scalar("select max(score) as m from public.game_scores where game_id = %(g)s and user_id = %(u)s",
                     {"g": gm["id"], "u": g.user["id"]})
    return ok({"game": gm, "leaderboard": board, "my_best": best})


@bp.post("/api/games/<slug>/scores")
@login_required
@feature_required("games")
@rate_limit("score", 12, 60, per="user")
def submit_score(slug):
    gm = _game(slug)
    me = g.user["id"]
    score = integer(body(), "score", lo=0, hi=SCORE_CAPS.get(slug, 100000))
    db.execute("insert into public.game_scores (game_id, user_id, score) values (%(g)s, %(u)s, %(s)s)",
               {"g": gm["id"], "u": me, "s": score})
    db.execute("update public.games set play_count = play_count + 1 where id = %(g)s", {"g": gm["id"]})
    sv.complete_quest(me, "daily_play")
    sv.check_gamer(me)
    lvl = sv.add_exp(me, min(score // 50, 30))
    best = db.scalar("select max(score) as m from public.game_scores where game_id = %(g)s and user_id = %(u)s",
                     {"g": gm["id"], "u": me})
    rank = db.scalar("select count(*) + 1 as r from (select user_id, max(score) as m from public.game_scores "
                     "where game_id = %(g)s group by user_id) t where t.m > %(b)s", {"g": gm["id"], "b": best})
    return ok({"best": best, "rank": rank, "level": lvl}, 201)


@bp.post("/api/games/<slug>/favorite")
@login_required
def favorite(slug):
    gm = _game(slug)
    db.execute("insert into public.game_favorites (user_id, game_id) values (%(u)s, %(g)s) on conflict do nothing",
               {"u": g.user["id"], "g": gm["id"]})
    return ok({"favorite": True})


@bp.delete("/api/games/<slug>/favorite")
@login_required
def unfavorite(slug):
    gm = _game(slug)
    db.execute("delete from public.game_favorites where user_id = %(u)s and game_id = %(g)s",
               {"u": g.user["id"], "g": gm["id"]})
    return ok({"favorite": False})
