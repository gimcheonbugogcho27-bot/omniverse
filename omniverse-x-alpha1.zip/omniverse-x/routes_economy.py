"""가상 경제: 지갑, 출석 보상, 송금, 상점, 인벤토리.

실제 현금 결제/환전 기능은 없다 (법률·보안 검토 전 구현 금지).
"""
from flask import Blueprint, g

import db
import services as sv
from security import (APIError, body, feature_required, integer, login_required, ok, omni_to_api, page_args,
                      rate_limit, setting, text)

bp = Blueprint("economy", __name__)


def _call(sql, params):
    try:
        return db.scalar(sql, params)
    except db.OmniError as e:
        raise omni_to_api(e)


@bp.get("/api/wallet")
@login_required
@feature_required("economy")
def wallet():
    me = g.user["id"]
    limit, offset = page_args(20)
    w = db.one("select balance, is_frozen from public.wallets where user_id = %(u)s", {"u": me})
    sent_today = db.scalar(
        "select coalesce(-sum(amount), 0) as s from public.transactions where user_id = %(u)s and kind = 'trade_out' "
        "and created_at >= (date_trunc('day', now() at time zone 'Asia/Seoul') at time zone 'Asia/Seoul')", {"u": me})
    tx = db.query(
        "select t.id, t.kind, t.amount, t.balance_after, t.memo, t.created_at, cu.username as counterparty "
        "from public.transactions t left join public.users cu on cu.id = t.counterparty_id "
        "where t.user_id = %(u)s order by t.id desc limit %(l)s offset %(o)s", {"u": me, "l": limit, "o": offset})
    claimed = bool(db.scalar("select exists (select 1 from public.transactions where idempotency_key = %(k)s) as x",
                             {"k": f"daily:{me}:{sv.today_key()}"}))
    return ok({"balance": w["balance"], "frozen": w["is_frozen"], "sent_today": sent_today,
               "daily_limit": int(setting("trade_daily_limit", 0) or 0), "daily_claimed": claimed,
               "daily_reward": int(setting("daily_reward", 0) or 0), "transactions": tx})


@bp.post("/api/wallet/daily")
@login_required
@feature_required("economy")
@rate_limit("daily", 10, 60, per="user")
def daily():
    me = g.user["id"]
    amount = int(setting("daily_reward", 0) or 0)
    if amount <= 0:
        raise APIError(400, "현재 출석 보상이 없습니다")
    bal = _call("select public.omni_credit(%(u)s, %(a)s, 'daily_reward', '출석 체크', %(k)s) as b",
                {"u": me, "a": amount, "k": f"daily:{me}:{sv.today_key()}"})
    sv.complete_quest(me, "daily_checkin")
    return ok({"balance": bal, "amount": amount})


@bp.post("/api/wallet/transfer")
@login_required
@feature_required("economy")
@rate_limit("transfer", 10, 60, per="user")
def transfer():
    d = body()
    me = g.user["id"]
    to = sv.user_by_username(text(d, "to", max_len=20))
    if not to or to["status"] != "active":
        raise APIError(404, "받는 사람을 찾을 수 없습니다")
    if sv.blocked_between(me, to["id"]):
        raise APIError(403, "이 사용자에게는 보낼 수 없습니다")
    amount = integer(d, "amount", lo=1, hi=1_000_000)
    memo = text(d, "memo", required=False, min_len=0, max_len=100) or "송금"
    bal = _call("select public.omni_transfer(%(a)s, %(b)s, %(m)s, %(memo)s, %(lim)s) as b",
                {"a": me, "b": to["id"], "m": amount, "memo": memo, "lim": int(setting("trade_daily_limit", 0) or 0)})
    sv.notify(to["id"], "coins", f"{g.user['username']}님이 {amount} 코인을 보냈습니다", "#/wallet", me)
    return ok({"balance": bal})


@bp.get("/api/shop/items")
@login_required
@feature_required("economy")
def shop():
    return ok(db.query(
        "select i.code, i.name, i.category, i.rarity, i.price, i.description, "
        "coalesce(inv.quantity, 0) as owned from public.items i "
        "left join public.inventory inv on inv.item_id = i.id and inv.user_id = %(u)s "
        "where i.is_active and i.category <> 'badge' order by i.price", {"u": g.user["id"]}))


@bp.post("/api/shop/buy")
@login_required
@feature_required("economy")
@rate_limit("buy", 20, 60, per="user")
def buy():
    d = body()
    code = text(d, "code", max_len=60)
    qty = integer(d, "qty", required=False, lo=1, hi=99, default=1)
    bal = _call("select public.omni_purchase(%(u)s, %(c)s, %(q)s) as b", {"u": g.user["id"], "c": code, "q": qty})
    return ok({"balance": bal})


@bp.get("/api/inventory")
@login_required
def inventory():
    return ok(db.query(
        "select i.code, i.name, i.category, i.rarity, i.description, inv.quantity, inv.acquired_at "
        "from public.inventory inv join public.items i on i.id = inv.item_id "
        "where inv.user_id = %(u)s and inv.quantity > 0 order by inv.acquired_at desc", {"u": g.user["id"]}))
