"""OMNIVERSE X ALPHA 1.0 핵심 기능 테스트 (실제 PostgreSQL 대상)."""
import db


def test_server_and_home(app):
    c = app.test_client()
    r = c.get("/")
    assert r.status_code == 200
    assert b"OMNIVERSE X" in r.data
    assert b"app.js?v=" in r.data and b"{{v}}" not in r.data
    assert "Content-Security-Policy" in r.headers
    h = c.get("/healthz").get_json()
    assert h["db"] is True and h["status"] == "ok"
    assert c.get("/static/js/app.js").status_code == 200
    assert c.get("/static/css/style.css").status_code == 200


def test_signup_login_logout_and_persistence(app, make_user):
    from conftest import Client
    u = make_user("alice")
    me = u.get("/api/auth/me").get_json()["user"]
    assert me["username"] == "alice" and me["role"] == "user"
    # 가입 보너스 + 개척자 배지
    w = u.get("/api/wallet").get_json()
    assert w["balance"] == 500
    assert w["transactions"][0]["kind"] == "signup_bonus"
    inv = u.get("/api/inventory").get_json()
    assert any(i["code"] == "badge_pioneer" for i in inv)
    # 로그아웃
    assert u.post("/api/auth/logout").status_code == 200
    assert u.get("/api/auth/me").get_json()["user"] is None
    assert u.get("/api/wallet").status_code == 401
    # 새 클라이언트(새 브라우저)로 로그인 → 데이터 유지
    c2 = Client(app)
    assert c2.post("/api/auth/login", {"login": "alice", "password": "wrong-pass1"}).status_code == 401
    r = c2.post("/api/auth/login", {"login": "ALICE@omniverse.test", "password": "Passw0rd!"})
    assert r.status_code == 200, r.get_json()
    assert c2.get("/api/wallet").get_json()["balance"] == 500


def test_signup_validation_and_duplicates(app, make_user):
    from conftest import Client
    make_user("bob")
    c = Client(app)
    assert c.post("/api/auth/signup", {"email": "x@omniverse.test", "username": "bob", "password": "Passw0rd!"}).status_code == 409
    assert c.post("/api/auth/signup", {"email": "bob@omniverse.test", "username": "bobby", "password": "Passw0rd!"}).status_code == 409
    assert c.post("/api/auth/signup", {"email": "bad", "username": "zz", "password": "Passw0rd!"}).status_code == 400
    assert c.post("/api/auth/signup", {"email": "a@b.co", "username": "x y", "password": "Passw0rd!"}).status_code == 400
    # 같은 IP에서 10분에 5번 넘게 가입 시도 → 요청 제한
    assert c.post("/api/auth/signup", {"email": "a@b.co", "username": "okname", "password": "short"}).status_code == 429
    from security import limiter
    limiter.reset()
    assert c.post("/api/auth/signup", {"email": "a@b.co", "username": "okname", "password": "short"}).status_code == 400
    assert c.post("/api/auth/signup", {"email": "a@b.co", "username": "okname", "password": "onlyletters"}).status_code == 400


def test_csrf_required(app, make_user):
    u = make_user()
    r = u.c.post("/api/posts", json={"content": "csrf 없이"})
    assert r.status_code == 403 and r.get_json()["code"] == "csrf"


def test_login_bruteforce_lock(app, make_user):
    from conftest import Client
    make_user("carol")
    c = Client(app)
    for _ in range(8):
        assert c.post("/api/auth/login", {"login": "carol", "password": "nope12345"}).status_code == 401
    r = c.post("/api/auth/login", {"login": "carol", "password": "Passw0rd!"})
    assert r.status_code == 429
    logs = db.query("select action from public.admin_logs where action = 'security.login_fail_burst'")
    assert logs


def test_profile_and_settings_saved(app, make_user):
    u = make_user("dave")
    assert u.patch("/api/me/profile", {"display_name": "데이브", "bio": "<script>alert(1)</script>", "is_public": False}).status_code == 200
    p = u.get("/api/users/dave").get_json()
    assert p["user"]["display_name"] == "데이브"
    assert p["user"]["bio"] == "<script>alert(1)</script>"  # 저장은 원문, 화면에서 이스케이프
    assert u.patch("/api/me/profile", {"title": "없는칭호"}).status_code == 400
    assert u.patch("/api/me/settings", {"theme": "aurora", "language": "en"}).status_code == 200
    s = u.get("/api/me/settings").get_json()
    assert s["theme"] == "aurora" and s["language"] == "en"
    assert u.patch("/api/me/settings", {"theme": "hacker"}).status_code == 400
    # 비공개 프로필은 다른 사용자에게 제한 정보만
    other = make_user()
    assert other.get("/api/users/dave").get_json()["limited"] is True


def test_worlds_enter_quest_and_level_lock(app, make_user):
    u = make_user("erin")
    worlds = u.get("/api/worlds").get_json()["items"]
    assert len(worlds) == 5
    assert {w["slug"] for w in worlds if w["locked"]} == {"verdant", "ignis", "crystalis"}
    assert u.post("/api/worlds/nova-prime/enter").get_json()["first_visit"] is True
    assert u.post("/api/worlds/nova-prime/enter").get_json()["first_visit"] is False
    assert u.post("/api/worlds/ignis/enter").status_code == 403
    assert u.post("/api/worlds/nowhere/enter").status_code == 404
    # 첫 착륙 퀘스트 완료 → 보상 수령 (한 번만)
    qs = {q["code"]: q for q in u.get("/api/quests").get_json()}
    assert qs["first_landing"]["status"] == "completed"
    r = u.post("/api/quests/first_landing/claim")
    assert r.status_code == 200 and r.get_json()["coins"] == 100
    assert u.post("/api/quests/first_landing/claim").status_code == 409
    assert u.post("/api/quests/first_post/claim").status_code == 400
    assert u.get("/api/wallet").get_json()["balance"] == 600
    # 월드 탐험 점수
    assert u.post("/api/worlds/nova-prime/score", {"score": 300}).get_json()["total"] == 300
    assert u.post("/api/worlds/nova-prime/score", {"score": 9999}).status_code == 400
    assert u.post("/api/worlds/aqua-terra/score", {"score": 10}).status_code == 400
    detail = u.get("/api/worlds/nova-prime").get_json()
    assert detail["leaderboard"][0]["username"] == "erin"


def test_friends_follow_block_and_dm(app, make_user):
    a = make_user("frank")
    b = make_user("grace")
    r = a.post("/api/friends/request", {"username": "grace"})
    assert r.status_code == 201
    assert a.post("/api/friends/request", {"username": "grace"}).status_code == 409
    assert a.post("/api/friends/request", {"username": "frank"}).status_code == 400
    inc = b.get("/api/friends").get_json()["incoming"]
    assert len(inc) == 1
    assert a.post(f"/api/friends/{inc[0]['id']}/accept").status_code == 404  # 보낸 사람은 수락 불가
    assert b.post(f"/api/friends/{inc[0]['id']}/accept").status_code == 200
    assert len(a.get("/api/friends").get_json()["friends"]) == 1
    notes = a.get("/api/notifications").get_json()
    assert any(n["kind"] == "friend_accept" for n in notes["items"])
    # 팔로우
    assert a.post("/api/follow/grace").get_json()["following"] is True
    assert b.get("/api/users/frank").get_json()["user"]["following"] == 1
    # 메시지
    cid = a.post("/api/dm/start", {"username": "grace"}).get_json()["id"]
    assert b.post("/api/dm/start", {"username": "frank"}).get_json()["id"] == cid
    assert a.post(f"/api/dm/{cid}/messages", {"content": "안녕 그레이스!"}).status_code == 201
    msgs = b.get(f"/api/dm/{cid}/messages").get_json()["items"]
    assert msgs[-1]["content"] == "안녕 그레이스!"
    outsider = make_user()
    assert outsider.get(f"/api/dm/{cid}/messages").status_code == 404
    # 차단 → 친구/팔로우 해제, 메시지 불가
    assert b.post("/api/block/frank").status_code == 200
    assert a.get("/api/friends").get_json()["friends"] == []
    assert a.post(f"/api/dm/{cid}/messages", {"content": "또 보내기"}).status_code == 403
    assert a.post("/api/friends/request", {"username": "grace"}).status_code == 403
    assert a.get("/api/users/grace").get_json()["blocked"] is True


def test_posts_visibility_likes_comments_reports(app, make_user):
    a = make_user("henry")
    b = make_user("iris")
    pid = a.post("/api/posts", {"content": "공개 글"}).get_json()["id"]
    fid = a.post("/api/posts", {"content": "친구 공개 글", "visibility": "friends"}).get_json()["id"]
    a.post("/api/posts", {"content": "나만 보기", "visibility": "private"})
    feed_b = [p["id"] for p in b.get("/api/feed").get_json()["items"]]
    assert pid in feed_b and fid not in feed_b
    assert len(a.get("/api/feed").get_json()["items"]) == 3
    assert b.post(f"/api/posts/{fid}/like").status_code == 404
    r = b.post(f"/api/posts/{pid}/like").get_json()
    assert r["like_count"] == 1
    assert b.post(f"/api/posts/{pid}/like").get_json()["like_count"] == 1  # 중복 좋아요 없음
    assert b.delete(f"/api/posts/{pid}/like").get_json()["like_count"] == 0
    assert b.post(f"/api/posts/{pid}/comments", {"content": "멋져요"}).status_code == 201
    assert b.get(f"/api/posts/{pid}/comments").get_json()[0]["content"] == "멋져요"
    assert b.delete(f"/api/posts/{pid}").status_code == 404  # 남의 글 삭제 불가
    assert b.post("/api/posts", {"content": ""}).status_code == 400
    assert b.post("/api/posts", {"content": "x", "image_url": "javascript:alert(1)"}).status_code == 400
    assert b.post("/api/reports", {"target_type": "post", "target_id": pid, "reason": "테스트 신고"}).status_code == 201
    # 첫 게시물 퀘스트
    q = {x["code"]: x for x in a.get("/api/quests").get_json()}
    assert q["first_post"]["status"] == "completed"


def test_search_is_injection_safe(app, make_user):
    u = make_user("jack")
    u.post("/api/posts", {"content": "검색되는 100% 글"})
    r = u.get("/api/search?q=' or 1=1 --")
    assert r.status_code == 200
    assert r.get_json()["users"] == []
    assert len(u.get("/api/search?q=100%").get_json()["posts"]) == 1
    assert u.get("/api/search?q=jack").get_json()["users"][0]["username"] == "jack"
    assert u.get("/api/search?q=노바").get_json()["worlds"][0]["slug"] == "nova-prime"


def test_wallet_daily_transfer_shop(app, make_user):
    a = make_user("kate")
    b = make_user("leo")
    r = a.post("/api/wallet/daily")
    assert r.status_code == 200 and r.get_json()["balance"] == 530
    assert a.post("/api/wallet/daily").status_code == 409
    assert a.post("/api/wallet/transfer", {"to": "leo", "amount": 100, "memo": "선물"}).get_json()["balance"] == 430
    assert b.get("/api/wallet").get_json()["balance"] == 600
    assert a.post("/api/wallet/transfer", {"to": "leo", "amount": 100000}).status_code == 400
    assert a.post("/api/wallet/transfer", {"to": "kate", "amount": 1}).status_code == 400
    assert a.post("/api/wallet/transfer", {"to": "leo", "amount": -5}).status_code == 400
    assert a.post("/api/wallet/transfer", {"to": "nobody", "amount": 5}).status_code == 404
    # 상점
    assert a.post("/api/shop/buy", {"code": "avatar_star_cape"}).get_json()["balance"] == 130
    assert a.post("/api/shop/buy", {"code": "avatar_star_cape"}).status_code == 409
    assert a.post("/api/shop/buy", {"code": "avatar_nebula_wings"}).status_code == 400  # 코인 부족
    assert a.post("/api/shop/buy", {"code": "badge_pioneer"}).status_code == 400
    assert a.post("/api/shop/buy", {"code": "game_boost_x2", "qty": 2}).get_json()["balance"] == 30
    # 아바타 장착은 가진 것만
    assert a.patch("/api/avatar", {"equipped": ["avatar_star_cape"], "color": "#22d3ee"}).status_code == 200
    assert a.patch("/api/avatar", {"equipped": ["avatar_nebula_wings"]}).status_code == 400
    # 거래 기록과 잔액이 일치
    rows = db.query("select sum(amount) as s from public.transactions where user_id = (select id from public.users where username = 'kate')")
    assert rows[0]["s"] == 30
    # 하루 송금 한도
    from security import settings
    db.execute("update public.system_settings set value = '150' where key = 'trade_daily_limit'")
    settings(refresh=True)
    assert b.post("/api/wallet/transfer", {"to": "kate", "amount": 100}).status_code == 200
    r = b.post("/api/wallet/transfer", {"to": "kate", "amount": 100})
    assert r.status_code == 400 and r.get_json()["code"] == "daily_limit"
    db.execute("update public.system_settings set value = '5000' where key = 'trade_daily_limit'")
    settings(refresh=True)


def test_games_scores_and_ranking(app, make_user):
    a = make_user("mia")
    b = make_user("noah")
    gl = a.get("/api/games").get_json()
    assert len(gl["official"]) == 3
    assert a.post("/api/games/star-catcher/scores", {"score": 1200}).get_json()["rank"] == 1
    assert b.post("/api/games/star-catcher/scores", {"score": 1500}).get_json()["rank"] == 1
    assert a.post("/api/games/star-catcher/scores", {"score": 999999}).status_code == 400
    board = a.get("/api/games/star-catcher").get_json()
    assert [x["username"] for x in board["leaderboard"]] == ["noah", "mia"]
    assert board["my_best"] == 1200
    assert a.post("/api/games/star-catcher/favorite").get_json()["favorite"] is True
    q = {x["code"]: x for x in a.get("/api/quests").get_json()}
    assert q["daily_play"]["status"] == "completed"


def test_ai_not_configured_is_explicit(app, make_user):
    u = make_user("olivia")
    st = u.get("/api/ai/status").get_json()
    assert st["configured"] is False
    cid = u.post("/api/ai/conversations", {}).get_json()["id"]
    r = u.post(f"/api/ai/conversations/{cid}/messages", {"content": "안녕"})
    assert r.status_code == 503 and r.get_json()["code"] == "ai_not_configured"
    assert u.get(f"/api/ai/conversations/{cid}/messages").get_json() == []  # 가짜 답변 저장 없음
    assert u.post("/api/ai/memories", {"content": "나는 우주를 좋아해"}).status_code == 201
    assert len(u.get("/api/ai/memories").get_json()) == 1
    other = make_user()
    assert other.get(f"/api/ai/conversations/{cid}/messages").status_code == 404


def test_ai_with_mocked_gemini(app, make_user, monkeypatch):
    import routes_ai

    class Resp:
        status_code = 200

        def json(self):
            return {"candidates": [{"content": {"parts": [{"text": "안녕하세요, 옴니입니다."}]}}]}

    seen = {}

    def fake_post(url, json=None, timeout=None, headers=None):
        seen["url"], seen["body"], seen["headers"] = url, json, headers
        return Resp()

    monkeypatch.setenv("GEMINI_API_KEY", "test-key")
    monkeypatch.setattr(routes_ai.requests, "post", fake_post)
    u = make_user("pete")
    u.post("/api/ai/memories", {"content": "고양이를 키운다"})
    cid = u.post("/api/ai/conversations", {}).get_json()["id"]
    r = u.post(f"/api/ai/conversations/{cid}/messages", {"content": "안녕", "mode": "study"})
    assert r.status_code == 201 and r.get_json()["content"] == "안녕하세요, 옴니입니다."
    assert "gemini-2.5-flash" in seen["url"] and seen["headers"]["x-goog-api-key"] == "test-key"
    assert "고양이를 키운다" in seen["body"]["systemInstruction"]["parts"][0]["text"]
    msgs = u.get(f"/api/ai/conversations/{cid}/messages").get_json()
    assert [m["role"] for m in msgs] == ["user", "assistant"]
    assert u.get("/api/ai/conversations").get_json()[0]["title"] == "안녕"


def test_creator_projects_preview_and_rating(app, make_user):
    a = make_user("quinn")
    b = make_user("ruby")
    pid = a.post("/api/creator/projects", {"title": "별 게임", "kind": "game", "template": "game"}).get_json()["id"]
    p = a.get(f"/api/creator/projects/{pid}").get_json()
    assert {f["path"] for f in p["files"]} == {"index.html", "style.css", "script.js"}
    assert b.get(f"/api/creator/projects/{pid}").status_code == 404  # 비공개
    assert a.put(f"/api/creator/projects/{pid}/files", {"path": "../evil.py", "content": "x"}).status_code == 400
    assert a.put(f"/api/creator/projects/{pid}/files", {"path": "script.js", "content": "console.log(2)"}).status_code == 200
    assert b.put(f"/api/creator/projects/{pid}/files", {"path": "script.js", "content": "hack"}).status_code in (403, 404)
    pv = a.get(f"/api/creator/projects/{pid}/preview")
    assert pv.status_code == 200 and b"console.log(2)" in pv.data
    assert "sandbox allow-scripts" in pv.headers["Content-Security-Policy"]
    assert a.patch(f"/api/creator/projects/{pid}", {"visibility": "public"}).status_code == 200
    assert b.post(f"/api/creator/projects/{pid}/rate", {"stars": 5}).status_code == 200
    assert b.post(f"/api/creator/projects/{pid}/rate", {"stars": 4}).status_code == 200
    proj = b.get(f"/api/creator/projects/{pid}").get_json()["project"]
    assert proj["rating_sum"] == 4 and proj["rating_count"] == 1 and proj["version"] == 2
    assert any(x["id"] == pid for x in b.get("/api/games").get_json()["community"])
    exported = a.get(f"/api/creator/projects/{pid}/export").get_json()
    new_id = b.post("/api/creator/import", exported).get_json()["id"]
    assert len(b.get(f"/api/creator/projects/{new_id}").get_json()["files"]) == 3


def test_admin_access_control(app, make_user):
    u = make_user("sam")
    for path in ("/api/admin/stats", "/api/admin/users", "/api/admin/settings", "/api/admin/logs"):
        assert u.get(path).status_code == 403
    assert u.patch("/api/admin/settings", {"features": {"ai": False}}).status_code == 403
    anon = app.test_client()
    assert anon.get("/api/admin/stats").status_code == 401
    # 가입 시 role 필드를 보내도 관리자가 될 수 없음
    from conftest import Client
    c = Client(app)
    c.post("/api/auth/signup", {"email": "sneaky@omniverse.test", "username": "sneaky", "password": "Passw0rd!", "role": "admin"})
    assert c.get("/api/auth/me").get_json()["user"]["role"] == "user"
    assert c.get("/api/admin/stats").status_code == 403


def test_admin_functions(app, make_user):
    admin = make_user("boss", email="boss@omniverse.test")
    assert admin.get("/api/auth/me").get_json()["user"]["role"] == "admin"
    target = make_user("tina")
    tid = db.scalar("select id from public.users where username = 'tina'")
    s = admin.get("/api/admin/stats").get_json()
    assert s["stats"]["users"] >= 2 and len(s["daily"]) == 7
    # 코인 조정, 동결
    assert admin.post(f"/api/admin/users/{tid}/coins", {"amount": 50, "memo": "이벤트"}).get_json()["balance"] == 550
    assert admin.post(f"/api/admin/users/{tid}/freeze", {"frozen": True}).status_code == 200
    assert target.post("/api/shop/buy", {"code": "avatar_neon_visor"}).status_code == 403
    admin.post(f"/api/admin/users/{tid}/freeze", {"frozen": False})
    # 기능 끄기 → 해당 API 비활성
    assert admin.patch("/api/admin/settings", {"features": {"games": False}}).status_code == 200
    assert target.get("/api/games").status_code == 503
    admin.patch("/api/admin/settings", {"features": {"games": True}})
    assert admin.patch("/api/admin/settings", {"features": {"hack": True}}).status_code == 400
    # 신고 처리 → 게시물 숨김
    pid = target.post("/api/posts", {"content": "신고될 글"}).get_json()["id"]
    target.post("/api/reports", {"target_type": "post", "target_id": pid, "reason": "스팸"})
    rid = admin.get("/api/admin/reports").get_json()[0]["id"]
    assert admin.post(f"/api/admin/reports/{rid}", {"status": "resolved", "hide_target": True}).status_code == 200
    assert pid not in [p["id"] for p in target.get("/api/feed").get_json()["items"]]
    # 공지
    admin.post("/api/admin/announcements", {"title": "알파 오픈", "body": "환영합니다"})
    assert target.get("/api/announcements").get_json()[0]["title"] == "알파 오픈"
    # 정지 → 세션 끊김, 로그인 불가
    assert admin.post(f"/api/admin/users/{tid}/status", {"status": "suspended"}).status_code == 200
    assert target.get("/api/wallet").status_code == 401
    from conftest import Client
    c = Client(app)
    assert c.post("/api/auth/login", {"login": "tina", "password": "Passw0rd!"}).status_code == 403
    admin.post(f"/api/admin/users/{tid}/status", {"status": "active"})
    assert c.post("/api/auth/login", {"login": "tina", "password": "Passw0rd!"}).status_code == 200
    # 자기 자신 보호
    aid = db.scalar("select id from public.users where username = 'boss'")
    assert admin.post(f"/api/admin/users/{aid}/role", {"role": "user"}).status_code == 400
    assert admin.post(f"/api/admin/users/{aid}/status", {"status": "suspended"}).status_code == 400
    actions = {l["action"] for l in admin.get("/api/admin/logs").get_json()}
    assert {"economy.adjust", "settings.update", "report.handle", "user.suspend", "user.restore"} <= actions


def test_api_error_handling(app, make_user):
    u = make_user()
    assert u.get("/api/nope").status_code == 404
    assert u.get("/api/nope").get_json()["error"]
    r = u.c.post("/api/posts", data="not json", headers={"X-CSRF-Token": u.csrf, "Content-Type": "application/json"})
    assert r.status_code == 400
    assert u.post("/api/wallet/transfer", {"to": "x", "amount": "abc"}).status_code in (400, 404)
    assert u.get("/api/feed?limit=abc").status_code == 400


def test_dashboard(app, make_user):
    u = make_user("uma")
    d = u.get("/api/me/dashboard").get_json()
    assert d["me"]["username"] == "uma" and d["me"]["balance"] == 500
    assert d["daily_claimed"] is False
    assert d["stats"]["worlds_visited"] == 0
    sm = u.get("/api/me/summary").get_json()
    assert sm["balance"] == 500 and sm["unread"] == 0
    u.post("/api/wallet/daily")
    assert u.get("/api/me/dashboard").get_json()["daily_claimed"] is True
    assert any(q["code"] == "daily_checkin" for q in d["quests"])
    assert u.get("/api/rankings").status_code == 200
    exp = u.get("/api/me/export").get_json()
    assert exp["account"]["username"] == "uma"


def test_migrations_are_idempotent(app):
    import migrate
    assert migrate.run(verbose=False) == []
    versions = {r["version"] for r in db.query("select version from public.schema_migrations")}
    assert len(versions) == 5
