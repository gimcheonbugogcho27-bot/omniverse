"""테스트 설정.

실제 PostgreSQL에 연결해서 테스트한다.
- OMNI_TEST_DATABASE_URL 이 있으면 psycopg2로 그 DB를 쓴다 (예: 로컬 PostgreSQL).
- 없고 OMNI_TEST_PSQL 이 있으면 psql 명령으로 실행하는 어댑터를 쓴다 (psycopg2를 설치할 수 없는 환경용).
테스트는 매 세션마다 빈 데이터베이스를 새로 만들고 migrate.py로 스키마를 적용한다.
"""
import csv
import io
import json
import os
import re
import subprocess
import sys
import uuid

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
os.environ.setdefault("COOKIE_SECURE", "0")
os.environ.setdefault("SECRET_KEY", "test-secret")
os.environ["ADMIN_EMAILS"] = "boss@omniverse.test"
os.environ.pop("GEMINI_API_KEY", None)

import db  # noqa: E402


# ---------------- psql 어댑터 ----------------

class PsqlRunner:
    INT_TYPES = {"bigint", "integer", "smallint"}

    def __init__(self, base_args, dbname):
        self.base = base_args
        self.dbname = dbname

    def _psql(self, script, csv_mode=True):
        args = self.base + ["-d", self.dbname, "-X", "-v", "ON_ERROR_STOP=1", "-v", "VERBOSITY=verbose", "-P", "null=\\N"]
        if csv_mode:
            args += ["--csv", "-q"]  # -q: 결과 뒤의 'INSERT 0 1' 같은 상태 줄을 숨김
        p = subprocess.run(args + ["-f", "-"], input=script, capture_output=True, text=True)
        if p.returncode != 0:
            err = p.stderr
            m = re.search(r"ERROR:\s+([0-9A-Z]{5}):\s*(.*)", err)
            code = m.group(1) if m else ""
            msg = m.group(2) if m else err
            om = re.search(r"OMNI:([a-z_]+)", err)
            if om:
                raise db.OmniError(om.group(1))
            if code.startswith("23"):
                raise db.IntegrityError(msg)
            raise db.DBError(msg)
        return p.stdout

    @staticmethod
    def quote(v):
        if v is None:
            return "NULL"
        if isinstance(v, bool):
            return "true" if v else "false"
        if isinstance(v, int):
            return str(v)
        if isinstance(v, float):
            return repr(v)
        if isinstance(v, (dict, list)):
            v = json.dumps(v)
        s = str(v)
        if "\x00" in s:
            raise db.DBError("NUL 문자는 저장할 수 없습니다")
        return "'" + s.replace("'", "''") + "'"

    def render(self, sql, params):
        seq = iter(params) if isinstance(params, (list, tuple)) else None

        def rep(m):
            tok = m.group(0)
            if tok == "%%":
                return "%"
            if tok == "%s":
                return self.quote(next(seq))
            return self.quote(params[m.group(1)])
        return re.sub(r"%%|%\((\w+)\)s|%s", rep, sql)

    def convert(self, val, typ):
        if val == "\\N":
            return None
        if typ in self.INT_TYPES:
            return int(val)
        if typ == "numeric":
            return int(val) if re.fullmatch(r"-?\d+", val) else float(val)
        if typ in ("double precision", "real"):
            return float(val)
        if typ == "boolean":
            return val == "t"
        if typ in ("json", "jsonb"):
            return json.loads(val)
        return val

    def __call__(self, sql, params, fetch):
        sql = self.render(sql, params)
        if not fetch:
            out = self._psql(sql, csv_mode=False)
            tags = re.findall(r"^(?:INSERT \d+|UPDATE|DELETE|SELECT|MERGE) (\d+)$", out, re.M)
            return int(tags[-1]) if tags else 0
        stmt = sql.strip().rstrip(";")
        desc = list(csv.reader(io.StringIO(self._psql(stmt + " \\gdesc\n"))))[1:]
        types = [t for _, t in desc]
        rows = list(csv.reader(io.StringIO(self._psql(stmt + ";\n"))))
        if not rows:
            return []
        header, data = rows[0], rows[1:]
        return [{h: self.convert(v, types[i]) for i, (h, v) in enumerate(zip(header, r))} for r in data]


@pytest.fixture(scope="session", autouse=True)
def database():
    psql = os.environ.get("OMNI_TEST_PSQL")
    url = os.environ.get("OMNI_TEST_DATABASE_URL")
    name = "omni_test_" + uuid.uuid4().hex[:8]
    if url:  # psycopg2 모드: 비어 있는 테스트 전용 DB 주소를 넣는다 (운영 DB 금지)
        os.environ["DATABASE_URL"] = url
        import migrate
        migrate.run(verbose=False)
        yield url
        return
    if not psql:
        pytest.skip("OMNI_TEST_PSQL 또는 OMNI_TEST_DATABASE_URL 이 필요합니다")
    base = psql.split()
    subprocess.run(base + ["-d", "postgres", "-X", "-q", "-c", f"create database {name}"], check=True)
    db._run = PsqlRunner(base, name)
    import migrate
    migrate.run(verbose=False)
    yield name
    subprocess.run(base + ["-d", "postgres", "-X", "-q", "-c", f"drop database {name} with (force)"], check=False)


@pytest.fixture()
def app(database):
    from app import app as flask_app
    from security import limiter, settings
    limiter.reset()
    settings(refresh=True)
    flask_app.config["TESTING"] = True
    return flask_app


class Client:
    """CSRF 토큰을 자동으로 붙이는 테스트 클라이언트"""

    def __init__(self, flask_app):
        self.c = flask_app.test_client()
        self.csrf = self.c.get("/api/auth/me").get_json()["csrf"]

    def _do(self, method, path, json_body=None):
        r = self.c.open(path, method=method, json=json_body, headers={"X-CSRF-Token": self.csrf})
        data = r.get_json(silent=True)
        if isinstance(data, dict) and data.get("csrf"):
            self.csrf = data["csrf"]
        return r

    def get(self, path):
        return self.c.get(path)

    def post(self, path, body=None):
        return self._do("POST", path, body or {})

    def patch(self, path, body=None):
        return self._do("PATCH", path, body or {})

    def put(self, path, body=None):
        return self._do("PUT", path, body or {})

    def delete(self, path):
        return self._do("DELETE", path)


@pytest.fixture()
def make_user(app):
    from security import limiter
    counter = {"n": 0}

    def _make(username=None, email=None, password="Passw0rd!"):
        counter["n"] += 1
        username = username or f"user{uuid.uuid4().hex[:6]}"
        email = email or f"{username}@omniverse.test"
        limiter.reset()
        cl = Client(app)
        r = cl.post("/api/auth/signup", {"email": email, "username": username, "password": password,
                                         "display_name": username.upper()})
        assert r.status_code == 201, r.get_json()
        cl.username = username
        cl.email = email
        return cl
    return _make
