insert into public.worlds (slug, name, theme, description, color, min_level, is_official) values
 ('nova-prime','노바 프라임','city','네온 도시 행성. 모든 탐험가가 처음 도착하는 허브 월드','#22d3ee',1,true),
 ('aqua-terra','아쿠아 테라','ocean','바다로 덮인 행성. 해저 유적과 수중 퀘스트','#3b82f6',1,true),
 ('verdant','버던트','forest','거대한 숲의 행성. 생태 탐험과 수집','#10b981',3,true),
 ('ignis','이그니스','volcano','용암 행성. 보스 콘텐츠가 기다리는 곳','#f97316',5,true),
 ('crystalis','크리스탈리스','ice','얼음 수정 행성. 퍼즐과 고급 보상','#a78bfa',8,true);

insert into public.items (code, name, category, rarity, price, tradable, description) values
 ('avatar_neon_visor','네온 바이저','avatar','common',100,true,'시안 빛이 나는 바이저'),
 ('avatar_star_cape','스타 망토','avatar','rare',300,true,'별빛이 흐르는 망토'),
 ('avatar_nebula_wings','성운 날개','avatar','epic',800,true,'보라색 성운 날개'),
 ('game_boost_x2','점수 부스터 x2','consumable','common',50,false,'다음 게임 1회 점수 2배'),
 ('badge_pioneer','개척자 배지','badge','legendary',0,false,'알파 1.0 초기 가입자 배지');

insert into public.games (slug, title, category, description, is_official) values
 ('star-catcher','스타 캐처','arcade','떨어지는 별을 모아 점수를 얻는 게임',true),
 ('memory-orbit','메모리 오빗','puzzle','행성 카드 짝 맞추기',true),
 ('type-warp','타이핑 워프','typing','단어를 빠르게 입력해 워프 속도를 높이는 게임',true);

insert into public.quests (world_id, code, title, description, reward_coins, reward_exp, is_daily) values
 ((select id from public.worlds where slug='nova-prime'),'first_landing','첫 착륙','노바 프라임에 처음 입장하기',100,50,false),
 (null,'daily_checkin','출석 체크','오늘 접속해서 보상 받기',30,10,true),
 (null,'daily_play','오늘의 게임','게임 1판 플레이하기',50,20,true),
 (null,'first_post','첫 게시물','피드에 첫 게시물 작성하기',80,30,false);

insert into public.achievements (code, title, description, icon, reward_coins) values
 ('explorer_5','은하 탐험가','공식 월드 5곳 모두 방문','🪐',300),
 ('social_10','인싸 우주인','친구 10명 만들기','🤝',200),
 ('gamer_100','게임 마스터','게임 점수 기록 100회','🎮',500);

insert into public.system_settings (key, value, description) values
 ('signup_bonus', '500', '회원가입 시 지급되는 코인'),
 ('daily_reward', '30', '출석 체크 보상 코인'),
 ('trade_daily_limit', '5000', '사용자 간 하루 송금 한도 코인'),
 ('features', '{"ai":true,"world":true,"social":true,"games":true,"economy":true,"creator":true,"realtime_chat":false,"voice":false,"image_gen":false}', '기능 활성화 스위치 (false = 미구현/비활성)'),
 ('maintenance', 'false', '점검 모드');
