-- 월드
create table public.worlds (
  id bigint generated always as identity primary key,
  slug text not null unique,
  name text not null,
  theme text not null,
  description text,
  color text,
  min_level int not null default 1,
  creator_id bigint references public.users(id) on delete set null,
  is_official boolean not null default false,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.world_members (
  world_id bigint not null references public.worlds(id) on delete cascade,
  user_id bigint not null references public.users(id) on delete cascade,
  score bigint not null default 0 check (score >= 0),
  joined_at timestamptz not null default now(),
  last_visit_at timestamptz not null default now(),
  primary key (world_id, user_id)
);
create index world_members_user_idx on public.world_members (user_id);
create index world_members_rank_idx on public.world_members (world_id, score desc);

create table public.avatars (
  user_id bigint primary key references public.users(id) on delete cascade,
  body text not null default 'default',
  color text not null default '#7c5cff',
  equipped jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);
create trigger avatars_updated before update on public.avatars for each row execute function public.set_updated_at();

-- 아이템/인벤토리
create table public.items (
  id bigint generated always as identity primary key,
  code text not null unique,
  name text not null,
  category text not null check (category in ('avatar','game','world','badge','consumable')),
  rarity text not null default 'common' check (rarity in ('common','rare','epic','legendary')),
  price bigint not null default 0 check (price >= 0),
  tradable boolean not null default true,
  is_active boolean not null default true,
  description text,
  created_at timestamptz not null default now()
);

create table public.inventory (
  user_id bigint not null references public.users(id) on delete cascade,
  item_id bigint not null references public.items(id) on delete restrict,
  quantity int not null default 1 check (quantity >= 0),
  acquired_at timestamptz not null default now(),
  primary key (user_id, item_id)
);

-- 경제 (가상 화폐 전용, 실제 현금 결제 없음)
create table public.wallets (
  user_id bigint primary key references public.users(id) on delete cascade,
  balance bigint not null default 0 check (balance >= 0),
  is_frozen boolean not null default false,
  updated_at timestamptz not null default now()
);
create trigger wallets_updated before update on public.wallets for each row execute function public.set_updated_at();

create table public.transactions (
  id bigint generated always as identity primary key,
  user_id bigint not null references public.users(id) on delete cascade,
  counterparty_id bigint references public.users(id) on delete set null,
  kind text not null check (kind in ('daily_reward','quest_reward','event_reward','purchase','trade_in','trade_out','admin_adjust','signup_bonus')),
  amount bigint not null check (amount <> 0),
  balance_after bigint not null check (balance_after >= 0),
  memo text,
  idempotency_key text unique,
  created_at timestamptz not null default now()
);
create index transactions_user_idx on public.transactions (user_id, created_at desc);

-- 퀘스트/업적
create table public.quests (
  id bigint generated always as identity primary key,
  world_id bigint references public.worlds(id) on delete cascade,
  code text not null unique,
  title text not null,
  description text,
  reward_coins bigint not null default 0 check (reward_coins >= 0),
  reward_exp bigint not null default 0 check (reward_exp >= 0),
  is_daily boolean not null default false,
  is_active boolean not null default true
);

create table public.user_quests (
  user_id bigint not null references public.users(id) on delete cascade,
  quest_id bigint not null references public.quests(id) on delete cascade,
  period date not null default current_date,
  status text not null default 'in_progress' check (status in ('in_progress','completed','claimed')),
  progress int not null default 0,
  completed_at timestamptz,
  primary key (user_id, quest_id, period)
);

create table public.achievements (
  id bigint generated always as identity primary key,
  code text not null unique,
  title text not null,
  description text,
  icon text,
  reward_coins bigint not null default 0 check (reward_coins >= 0)
);

create table public.user_achievements (
  user_id bigint not null references public.users(id) on delete cascade,
  achievement_id bigint not null references public.achievements(id) on delete cascade,
  earned_at timestamptz not null default now(),
  primary key (user_id, achievement_id)
);

-- 게임 센터
create table public.games (
  id bigint generated always as identity primary key,
  slug text not null unique,
  title text not null,
  category text not null,
  description text,
  creator_id bigint references public.users(id) on delete set null,
  is_official boolean not null default false,
  status text not null default 'published' check (status in ('draft','published','hidden')),
  play_count bigint not null default 0,
  created_at timestamptz not null default now()
);

create table public.game_scores (
  id bigint generated always as identity primary key,
  game_id bigint not null references public.games(id) on delete cascade,
  user_id bigint not null references public.users(id) on delete cascade,
  score bigint not null check (score >= 0),
  created_at timestamptz not null default now()
);
create index game_scores_rank_idx on public.game_scores (game_id, score desc);
create index game_scores_user_idx on public.game_scores (user_id);

create table public.game_favorites (
  user_id bigint not null references public.users(id) on delete cascade,
  game_id bigint not null references public.games(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, game_id)
);
