-- 커뮤니티/게시물
create table public.communities (
  id bigint generated always as identity primary key,
  slug text not null unique,
  name text not null,
  description text,
  owner_id bigint references public.users(id) on delete set null,
  is_private boolean not null default false,
  created_at timestamptz not null default now()
);

create table public.community_members (
  community_id bigint not null references public.communities(id) on delete cascade,
  user_id bigint not null references public.users(id) on delete cascade,
  role text not null default 'member' check (role in ('member','moderator','owner')),
  joined_at timestamptz not null default now(),
  primary key (community_id, user_id)
);
create index community_members_user_idx on public.community_members (user_id);

create table public.posts (
  id bigint generated always as identity primary key,
  author_id bigint not null references public.users(id) on delete cascade,
  community_id bigint references public.communities(id) on delete cascade,
  content text not null check (char_length(content) between 1 and 5000),
  image_url text,
  visibility text not null default 'public' check (visibility in ('public','friends','private')),
  is_hidden boolean not null default false,
  like_count int not null default 0,
  comment_count int not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index posts_feed_idx on public.posts (created_at desc);
create index posts_author_idx on public.posts (author_id, created_at desc);
create index posts_community_idx on public.posts (community_id, created_at desc);
create trigger posts_updated before update on public.posts for each row execute function public.set_updated_at();

create table public.comments (
  id bigint generated always as identity primary key,
  post_id bigint not null references public.posts(id) on delete cascade,
  author_id bigint not null references public.users(id) on delete cascade,
  content text not null check (char_length(content) between 1 and 1000),
  is_hidden boolean not null default false,
  created_at timestamptz not null default now()
);
create index comments_post_idx on public.comments (post_id, created_at);

create table public.likes (
  user_id bigint not null references public.users(id) on delete cascade,
  post_id bigint not null references public.posts(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, post_id)
);
create index likes_post_idx on public.likes (post_id);

create table public.blocks (
  blocker_id bigint not null references public.users(id) on delete cascade,
  blocked_id bigint not null references public.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (blocker_id, blocked_id),
  check (blocker_id <> blocked_id)
);

create table public.notifications (
  id bigint generated always as identity primary key,
  user_id bigint not null references public.users(id) on delete cascade,
  actor_id bigint references public.users(id) on delete set null,
  kind text not null,
  message text not null,
  link text,
  read_at timestamptz,
  created_at timestamptz not null default now()
);
create index notifications_user_idx on public.notifications (user_id, created_at desc);
create index notifications_unread_idx on public.notifications (user_id) where read_at is null;

create table public.reports (
  id bigint generated always as identity primary key,
  reporter_id bigint not null references public.users(id) on delete cascade,
  target_type text not null check (target_type in ('user','post','comment','game','world','project')),
  target_id bigint not null,
  reason text not null check (char_length(reason) between 1 and 1000),
  status text not null default 'open' check (status in ('open','reviewing','resolved','rejected')),
  handled_by bigint references public.users(id) on delete set null,
  handled_at timestamptz,
  created_at timestamptz not null default now()
);
create index reports_status_idx on public.reports (status, created_at desc);

-- 크리에이터
create table public.creator_projects (
  id bigint generated always as identity primary key,
  owner_id bigint not null references public.users(id) on delete cascade,
  title text not null,
  kind text not null check (kind in ('app','game','website','world')),
  description text,
  visibility text not null default 'private' check (visibility in ('private','public')),
  version int not null default 1,
  rating_sum int not null default 0,
  rating_count int not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index creator_projects_owner_idx on public.creator_projects (owner_id);
create index creator_projects_public_idx on public.creator_projects (visibility, created_at desc);
create trigger creator_projects_updated before update on public.creator_projects for each row execute function public.set_updated_at();

create table public.project_files (
  id bigint generated always as identity primary key,
  project_id bigint not null references public.creator_projects(id) on delete cascade,
  path text not null,
  content text not null default '' check (char_length(content) <= 500000),
  version int not null default 1,
  updated_at timestamptz not null default now(),
  unique (project_id, path)
);
create trigger project_files_updated before update on public.project_files for each row execute function public.set_updated_at();

-- 관리자
create table public.admin_logs (
  id bigint generated always as identity primary key,
  admin_id bigint references public.users(id) on delete set null,
  action text not null,
  target_type text,
  target_id bigint,
  detail jsonb not null default '{}'::jsonb,
  ip text,
  created_at timestamptz not null default now()
);
create index admin_logs_created_idx on public.admin_logs (created_at desc);

create table public.system_settings (
  key text primary key,
  value jsonb not null,
  description text,
  updated_by bigint references public.users(id) on delete set null,
  updated_at timestamptz not null default now()
);
create trigger system_settings_updated before update on public.system_settings for each row execute function public.set_updated_at();

create table public.announcements (
  id bigint generated always as identity primary key,
  title text not null,
  body text not null,
  author_id bigint references public.users(id) on delete set null,
  is_published boolean not null default true,
  created_at timestamptz not null default now()
);

-- 보안: 앱 서버(Flask)가 DB에 직접 접속하므로, Supabase 공개 API(anon/authenticated)로는 모든 테이블 접근 차단
-- (anon/authenticated 역할이 없는 일반 PostgreSQL에서는 RLS만 켠다)
do $$
declare t record; has_roles boolean;
begin
  has_roles := exists (select 1 from pg_roles where rolname = 'anon')
           and exists (select 1 from pg_roles where rolname = 'authenticated');
  for t in select tablename from pg_tables where schemaname = 'public' loop
    execute format('alter table public.%I enable row level security', t.tablename);
    if has_roles then
      execute format('revoke all on public.%I from anon, authenticated', t.tablename);
    end if;
  end loop;
  if has_roles then
    execute 'alter default privileges in schema public revoke all on tables from anon, authenticated';
  end if;
end $$;
