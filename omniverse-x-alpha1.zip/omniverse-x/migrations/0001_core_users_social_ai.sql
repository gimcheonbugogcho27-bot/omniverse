-- 공통: updated_at 자동 갱신
create or replace function public.set_updated_at() returns trigger
language plpgsql set search_path = '' as $$
begin new.updated_at = now(); return new; end $$;

-- 사용자
create table public.users (
  id bigint generated always as identity primary key,
  email text not null,
  username text not null,
  password_hash text not null,
  role text not null default 'user' check (role in ('user','moderator','admin')),
  status text not null default 'active' check (status in ('active','suspended','deleted')),
  is_demo boolean not null default false,
  last_login_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index users_email_uq on public.users (lower(email));
create unique index users_username_uq on public.users (lower(username));
create trigger users_updated before update on public.users for each row execute function public.set_updated_at();

create table public.user_profiles (
  user_id bigint primary key references public.users(id) on delete cascade,
  display_name text,
  bio text check (char_length(bio) <= 500),
  avatar_url text,
  title text,
  level int not null default 1 check (level >= 1),
  exp bigint not null default 0 check (exp >= 0),
  is_public boolean not null default true,
  updated_at timestamptz not null default now()
);
create trigger user_profiles_updated before update on public.user_profiles for each row execute function public.set_updated_at();

create table public.user_settings (
  user_id bigint primary key references public.users(id) on delete cascade,
  language text not null default 'ko' check (language in ('ko','en')),
  theme text not null default 'nebula',
  notify_email boolean not null default true,
  notify_push boolean not null default true,
  settings jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);
create trigger user_settings_updated before update on public.user_settings for each row execute function public.set_updated_at();

create table public.user_sessions (
  id bigint generated always as identity primary key,
  user_id bigint not null references public.users(id) on delete cascade,
  token_hash text not null unique,
  ip text,
  user_agent text,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null,
  revoked_at timestamptz
);
create index user_sessions_user_idx on public.user_sessions (user_id);

-- 소셜
create table public.friendships (
  id bigint generated always as identity primary key,
  requester_id bigint not null references public.users(id) on delete cascade,
  addressee_id bigint not null references public.users(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','accepted','declined','blocked')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (requester_id <> addressee_id)
);
create unique index friendships_pair_uq on public.friendships (least(requester_id, addressee_id), greatest(requester_id, addressee_id));
create index friendships_addressee_idx on public.friendships (addressee_id);
create trigger friendships_updated before update on public.friendships for each row execute function public.set_updated_at();

create table public.follows (
  follower_id bigint not null references public.users(id) on delete cascade,
  following_id bigint not null references public.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (follower_id, following_id),
  check (follower_id <> following_id)
);
create index follows_following_idx on public.follows (following_id);

-- 대화 (AI 채팅 + 사용자 DM 공용)
create table public.conversations (
  id bigint generated always as identity primary key,
  kind text not null check (kind in ('ai','direct','group')),
  owner_id bigint not null references public.users(id) on delete cascade,
  peer_id bigint references public.users(id) on delete cascade,
  title text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index conversations_owner_idx on public.conversations (owner_id, updated_at desc);
create index conversations_peer_idx on public.conversations (peer_id);
create trigger conversations_updated before update on public.conversations for each row execute function public.set_updated_at();

create table public.messages (
  id bigint generated always as identity primary key,
  conversation_id bigint not null references public.conversations(id) on delete cascade,
  sender_id bigint references public.users(id) on delete set null,
  role text not null default 'user' check (role in ('user','assistant','system')),
  content text not null check (char_length(content) <= 20000),
  read_at timestamptz,
  created_at timestamptz not null default now()
);
create index messages_conversation_idx on public.messages (conversation_id, created_at);

create table public.ai_memories (
  id bigint generated always as identity primary key,
  user_id bigint not null references public.users(id) on delete cascade,
  content text not null check (char_length(content) <= 2000),
  importance smallint not null default 1 check (importance between 1 and 5),
  created_at timestamptz not null default now()
);
create index ai_memories_user_idx on public.ai_memories (user_id);
