-- 경제 처리 함수: 잔액 변경과 거래 기록을 하나의 트랜잭션으로 묶어 원자적으로 처리한다.
-- 오류는 'OMNI:<코드>' 형식으로 올려서 앱이 사용자 메시지로 바꾼다.

-- 코인 지급/차감 (보상, 관리자 조정, 구매에서 사용). p_key가 있으면 같은 키로 두 번 지급되지 않는다.
create or replace function public.omni_credit(p_user bigint, p_amount bigint, p_kind text, p_memo text, p_key text default null)
returns bigint
language plpgsql set search_path = '' as $$
declare v_bal bigint;
begin
  if p_amount = 0 then raise exception 'OMNI:invalid_amount'; end if;
  if p_key is not null and exists (select 1 from public.transactions where idempotency_key = p_key) then
    raise exception 'OMNI:already_claimed';
  end if;
  if exists (select 1 from public.wallets where user_id = p_user and is_frozen) then
    raise exception 'OMNI:wallet_frozen';
  end if;
  update public.wallets set balance = balance + p_amount
   where user_id = p_user and balance + p_amount >= 0
   returning balance into v_bal;
  if v_bal is null then raise exception 'OMNI:insufficient_funds'; end if;
  insert into public.transactions (user_id, kind, amount, balance_after, memo, idempotency_key)
  values (p_user, p_kind, p_amount, v_bal, p_memo, p_key);
  return v_bal;
exception when unique_violation then
  raise exception 'OMNI:already_claimed';
end $$;

-- 사용자 간 송금. 두 지갑을 user_id 순서로 잠가 교착을 막고, 하루 송금 한도(한국 시간 기준)를 검사한다.
create or replace function public.omni_transfer(p_from bigint, p_to bigint, p_amount bigint, p_memo text, p_daily_limit bigint)
returns bigint
language plpgsql set search_path = '' as $$
declare v_sent bigint; v_from bigint; v_to bigint;
begin
  if p_amount is null or p_amount <= 0 then raise exception 'OMNI:invalid_amount'; end if;
  if p_from = p_to then raise exception 'OMNI:self_transfer'; end if;
  perform 1 from public.wallets where user_id in (p_from, p_to) order by user_id for update;
  if not exists (select 1 from public.wallets w join public.users u on u.id = w.user_id
                 where w.user_id = p_to and not w.is_frozen and u.status = 'active') then
    raise exception 'OMNI:receiver_unavailable';
  end if;
  if exists (select 1 from public.wallets where user_id = p_from and is_frozen) then
    raise exception 'OMNI:wallet_frozen';
  end if;
  select coalesce(-sum(amount), 0) into v_sent from public.transactions
   where user_id = p_from and kind = 'trade_out'
     and created_at >= (date_trunc('day', now() at time zone 'Asia/Seoul') at time zone 'Asia/Seoul');
  if v_sent + p_amount > p_daily_limit then raise exception 'OMNI:daily_limit'; end if;
  update public.wallets set balance = balance - p_amount
   where user_id = p_from and balance >= p_amount returning balance into v_from;
  if v_from is null then raise exception 'OMNI:insufficient_funds'; end if;
  update public.wallets set balance = balance + p_amount where user_id = p_to returning balance into v_to;
  insert into public.transactions (user_id, counterparty_id, kind, amount, balance_after, memo)
  values (p_from, p_to, 'trade_out', -p_amount, v_from, p_memo),
         (p_to, p_from, 'trade_in', p_amount, v_to, p_memo);
  return v_from;
end $$;

-- 상점 구매. 아바타 아이템은 1개만 소유, 배지는 구매 불가.
create or replace function public.omni_purchase(p_user bigint, p_item_code text, p_qty int)
returns bigint
language plpgsql set search_path = '' as $$
declare v_item public.items; v_bal bigint; v_total bigint;
begin
  if p_qty is null or p_qty < 1 or p_qty > 99 then raise exception 'OMNI:invalid_amount'; end if;
  select * into v_item from public.items where code = p_item_code and is_active;
  if v_item.id is null then raise exception 'OMNI:item_not_found'; end if;
  if v_item.category = 'badge' then raise exception 'OMNI:not_for_sale'; end if;
  if v_item.category = 'avatar' then
    if p_qty <> 1 then raise exception 'OMNI:invalid_amount'; end if;
    if exists (select 1 from public.inventory where user_id = p_user and item_id = v_item.id and quantity > 0) then
      raise exception 'OMNI:already_owned';
    end if;
  end if;
  v_total := v_item.price * p_qty;
  if v_total > 0 then
    v_bal := public.omni_credit(p_user, -v_total, 'purchase', v_item.name || ' x' || p_qty, null);
  else
    select balance into v_bal from public.wallets where user_id = p_user;
  end if;
  insert into public.inventory (user_id, item_id, quantity) values (p_user, v_item.id, p_qty)
  on conflict (user_id, item_id) do update set quantity = public.inventory.quantity + excluded.quantity;
  return v_bal;
end $$;

-- 크리에이터 작품 평가 (사용자당 1회, 다시 평가하면 갱신)
create table public.project_ratings (
  project_id bigint not null references public.creator_projects(id) on delete cascade,
  user_id bigint not null references public.users(id) on delete cascade,
  stars smallint not null check (stars between 1 and 5),
  created_at timestamptz not null default now(),
  primary key (project_id, user_id)
);
alter table public.project_ratings enable row level security;

-- 마이그레이션 기록 (앱의 migrate.py가 사용)
create table if not exists public.schema_migrations (
  version text primary key,
  applied_at timestamptz not null default now()
);
alter table public.schema_migrations enable row level security;

revoke all on function public.omni_credit(bigint, bigint, text, text, text) from public;
revoke all on function public.omni_transfer(bigint, bigint, bigint, text, bigint) from public;
revoke all on function public.omni_purchase(bigint, text, int) from public;
revoke all on function public.set_updated_at() from public;

-- Supabase 공개 API 역할이 있으면 새 테이블/함수 접근도 막는다
do $$
begin
  if exists (select 1 from pg_roles where rolname = 'anon') and exists (select 1 from pg_roles where rolname = 'authenticated') then
    execute 'revoke all on public.project_ratings, public.schema_migrations from anon, authenticated';
    execute 'revoke all on function public.omni_credit(bigint, bigint, text, text, text) from anon, authenticated';
    execute 'revoke all on function public.omni_transfer(bigint, bigint, bigint, text, bigint) from anon, authenticated';
    execute 'revoke all on function public.omni_purchase(bigint, text, int) from anon, authenticated';
    execute 'revoke all on function public.set_updated_at() from anon, authenticated';
  end if;
end $$;
