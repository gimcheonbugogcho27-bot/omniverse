"""OMNIVERSE AI: Gemini REST API 연동, 대화 기록, 개인 기억, 프롬프트 라이브러리.

GEMINI_API_KEY가 없으면 AI 기능은 '미설정' 상태를 명확히 돌려준다(가짜 답변 없음).
"""
import os
import re

import requests
from flask import Blueprint, g

import db
from security import APIError, body, choice, feature_required, integer, login_required, ok, rate_limit, text

bp = Blueprint("ai", __name__)

GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
MODES = {
    "chat": "너는 OMNIVERSE X 플랫폼의 통합 AI 어시스턴트 '옴니'다. 친절하고 정확하게 한국어로 답한다.",
    "code": "너는 시니어 개발자다. 실행 가능한 코드를 코드 블록으로 주고, 핵심만 짧게 설명한다.",
    "doc": "너는 문서 작성 전문가다. 제목과 소제목을 갖춘 읽기 쉬운 문서를 쓴다.",
    "game": "너는 게임 기획·제작 도우미다. 규칙, 레벨 디자인, 간단한 HTML5 게임 코드를 제안한다.",
    "study": "너는 학습 코치다. 개념을 단계별로 설명하고, 마지막에 확인 질문 2개를 낸다.",
}
PROMPT_LIBRARY = [
    {"mode": "chat", "title": "오늘 할 일 정리", "prompt": "오늘 해야 할 일을 우선순위대로 정리해줘: "},
    {"mode": "code", "title": "HTML 미니게임", "prompt": "키보드로 움직이는 우주선 피하기 게임을 HTML 한 파일로 만들어줘"},
    {"mode": "doc", "title": "공지문 작성", "prompt": "다음 내용을 공지문으로 정리해줘: "},
    {"mode": "game", "title": "퀘스트 아이디어", "prompt": "우주 행성 월드에 어울리는 퀘스트 5개를 제안해줘"},
    {"mode": "study", "title": "개념 배우기", "prompt": "블랙홀이 무엇인지 초등학생도 이해하게 설명해줘"},
]
MAX_HISTORY = 20
DAILY_CAP = int(os.environ.get("AI_DAILY_LIMIT", "200"))


def ai_config():
    key = os.environ.get("GEMINI_API_KEY", "").strip()
    model = os.environ.get("GEMINI_MODEL", "gemini-2.5-flash").strip()
    if not re.match(r"^[A-Za-z0-9.\-_]{1,80}$", model):
        model = "gemini-2.5-flash"
    return key, model


def generate(system, history, max_tokens=2048):
    """Gemini 호출. history = [{'role': 'user'|'assistant', 'content': str}, ...]"""
    key, model = ai_config()
    if not key:
        raise APIError(503, "AI가 아직 설정되지 않았습니다. 관리자가 GEMINI_API_KEY를 등록해야 합니다", "ai_not_configured")
    contents = [{"role": "model" if m["role"] == "assistant" else "user", "parts": [{"text": m["content"]}]}
                for m in history]
    payload = {"systemInstruction": {"parts": [{"text": system}]}, "contents": contents,
               "generationConfig": {"temperature": 0.8, "maxOutputTokens": max_tokens}}
    try:
        resp = requests.post(GEMINI_URL.format(model=model), json=payload, timeout=60,
                             headers={"x-goog-api-key": key, "Content-Type": "application/json"})
    except requests.RequestException:
        raise APIError(502, "AI 서버에 연결하지 못했습니다. 잠시 후 다시 시도하세요", "ai_unreachable")
    if resp.status_code == 429:
        raise APIError(429, "AI 사용량 한도에 도달했습니다. 잠시 후 다시 시도하세요", "ai_quota")
    if resp.status_code in (400, 401, 403):
        raise APIError(502, "AI 키 또는 모델 설정이 올바르지 않습니다 (관리자 확인 필요)", "ai_config_error")
    if resp.status_code >= 400:
        raise APIError(502, "AI 응답 오류가 발생했습니다", "ai_error")
    data = resp.json()
    try:
        parts = data["candidates"][0]["content"]["parts"]
        answer = "".join(p.get("text", "") for p in parts).strip()
    except (KeyError, IndexError, TypeError):
        answer = ""
    if not answer:
        raise APIError(502, "AI가 답을 만들지 못했습니다 (안전 필터 또는 빈 응답)", "ai_empty")
    return answer


def _check_daily_cap(uid):
    n = db.scalar("select count(*) as n from public.messages m join public.conversations c on c.id = m.conversation_id "
                  "where c.owner_id = %(u)s and c.kind = 'ai' and m.role = 'user' and m.created_at > now() - interval '1 day'",
                  {"u": uid})
    if n >= DAILY_CAP:
        raise APIError(429, f"AI는 하루 {DAILY_CAP}회까지 쓸 수 있습니다", "ai_daily_cap")


def system_prompt(uid, mode):
    memories = db.query("select content from public.ai_memories where user_id = %(u)s "
                        "order by importance desc, id desc limit 20", {"u": uid})
    prof = db.one("select p.display_name, p.level from public.user_profiles p where p.user_id = %(u)s", {"u": uid})
    s = MODES.get(mode, MODES["chat"])
    s += f"\n사용자 이름: {prof['display_name']} (레벨 {prof['level']})."
    if memories:
        s += "\n사용자가 기억해 달라고 한 내용:\n" + "\n".join(f"- {m['content']}" for m in memories)
    return s


@bp.get("/api/ai/status")
@login_required
def status():
    key, model = ai_config()
    return ok({"configured": bool(key), "model": model, "modes": list(MODES.keys()), "library": PROMPT_LIBRARY,
               "daily_limit": DAILY_CAP})


@bp.get("/api/ai/conversations")
@login_required
def conversations():
    return ok(db.query("select id, title, updated_at from public.conversations where owner_id = %(u)s and kind = 'ai' "
                       "order by updated_at desc limit 50", {"u": g.user["id"]}))


@bp.post("/api/ai/conversations")
@login_required
def new_conversation():
    title = text(body(), "title", required=False, max_len=60) or "새 대화"
    row = db.one("insert into public.conversations (kind, owner_id, title) values ('ai', %(u)s, %(t)s) returning id, title",
                 {"u": g.user["id"], "t": title})
    return ok(row, 201)


def _conv(cid):
    c = db.one("select id, title from public.conversations where id = %(c)s and owner_id = %(u)s and kind = 'ai'",
               {"c": cid, "u": g.user["id"]})
    if not c:
        raise APIError(404, "대화를 찾을 수 없습니다")
    return c


@bp.delete("/api/ai/conversations/<int:cid>")
@login_required
def delete_conversation(cid):
    _conv(cid)
    db.execute("delete from public.conversations where id = %(c)s", {"c": cid})
    return ok()


@bp.get("/api/ai/conversations/<int:cid>/messages")
@login_required
def messages(cid):
    _conv(cid)
    return ok(db.query("select id, role, content, created_at from public.messages where conversation_id = %(c)s order by id",
                       {"c": cid}))


@bp.post("/api/ai/conversations/<int:cid>/messages")
@login_required
@feature_required("ai")
@rate_limit("ai", 15, 60, per="user")
def send(cid):
    conv = _conv(cid)
    d = body()
    content = text(d, "content", max_len=8000)
    mode = choice(d, "mode", tuple(MODES.keys()), default="chat")
    uid = g.user["id"]
    _check_daily_cap(uid)
    history = db.query("select role, content from (select id, role, content from public.messages where conversation_id = %(c)s "
                       "order by id desc limit %(n)s) t order by id", {"c": cid, "n": MAX_HISTORY})
    history.append({"role": "user", "content": content})
    answer = generate(system_prompt(uid, mode), history)
    db.execute("insert into public.messages (conversation_id, sender_id, role, content) values (%(c)s, %(u)s, 'user', %(t)s)",
               {"c": cid, "u": uid, "t": content})
    row = db.one("insert into public.messages (conversation_id, role, content) values (%(c)s, 'assistant', %(t)s) "
                 "returning id, role, content, created_at", {"c": cid, "t": answer[:20000]})
    if conv["title"] == "새 대화":
        db.execute("update public.conversations set title = %(t)s where id = %(c)s", {"t": content[:40], "c": cid})
    else:
        db.execute("update public.conversations set updated_at = now() where id = %(c)s", {"c": cid})
    return ok(row, 201)


@bp.get("/api/ai/memories")
@login_required
def memories():
    return ok(db.query("select id, content, importance, created_at from public.ai_memories where user_id = %(u)s order by id desc",
                       {"u": g.user["id"]}))


@bp.post("/api/ai/memories")
@login_required
@rate_limit("memory", 20, 60, per="user")
def add_memory():
    d = body()
    uid = g.user["id"]
    if db.scalar("select count(*) as n from public.ai_memories where user_id = %(u)s", {"u": uid}) >= 50:
        raise APIError(400, "기억은 50개까지 저장할 수 있습니다")
    row = db.one("insert into public.ai_memories (user_id, content, importance) values (%(u)s, %(c)s, %(i)s) returning id",
                 {"u": uid, "c": text(d, "content", max_len=500), "i": integer(d, "importance", required=False, lo=1, hi=5, default=1)})
    return ok(row, 201)


@bp.delete("/api/ai/memories/<int:mid>")
@login_required
def delete_memory(mid):
    n = db.execute("delete from public.ai_memories where id = %(m)s and user_id = %(u)s", {"m": mid, "u": g.user["id"]})
    if not n:
        raise APIError(404, "기억을 찾을 수 없습니다")
    return ok()
