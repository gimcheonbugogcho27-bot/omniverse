"""여러 기능이 같이 쓰는 도메인 로직: 알림, 퀘스트, 업적, 경험치, 관리자 기록, 차단/친구 관계."""
import json

from flask import g

import db
from security import client_ip

QUEST_PERIOD_SQL = ("case when q.is_daily then (now() at time zone 'Asia/Seoul')::date "
                    "else date '2000-01-01' end")


def today_key():
    return db.scalar("select to_char(now() at time zone 'Asia/Seoul', 'YYYY-MM-DD') as d")


def notify(user_id, kind, message, link=None, actor_id=None):
    if actor_id is not None and actor_id == user_id:
        return
    db.execute(
        "insert into public.notifications (user_id, actor_id, kind, message, link) "
        "values (%(u)s, %(a)s, %(k)s, %(m)s, %(l)s)",
        {"u": user_id, "a": actor_id, "k": kind, "m": message[:300], "l": link},
    )


def add_exp(user_id, amount):
    if amount <= 0:
        return None
    return db.one(
        "update public.user_profiles set exp = exp + %(a)s, "
        "level = 1 + floor(sqrt((exp + %(a)s) / 100.0))::int "
        "where user_id = %(u)s returning level, exp",
        {"a": amount, "u": user_id},
    )


def complete_quest(user_id, code):
    """퀘스트를 완료 상태로 표시한다. 이미 완료/수령했으면 아무 일도 없다."""
    row = db.one(
        "insert into public.user_quests (user_id, quest_id, period, status, progress, completed_at) "
        f"select %(u)s, q.id, {QUEST_PERIOD_SQL}, 'completed', 1, now() "
        "from public.quests q where q.code = %(c)s and q.is_active "
        "on conflict do nothing returning quest_id",
        {"u": user_id, "c": code},
    )
    if row:
        title = db.scalar("select title from public.quests where code = %(c)s", {"c": code})
        notify(user_id, "quest", f"퀘스트 완료: {title} — 보상을 받으세요", "#/quests")
    return bool(row)


def award_achievement(user_id, code):
    row = db.one(
        "insert into public.user_achievements (user_id, achievement_id) "
        "select %(u)s, id from public.achievements where code = %(c)s "
        "on conflict do nothing returning achievement_id",
        {"u": user_id, "c": code},
    )
    if not row:
        return False
    ach = db.one("select title, reward_coins from public.achievements where code = %(c)s", {"c": code})
    if ach and ach["reward_coins"] > 0:
        try:
            db.scalar("select public.omni_credit(%(u)s, %(a)s, 'event_reward', %(m)s, %(k)s) as b",
                      {"u": user_id, "a": ach["reward_coins"], "m": f"업적: {ach['title']}", "k": f"ach:{user_id}:{code}"})
        except db.OmniError:
            pass
    notify(user_id, "achievement", f"업적 달성: {ach['title']}", "#/profile")
    return True


def check_explorer(user_id):
    row = db.one(
        "select (select count(*) from public.worlds where is_official and is_active) as total, "
        "(select count(*) from public.world_members m join public.worlds w on w.id = m.world_id "
        " where m.user_id = %(u)s and w.is_official and w.is_active) as visited",
        {"u": user_id},
    )
    if row and row["total"] > 0 and row["visited"] >= row["total"]:
        award_achievement(user_id, "explorer_5")


def check_social(user_id):
    n = db.scalar(
        "select count(*) as n from public.friendships where status = 'accepted' "
        "and (requester_id = %(u)s or addressee_id = %(u)s)", {"u": user_id})
    if n and n >= 10:
        award_achievement(user_id, "social_10")


def check_gamer(user_id):
    n = db.scalar("select count(*) as n from public.game_scores where user_id = %(u)s", {"u": user_id})
    if n and n >= 100:
        award_achievement(user_id, "gamer_100")


def admin_log(action, target_type=None, target_id=None, detail=None):
    db.execute(
        "insert into public.admin_logs (admin_id, action, target_type, target_id, detail, ip) "
        "values (%(a)s, %(ac)s, %(tt)s, %(ti)s, %(d)s::jsonb, %(ip)s)",
        {"a": g.user["id"] if g.get("user") else None, "ac": action, "tt": target_type, "ti": target_id,
         "d": json.dumps(detail or {}, ensure_ascii=False), "ip": client_ip()[:64]},
    )


def blocked_between(a, b):
    return bool(db.scalar(
        "select exists (select 1 from public.blocks where (blocker_id = %(a)s and blocked_id = %(b)s) "
        "or (blocker_id = %(b)s and blocked_id = %(a)s)) as x", {"a": a, "b": b}))


def are_friends(a, b):
    return bool(db.scalar(
        "select exists (select 1 from public.friendships where status = 'accepted' and "
        "least(requester_id, addressee_id) = least(%(a)s::bigint, %(b)s::bigint) and "
        "greatest(requester_id, addressee_id) = greatest(%(a)s::bigint, %(b)s::bigint)) as x",
        {"a": a, "b": b}))


def user_by_username(username):
    return db.one(
        "select u.id, u.username, u.role, u.status, p.display_name, p.is_public, p.level "
        "from public.users u join public.user_profiles p on p.user_id = u.id "
        "where lower(u.username) = lower(%(n)s) and u.status <> 'deleted'",
        {"n": username or ""},
    )


def like_escape(s):
    return s.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


# 게시물 가시성: 숨김 아님 + (공개 | 본인 | 친구공개&친구) + 차단 관계 없음
VISIBLE_POST_SQL = """
  not p.is_hidden
  and (p.visibility = 'public' or p.author_id = %(me)s
       or (p.visibility = 'friends' and exists (
            select 1 from public.friendships f where f.status = 'accepted'
              and least(f.requester_id, f.addressee_id) = least(p.author_id, %(me)s::bigint)
              and greatest(f.requester_id, f.addressee_id) = greatest(p.author_id, %(me)s::bigint))))
  and not exists (select 1 from public.blocks b where (b.blocker_id = %(me)s and b.blocked_id = p.author_id)
                                                or (b.blocker_id = p.author_id and b.blocked_id = %(me)s))
  and au.status = 'active'
"""

POST_SELECT_SQL = """
  select p.id, p.content, p.image_url, p.visibility, p.like_count, p.comment_count, p.created_at,
         p.community_id, c.name as community_name, c.slug as community_slug,
         au.id as author_id, au.username as author_username, ap.display_name as author_name, ap.level as author_level,
         exists (select 1 from public.likes l where l.post_id = p.id and l.user_id = %(me)s) as liked
  from public.posts p
  join public.users au on au.id = p.author_id
  join public.user_profiles ap on ap.user_id = au.id
  left join public.communities c on c.id = p.community_id
"""
